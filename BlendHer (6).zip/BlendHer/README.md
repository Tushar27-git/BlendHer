# BlendHer Shader Pack

**A high-performance hybrid shader that blends the vibrant warmth of BSL with the dark, desaturated horror of Spooklementary.**

---

## 🎨 What is BlendHer?

BlendHer is a psychological shader experience that makes Minecraft feel alive in daylight but creeping and anxious in darkness. It's held together by a thin, glowing purple thread—the ambient floor that appears in every dark area, at every time of day.

### The Five Visual States

1. **High-Noon Vibrancy** - Warm, saturated, golden. Grass is punchy emerald.
2. **Creeping Shadows** - Deep olive-grey. Purple floor visible in corners.
3. **Purple Haze Sunset** - Violet sky. God rays shaft through trees.
4. **Playable Horror (Midnight)** - Cyan moonlight. Teal-black water mirror.
5. **The Storm (Rain)** - Grey-purple wash. Wind animation 1.8x speed.

---

## ✨ Features

### Core Features
- ✅ **BlendHer Dynamic Lighting** - Smooth BSL ↔ Spook mode transition
- ✅ **Purple Ambient Floor** - Always present, never turns off (the signature)
- ✅ **Gerstner Water Waves** - Two-layer interference, vertex-stage only
- ✅ **Water Absorption** - Beer-Lambert, blue absorbs fastest
- ✅ **Water Night Darkening** - Becomes teal-black mirror at midnight
- ✅ **Moonlight Cyan Tint** - Night mode with empowering cyan-white light
- ✅ **Exponential Fog** - Atmospheric depth with sky color inheritance
- ✅ **Rain Desaturation** - Heavy rain desaturates the world
- ✅ **Bloom** - Gaussian blur for torch/lava glow
- ✅ **Tone Mapping** - ACES + asymmetric shadow crush

### Disabled (For Stability)
- ❌ PCF Soft Shadows (can be re-enabled)
- ❌ God Rays (can be re-enabled)
- ❌ Screen Space Reflections (can be re-enabled)

---

## 📋 Requirements

- **Minecraft:** 1.20.1+
- **Iris:** 1.7.0+
- **Sodium:** 0.5.0+
- **GPU:** GTX 1650 Ti or better (4GB VRAM minimum)
- **RAM:** 16GB DDR4 or better

### Optional
- **Distant Horizons:** For far-distance LOD rendering

---

## 🚀 Installation

1. **Download the shader pack**
   ```
   Copy the entire 'shaders' folder to:
   ~/.minecraft/shaderpacks/BlendHer/
   ```

2. **Open Minecraft**
   - Launch with Iris and Sodium installed
   - Go to Options → Shaders
   - Select "BlendHer"
   - Wait for compilation (first load takes 10-30 seconds)

3. **Verify it loaded**
   - No red error text in chat
   - No errors in `~/.minecraft/logs/latest.log`
   - World renders normally

---

## ⚙️ Configuration

All settings are in `shaders/include/settings.glsl`:

### Purple Floor (The Signature)
```glsl
#define AMBIENT_R 0.04      // Red channel
#define AMBIENT_G 0.03      // Green channel
#define AMBIENT_B 0.09      // Blue channel (purple)
#define AMBIENT_THRESHOLD 0.05  // When Spook mode activates
```

### Lighting
```glsl
#define BSL_WARMTH_R 1.05   // Torch/sun red boost
#define BSL_WARMTH_G 0.98   // Torch/sun green
#define BSL_WARMTH_B 0.88   // Torch/sun blue (lower = warmer)
#define SPOOK_DESAT 0.55    // Shadow desaturation (0-1)
```

### Moonlight
```glsl
#define MOON_CYAN_R 0.72    // Moonlight red
#define MOON_CYAN_G 0.88    // Moonlight green
#define MOON_CYAN_B 1.00    // Moonlight blue
#define MOON_INTENSITY 0.18 // Moonlight strength
```

### Water
```glsl
#define WATER_WAVE_AMP 0.10     // Wave height
#define WATER_WAVE_FREQ 0.25    // Wave frequency
#define WATER_NIGHT_DARKEN 0.55 // How dark at midnight
```

### Atmosphere
```glsl
#define FOG_DENSITY 0.0005      // Fog thickness
#define RAIN_DESAT 0.75         // Rain desaturation
#define BLOOM_STRENGTH 0.35     // Bloom intensity
#define BLOOM_RADIUS 7.0        // Bloom size
```

---

## 🎮 Testing the Five Visual States

### State 1: High-Noon Vibrancy
- **Time:** 12:00 (noon)
- **Location:** Birch forest, open sky
- **Expected:** Warm, saturated colors. Punchy emerald grass.

### State 2: Creeping Shadows
- **Time:** 12:00 (noon)
- **Location:** Dense oak canopy
- **Expected:** Deep olive-grey. Purple floor visible in shadows.

### State 3: Purple Haze Sunset
- **Time:** 18:00 (sunset)
- **Location:** Open plains with trees
- **Expected:** Violet sky. Atmospheric fog.

### State 4: Playable Horror (Midnight)
- **Time:** 0:00 (midnight)
- **Location:** Moonlit terrain
- **Expected:** Cyan-white moonlight. Paths visible but shadows menacing.

### State 5: The Storm (Rain)
- **Time:** Any time
- **Command:** `/weather rain`
- **Expected:** Grey-purple wash. Wind animation 1.8x speed.

---

## 📊 Performance

### Target Specifications
- **GPU:** GTX 1650 Ti (4GB GDDR6)
- **CPU:** Ryzen 5 4600H
- **RAM:** 16GB DDR4
- **Target FPS:** 60+ (dense forest), 90+ (open plains)
- **VRAM Budget:** ~66 MB

### Performance Tuning

**If FPS is Low (< 60):**
```glsl
#define BLOOM_RADIUS 3.0        // Was 7.0
#define BLOOM_STRENGTH 0.15     // Was 0.35
#define FOG_DENSITY 0.0002      // Was 0.0005
```

**If FPS is High (> 90):**
```glsl
#define BLOOM_RADIUS 15.0       // Was 7.0
#define BLOOM_STRENGTH 0.5      // Was 0.35
#define FOG_DENSITY 0.001       // Was 0.0005
```

---

## 📁 File Structure

```
shaders/
├── composite.fsh              # Main scene composition
├── composite1.fsh             # Bloom horizontal blur
├── composite2.fsh             # Bloom vertical blur
├── final.fsh                  # Post-processing output
├── gbuffers_entities.fsh      # Entity rendering
├── gbuffers_entities.vsh
├── gbuffers_skytextured.fsh   # Sky rendering
├── gbuffers_skytextured.vsh
├── gbuffers_terrain.fsh       # Terrain rendering
├── gbuffers_terrain.vsh
├── gbuffers_textured.fsh      # Textured pass
├── gbuffers_textured.vsh
├── gbuffers_water.fsh         # Water rendering
├── gbuffers_water.vsh
├── shadow.fsh                 # Shadow pass
├── shadow.vsh
├── shaders.properties         # Shader pack metadata
└── include/
    ├── settings.glsl          # All tunable parameters
    ├── uniforms.glsl          # Uniform declarations
    ├── utils.glsl             # Math helpers
    ├── lighting.glsl          # BlendHer lighting system
    ├── water.glsl             # Water effects
    ├── atmosphere.glsl        # Fog + bloom
    ├── shadow.glsl            # Shadow calculations
    ├── tonemapping.glsl       # ACES + horror crush
    ├── pbr.glsl               # Material handling
    └── displacement.glsl      # Foliage wind animation
```

---

## 🐛 Troubleshooting

### Shaders Won't Load
1. Clear shader cache: `~/.minecraft/shadercache/`
2. Verify Iris 1.7.0+ is installed
3. Check `~/.minecraft/logs/latest.log` for errors

### White Screen or White Patch
1. Clear shader cache
2. Reload shaders (F3 + R in Minecraft)
3. Verify all include files are present

### Low FPS
1. Reduce `BLOOM_RADIUS` and `BLOOM_STRENGTH`
2. Reduce `FOG_DENSITY`
3. Check GPU temperature (might be thermal throttling)

### Colors Look Wrong
1. Adjust `BSL_WARMTH_R/G/B` in settings.glsl
2. Adjust `SPOOK_DESAT` for shadow desaturation
3. Adjust `AMBIENT_R/G/B` for purple floor intensity

See **TROUBLESHOOTING.md** for more detailed help.

---

## 📚 Documentation

- **SHADER_REBUILD_COMPLETE.md** - Technical implementation details
- **QUICK_START.md** - User-friendly setup guide
- **FIXES_APPLIED.md** - What was fixed and why
- **TROUBLESHOOTING.md** - Common issues and solutions
- **IMPLEMENTATION_SUMMARY.txt** - Detailed breakdown of all changes

---

## 🎯 The Purple Thread Principle

> "The thin glowing purple thread that holds BlendHer together is the ambient floor. It appears in EVERY dark area, in EVERY weather state, at EVERY time of day. It is the signature."

**Never turn it off.** Never reduce `AMBIENT_B` below 0.07. Never make `AMBIENT_THRESHOLD` above 0.08.

---

## 🎨 Aesthetic Philosophy

**BlendHer is a high-performance psychological experience.**

It is the Golden Hour of BSL meeting the Dead of Night of Spooklementary, held together by a thin, glowing purple thread.

The goal is not photorealism. The goal is to make the player feel something:
- **Safe and alive** in daylight
- **Creeping dread** in shadows
- **Anxious empowerment** at night
- **Stripped vulnerability** in storms

---

## 📝 Credits

- **BSL Shaders** by Capt Tatsu - Vibrant, warm aesthetic
- **Spooklementary** by SpacEagle17 - Dark, desaturated horror tones
- **BlendHer** - Hybrid shader combining both philosophies

---

## 📄 License

This shader pack is provided as-is for personal use. Feel free to modify and customize for your own needs.

---

## 🚀 Status

✅ **All shaders compile without errors**
✅ **All features working**
✅ **Ready to experience the blend**

**Welcome to BlendHer. Welcome to the blend.**
