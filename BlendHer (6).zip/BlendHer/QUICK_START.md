# BlendHer Shader Pack - Quick Start Guide

## Installation

1. **Copy the `shaders/` folder** to your Minecraft shader pack directory:
   ```
   ~/.minecraft/shaderpacks/BlendHer/shaders/
   ```

2. **Requirements:**
   - Minecraft 1.20.1+ (or compatible version)
   - Iris 1.7.0+
   - Sodium 0.5.0+
   - Distant Horizons (optional, but recommended)

3. **Load in Minecraft:**
   - Open Minecraft with Iris
   - Go to Options → Shaders
   - Select "BlendHer"
   - Wait for compilation (first load takes 10-30 seconds)

---

## First Time Setup

### Check Compilation
- If shaders load without errors, you're good to go!
- If you see red text in chat, check the log file:
  ```
  ~/.minecraft/logs/latest.log
  ```

### Adjust Settings
All settings are in `shaders/include/settings.glsl`:

```glsl
// Purple floor intensity (the signature)
#define AMBIENT_R 0.04
#define AMBIENT_G 0.03
#define AMBIENT_B 0.09

// When Spook mode activates (0.0 = always dark, 1.0 = always bright)
#define AMBIENT_THRESHOLD 0.05

// Shadow desaturation (0 = colorful, 1 = grayscale)
#define SPOOK_DESAT 0.55

// Torch/sun warmth (lower blue = warmer gold)
#define BSL_WARMTH_R 1.05
#define BSL_WARMTH_G 0.98
#define BSL_WARMTH_B 0.88

// Bloom strength (0 = off, 1 = nuclear)
#define BLOOM_STRENGTH 0.35

// God rays quality (4-16, higher = better but slower)
#define GODRAY_SAMPLES 8
```

---

## Testing the Five Visual States

### 1. High-Noon Vibrancy
- **Time:** Noon (12:00)
- **Location:** Birch forest, open sky
- **Expected:** Warm, saturated, golden. Grass is punchy emerald.
- **Adjust if:** Colors too dull → increase `BSL_WARMTH_R`

### 2. Creeping Shadows
- **Time:** Noon
- **Location:** Dense oak canopy
- **Expected:** Deep olive-grey. Purple floor visible in shadows.
- **Adjust if:** Purple too strong → decrease `AMBIENT_B`

### 3. Purple Haze Sunset
- **Time:** Sunset (18:00)
- **Location:** Open plains with trees
- **Expected:** Violet sky. God rays shaft through trees.
- **Adjust if:** God rays too weak → increase `GODRAY_STRENGTH`

### 4. Playable Horror (Midnight)
- **Time:** Midnight (0:00)
- **Location:** Moonlit terrain
- **Expected:** Cyan-white moonlight. Paths visible but shadows menacing.
- **Adjust if:** Too dark → increase `MOON_INTENSITY`

### 5. The Storm (Rain)
- **Time:** Any time
- **Command:** `/weather rain`
- **Expected:** Grey-purple wash. Wind animation 1.8x speed.
- **Adjust if:** Desaturation too strong → decrease `RAIN_DESAT`

---

## Performance Tuning

### If FPS is Low (< 60)

**Reduce quality:**
```glsl
#define GODRAY_SAMPLES 4        // Was 8
#define BLOOM_RADIUS 3.0        // Was 7.0
#define SSR_STEPS 8             // Was 16
#define SHADOW_RESOLUTION 1024  // Was 2048
```

**Or disable features:**
```glsl
// Comment out god rays in composite.fsh
// lit += getGodRays(colortex0, texcoord, sunScreenPos);

// Comment out SSR in composite.fsh
// if (materialType == 1) { ... }
```

### If FPS is High (> 90)

**Increase quality:**
```glsl
#define GODRAY_SAMPLES 16       // Was 8
#define BLOOM_RADIUS 15.0       // Was 7.0
#define SSR_STEPS 32            // Was 16
#define SHADOW_RESOLUTION 4096  // Was 2048
```

---

## Common Issues

### Issue: Shaders won't compile
**Solution:** Check `~/.minecraft/logs/latest.log` for error messages. Most common issues:
- Missing `#include` files (check `shaders/include/` folder)
- GLSL syntax errors (check line numbers in error message)
- Uniform mismatch (check `uniforms.glsl`)

### Issue: Purple floor too strong/weak
**Solution:** Adjust in `settings.glsl`:
```glsl
#define AMBIENT_R 0.04  // Increase for more red
#define AMBIENT_G 0.03  // Increase for more green
#define AMBIENT_B 0.09  // Increase for more blue (purple)
```

### Issue: Water looks flat
**Solution:** Increase wave amplitude in `settings.glsl`:
```glsl
#define WATER_WAVE_AMP 0.15  // Increase for bigger waves
#define WATER_WAVE_FREQ 0.25 // Increase for more frequent waves
```

### Issue: Shadows too soft/hard
**Solution:** Adjust PCF in `settings.glsl`:
```glsl
#define SHADOW_NORMAL_OFFSET 0.02  // Increase for softer shadows
#define SHADOW_DISTORTION 0.9      // Decrease for harder shadows
```

### Issue: Bloom too bright/dim
**Solution:** Adjust in `settings.glsl`:
```glsl
#define BLOOM_THRESHOLD 1.2   // Lower = more things bloom
#define BLOOM_STRENGTH 0.35   // Increase for brighter bloom
#define BLOOM_RADIUS 7.0      // Increase for larger bloom
```

---

## Advanced Customization

### Change Moonlight Color
In `settings.glsl`:
```glsl
#define MOON_CYAN_R 0.72  // Red channel (0.0-1.0)
#define MOON_CYAN_G 0.88  // Green channel (0.0-1.0)
#define MOON_CYAN_B 1.00  // Blue channel (0.0-1.0)
#define MOON_INTENSITY 0.18  // Brightness (0.0-1.0)
```

### Change Fog Color
In `atmosphere.glsl`, modify `applyFog()`:
```glsl
vec3 fogColor = skyColor;
fogColor = mix(fogColor, vec3(skyLuma), FOG_SAT_REDUCE);
fogColor += vec3(FOG_PURPLE_SHIFT * 0.1, FOG_PURPLE_SHIFT * 0.05, FOG_PURPLE_SHIFT * 0.2);
// Adjust the RGB multipliers to change fog tint
```

### Change Wind Animation Speed
In `settings.glsl`:
```glsl
#define WIND_GRASS_FREQ 2.0   // Increase for faster grass sway
#define WIND_LEAVES_FREQ 0.8  // Increase for faster leaf sway
#define WIND_CROPS_FREQ 3.0   // Increase for faster crop sway
#define RAIN_WIND_MULT 1.8    // Increase for more wind in rain
```

---

## File Structure

```
shaders/
├── composite.fsh          # Main scene composition
├── composite1.fsh         # Bloom horizontal blur
├── composite2.fsh         # Bloom vertical blur
├── final.fsh              # Post-processing output
├── gbuffers_entities.fsh  # Entity rendering
├── gbuffers_entities.vsh  # Entity vertex pass
├── gbuffers_skytextured.fsh
├── gbuffers_skytextured.vsh
├── gbuffers_terrain.fsh   # Terrain rendering
├── gbuffers_terrain.vsh   # Terrain vertex pass + wind
├── gbuffers_textured.fsh
├── gbuffers_textured.vsh
├── gbuffers_water.fsh     # Water rendering
├── gbuffers_water.vsh     # Water vertex pass + waves
├── shadow.fsh             # Shadow pass
├── shadow.vsh             # Shadow vertex pass
├── shaders.properties     # Shader pack metadata
├── include/
│   ├── settings.glsl      # All tunable parameters
│   ├── uniforms.glsl      # Uniform declarations
│   ├── utils.glsl         # Math helpers
│   ├── lighting.glsl      # BlendHer lighting system
│   ├── water.glsl         # Water effects
│   ├── atmosphere.glsl    # Fog + god rays + bloom
│   ├── shadow.glsl        # PCF soft shadows
│   ├── tonemapping.glsl   # ACES + horror crush
│   ├── pbr.glsl           # Screen-space reflections
│   └── displacement.glsl  # Foliage wind animation
└── lang/
    └── en_US.lang         # Language file
```

---

## Performance Targets

- **GPU:** GTX 1650 Ti (4GB GDDR6)
- **CPU:** Ryzen 5 4600H
- **RAM:** 16GB DDR4
- **Target FPS:** 60 FPS minimum (dense oak forest, noon, shadows active)
- **Target FPS:** 90 FPS (open plains, clear sky)
- **VRAM Budget:** ~66 MB

---

## Support & Troubleshooting

If you encounter issues:

1. **Check the log file:** `~/.minecraft/logs/latest.log`
2. **Verify all files are present:** Check `shaders/include/` folder
3. **Try default settings:** Reset `settings.glsl` to defaults
4. **Update Iris:** Make sure you have Iris 1.7.0+
5. **Check Minecraft version:** BlendHer requires 1.20.1+

---

## The Purple Thread Principle

> "The thin glowing purple thread that holds BlendHer together is the ambient floor. It appears in EVERY dark area, in EVERY weather state, at EVERY time of day. It is the signature."

**Never turn it off.** Never reduce `AMBIENT_B` below 0.07. Never make `AMBIENT_THRESHOLD` above 0.08.

---

## Enjoy!

BlendHer is a high-performance psychological experience. It's the Golden Hour of BSL meeting the Dead of Night of Spooklementary, held together by a thin, glowing purple thread.

The goal is to make you feel something:
- Safe and alive in daylight
- Creeping dread in shadows
- Anxious empowerment at night
- Stripped vulnerability in storms

**Welcome to the blend.**
