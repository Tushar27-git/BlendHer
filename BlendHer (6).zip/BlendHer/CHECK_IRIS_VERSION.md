# How to Check Your Iris Version

## Method 1: In-Game (Easiest)

1. **Open Minecraft**
2. **Go to:** Options → Shaders
3. **Look at the bottom left** - You'll see something like:
   ```
   Iris Version: 1.7.0
   ```
   or
   ```
   Iris 1.7.0 (Iris Shaders)
   ```

## Method 2: Check Mods Folder

1. **Navigate to:** `~/.minecraft/mods/`
2. **Look for a file named:** `iris-*.jar`
   - Example: `iris-1.7.0+mc1.20.1.jar`
   - The version number is in the filename

## Method 3: Check Minecraft Launcher

1. **Open Minecraft Launcher**
2. **Go to:** Installations
3. **Find your profile** (the one you use for modded Minecraft)
4. **Click the folder icon** to open the installation folder
5. **Navigate to:** `mods/`
6. **Look for:** `iris-*.jar`

## What Version Do You Need?

- **Minimum:** Iris 1.7.0
- **Recommended:** Iris 1.7.0 or newer
- **Current Latest:** Check [Iris GitHub](https://github.com/IrisShaders/Iris/releases)

## If Your Version is Too Old

1. **Download latest Iris:**
   - Go to [Iris Releases](https://github.com/IrisShaders/Iris/releases)
   - Download the latest `.jar` file for your Minecraft version

2. **Replace the old version:**
   - Delete the old `iris-*.jar` from `~/.minecraft/mods/`
   - Copy the new `iris-*.jar` to `~/.minecraft/mods/`

3. **Restart Minecraft**

## Verify Installation

After updating:
1. Open Minecraft
2. Go to Options → Shaders
3. Confirm the new version is shown
4. Select BlendHer shader pack
5. Wait for compilation

---

**Your current GPU:** GTX 1650 Ti (shown at bottom of shader selection screen)
**Your current OpenGL:** Should be 3.3 or higher (shown at bottom of shader selection screen)

If you see "OpenGL 3.2" or lower, you may need to update your GPU drivers.
