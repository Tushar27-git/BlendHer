# BlendHer Shader Pack - Feature Overview

## What You're Getting

BlendHer is a **high-performance hybrid shader** that blends the vibrant, warm aesthetic of **BSL** with the dark, desaturated horror tones of **Spooklementary**. The result is a shader that feels alive in daylight but creeping and anxious in darkness.

---

## Core Features

### 1. **BSL ↔ Spook Dynamic Lighting**
The heart of BlendHer. A branchless GLSL function that smoothly transitions between two lighting modes based on light level:

- **BSL Mode (Daylight):** Warm, saturated, golden. Torchlight glows amber-gold. Grass is punchy emerald.
- **Spook Mode (Darkness):** Desaturated, olive-grey. Shadows are deep and menacing.
- **Transition:** Smooth crossfade at configurable light threshold (default: 0.05)

**Visual Result:** The world feels safe and vibrant in sunlight, but stepping into shadow feels like entering another realm.

---

### 2. **Purple Ambient Floor** (The Signature)
Instead of pure black in dark areas, BlendHer injects a faint charcoal-purple glow. This is **additive** (not multiplicative), so it survives in caves and shadows.

- **Why it matters:** Darkness feels alive, not empty. The player's brain senses something beneath the surface.
- **Configurable:** `AMBIENT_R`, `AMBIENT_G`, `AMBIENT_B` in settings.glsl
- **Never turns off:** This is the BlendHer identity.

---

### 3. **God Rays (Volumetric Light Shafts)**
Radial screen-space blur god rays that shaft through foliage when the sun is above the horizon.

- **8 samples** (sweet spot for GTX 1650 Ti)
- **Decay factor:** 0.96 per step
- **Sun-gated:** No rays underground or at night
- **Most dramatic:** At sunset when sun is low through trees

---

### 4. **Gerstner Water Waves**
Physically accurate water surface using Gerstner wave physics (not 3D noise).

- **Two-layer interference:** Different directions and frequencies create organic, non-repeating patterns
- **Vertex-stage only:** Zero VRAM cost, pure trigonometry
- **Sharp crests, flat troughs:** Looks like real ocean water
- **Beer-Lambert absorption:** Deep water shifts to teal-green (blue absorbs fastest)
- **Night darkening:** Water becomes a near-black teal mirror at midnight
- **Chromatic aberration:** Subtle RGB fringe at screen edges for cinematic glass effect

---

### 5. **Foliage Wind Animation**
Vertex-stage wind displacement for grass, leaves, and crops.

- **Grass:** Two-axis sine for organic motion
- **Leaves:** Vertical phase variation across layers
- **Crops:** Higher frequency for nervous sway
- **Rain multiplier:** Animation speed increases 1.8x in storms
- **Ground-lock:** Base of grass stays planted, only tops sway (no floating)

---

### 6. **Bloom (Torch/Lava Glow)**
Two-pass Gaussian blur bloom system.

- **Threshold:** 1.2 (only lava, torches, and very bright sources trigger it)
- **Radius:** 7 pixels (concavesfigurable)
- **Strength:** 0.35 (visible but not overexposed)
- **Visual:** Torches become warm golden sanctuaries in dark 

---

### 7. **Screen Space Reflections (SSR)**
Water reflections using screen-space raymarching.

- **16 steps** (fast, quality-balanced)
- **Thickness tolerance:** 0.5 (prevents artifacts)
- **Edge fade:** Reflections fade near screen borders
- **Fallback:** Sky reflection when no terrain hit

---

### 8. **PCF Soft Shadows**
Percentage Closer Filtering for soft shadow edges.

- **3x3 filter:** 9 samples per pixel
- **Cosine distortion:** Concentrates resolution near player, softer at edges
- **Normal offset:** 0.02 (prevents self-shadowing acne)
- **Resolution:** 2048x2048 (8 MB VRAM)

---

### 9. **Exponential Fog**
Atmospheric fog that matches real-world scattering.

- **Clarity vs Mystery:** Immediate world is sharp, horizon fades
- **DH fog wall:** Hides Distant Horizons LOD seams at 1200-1500 blocks
- **Purple tint:** Fog inherits sky color with -15% saturation and +5% purple shift
- **Rain desaturation:** Heavy rain desaturates the world (not fog blindness)

---

### 10. **Horror Tonemapping**
ACES filmic curve + asymmetric shadow crush.

- **Standard ACES:** Bright scenes use standard tone-mapping
- **Horror curve:** Dark scenes get pow(x, 1.15) shadow crush
- **Asymmetric:** Highlights preserved (BSL vibrant), shadows crushed (Spooklementary dark)
- **Result:** Shadows feel deeper and more menacing

---

### 11. **Moonlight Cyan Tint**
At night, the scene is tinted with cool cyan-white moonlight.

- **Intensity:** 0.18 (configurable)
- **Color:** (0.72, 0.88, 1.00) - cool cyan-white
- **Gated:** Only active when sun is below horizon
- **Empowering:** Player can navigate by moonlight while remaining anxious

---

### 12. **Distant Horizons Integration**
Full support for Distant Horizons LOD rendering.

- **DH depth buffer:** Properly sampled for far-distance fog
- **Fog wall:** Smoothly hides LOD seams
- **Requires:** `iris.features=DISTANT_HORIZONS` in shaders.properties

---

## The Five Visual States

Every shader decision is evaluated against these five states:

### State 1: High-Noon Vibrancy
- **Setting:** Birch forest, noon, direct sunlight
- **Feel:** Safe, alive, premium
- **Colors:** Punchy emerald grass, thick painterly clouds, crystal-clear water
- **Lighting:** Full BSL mode, zero purple contamination

### State 2: Creeping Shadows
- **Setting:** Dense oak canopy, filtered sunlight
- **Feel:** Transition, something has changed
- **Colors:** Deep olive-grey, charcoal-purple in corners
- **Lighting:** Spook mode activating, purple floor visible

### State 3: Purple Haze Sunset
- **Setting:** Sun dipping, sky transitions orange → violet
- **Feel:** World stops feeling safe
- **Colors:** Violet-purple sky, dark teal water, atmospheric fog
- **Lighting:** God rays shaft through trees, fog rises visibly

### State 4: Playable Horror (Midnight)
- **Setting:** Moonlit terrain, zero sunlight
- **Feel:** Empowered but anxious
- **Colors:** Cyan-white moonlight, teal-black water mirror, impenetrable shadows
- **Lighting:** Paths visible via moonlight, but shadows remain menacing
- **Visibility:** 32+ blocks minimum (not blinding)

### State 5: The Storm (Rain)
- **Setting:** Heavy rain, any time of day
- **Feel:** World stripped of vibrancy
- **Colors:** Grey-purple wash, wet shimmer on blocks
- **Lighting:** Desaturation at max, wind animation 1.8x speed
- **Visibility:** 32+ blocks (rain desaturates, doesn't blind)

---

## Performance Target

- **GPU:** GTX 1650 Ti (4GB GDDR6)
- **CPU:** Ryzen 5 4600H
- **RAM:** 16GB DDR4
- **Target FPS:** 60 FPS minimum (dense oak forest, noon, shadows active)
- **Target FPS:** 90 FPS (open plains, clear sky)
- **VRAM Budget:** ~66 MB (well within 3.2 GB usable)

---

## Configuration

All tuning is done in `shaders/include/settings.glsl`. Every value has a comment explaining:
- Visual effect
- Valid range
- Performance cost

Key tunables:
- `AMBIENT_R/G/B` - Purple floor color
- `AMBIENT_THRESHOLD` - Light level where Spook mode triggers
- `SPOOK_DESAT` - Shadow desaturation amount
- `BSL_WARMTH_R/G/B` - Torch/sun warmth
- `BLOOM_THRESHOLD` - What triggers bloom
- `WATER_WAVE_FREQ/AMP` - Wave intensity
- `FOG_DENSITY` - Atmospheric fog thickness
- `GODRAY_SAMPLES` - God ray quality

---

## The Purple Thread Principle

> "The thin glowing purple thread that holds BlendHer together is the ambient floor. It appears in EVERY dark area, in EVERY weather state, at EVERY time of day. It is the signature."

Never turn it off. Never reduce `AMBIENT_B` below 0.07. Never make `AMBIENT_THRESHOLD` above 0.08.

---

## Aesthetic Philosophy

**BlendHer is a high-performance psychological experience.**

It is the Golden Hour of BSL meeting the Dead of Night of Spooklementary, held together by a thin, glowing purple thread.

The goal is not photorealism. The goal is to make the player feel something:
- Safe and alive in daylight
- Creeping dread in shadows
- Anxious empowerment at night
- Stripped vulnerability in storms

---

## What's NOT Included

To maintain 60+ FPS on a 1650 Ti:
- ❌ 3D volumetric fog (too slow)
- ❌ Raymarched god rays (too slow)
- ❌ Complex parallax mapping (too slow)
- ❌ Subsurface scattering (too slow)
- ❌ Complex PBR workflows (too slow)

Instead: **Lightweight, branchless, screen-space techniques** that deliver the aesthetic at high FPS.

---

## Summary

BlendHer is a **lightweight, high-performance shader** that delivers a **unique aesthetic** by blending two opposing visual philosophies. It's not trying to be photorealistic. It's trying to make Minecraft feel like a vibrant dream slowly turning into a beautiful nightmare.

**Status:** ✅ All compilation errors fixed. Ready to experience the blend.
