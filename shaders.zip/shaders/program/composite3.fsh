/*
 * BlendHer Shader - Bloom Vertical Blur Pass
 * 
 * This fragment shader implements the vertical pass of a separable Gaussian blur
 * for bloom effect. This is the second pass of the separable blur, applied after
 * the horizontal pass (composite2.fsh).
 * 
 * Separable Gaussian blur is a performance optimization that reduces the number
 * of samples from O(n²) to O(2n). The horizontal pass (composite2.fsh) extracts
 * bright pixels and applies horizontal blur. This vertical pass applies the
 * vertical blur to complete the 2D Gaussian blur effect.
 * 
 * Pipeline:
 * 1. Read horizontally blurred bloom from colortex0 (output from composite2.fsh)
 * 2. Apply separable Gaussian blur vertically using 7-tap kernel
 * 3. Clamp output to valid range [0.0, 1.0]
 * 4. Output vertically blurred bloom result
 * 
 * Performance:
 * - 7-tap vertical blur kernel: 7 texture samples per pixel
 * - Total separable blur: 7 (horizontal) + 7 (vertical) = 14 samples
 * - Compared to 2D blur: 49 samples (7x7 kernel)
 * - Performance improvement: 3.5x faster than 2D blur
 * 
 * Reference: Requirement 15 (Performance Targets)
 * Compatible with: GLSL 460 core, Iris 1.8.5+, OptiFine
 */

#version 460 core

// ============================================================================
// INCLUDE FILES
// ============================================================================
#include "/lib/settings.glsl"
#include "/lib/uniforms.glsl"
#include "/lib/utils.glsl"

// ============================================================================
// INPUT/OUTPUT
// ============================================================================

// Input from vertex shader
in vec2 texCoord;

// Input textures
uniform sampler2D colortex0;  // Horizontally blurred bloom (from composite2.fsh)

// Output
layout(location = 0) out vec4 outColor;

// ============================================================================
// GAUSSIAN BLUR KERNEL
// ============================================================================

// Gaussian blur kernel weights for 7-tap filter
// These weights are pre-calculated for a Gaussian distribution with σ ≈ 1.0
const float kernel[7] = float[](
    0.0625,   // 1/16
    0.125,    // 2/16
    0.1875,   // 3/16
    0.25,     // 4/16 (center)
    0.1875,   // 3/16
    0.125,    // 2/16
    0.0625    // 1/16
);

// Offsets for sampling (in texture coordinates)
const int offsets[7] = int[](
    -3, -2, -1, 0, 1, 2, 3
);

// ============================================================================
// MAIN FRAGMENT SHADER
// ============================================================================

void main() {
    // Apply vertical Gaussian blur
    vec3 blurred = vec3(0.0);
    
    // Get screen size for proper texel offset calculation
    // Use invScreenSize uniform for efficient calculation (1.0 / screenSize)
    float texelSize = invScreenSize.y;  // Vertical texel size
    
    // Apply 7-tap Gaussian blur vertically
    for (int i = 0; i < 7; i++) {
        // Calculate sample coordinate (vertical offset only)
        vec2 sampleCoord = texCoord + vec2(0.0, float(offsets[i]) * texelSize);
        
        // Clamp to screen bounds
        sampleCoord = clamp(sampleCoord, vec2(0.0), vec2(1.0));
        
        // Sample and accumulate with kernel weight
        vec3 sample = texture(colortex0, sampleCoord).rgb;
        blurred += sample * kernel[i];
    }
    
    // Clamp to valid range
    blurred = clamp(blurred, vec3(0.0), vec3(1.0));
    
    // Output vertically blurred bloom
    outColor = vec4(blurred, 1.0);
}
