/*
 * BlendHer Shader - Shadow Fragment Shader
 * 
 * This shader writes depth data to shadow maps for cascaded shadow rendering.
 * It handles:
 * - Depth writing to shadow maps
 * - Alpha testing for transparent blocks (leaves, glass, etc.)
 * - Proper depth bias application
 * 
 * Compatible with: GLSL 460 core, Iris 1.8.5+, OptiFine
 * References: Requirement 5 (Cascaded Shadow Mapping)
 */

#version 460 core

// ============================================================================
// FRAGMENT SHADER INPUT
// ============================================================================

// Shadow map coordinate (from vertex shader)
in vec3 vShadowCoord;

// Texture coordinate (for alpha testing)
in vec2 vTexCoord;

// Vertex color (for alpha blending)
in vec4 vColor;

// Vertex normal (for adaptive depth bias)
in vec3 vNormal;

// ============================================================================
// UNIFORMS
// ============================================================================

// Include modern uniforms and settings
#include "/lib/uniforms.glsl"
#include "/lib/settings.glsl"

// Texture samplers for alpha testing
uniform sampler2D tex;           // Main texture (for alpha channel)
uniform sampler2D lightmap;      // Lightmap (for light level detection)

// ============================================================================
// FRAGMENT SHADER OUTPUT
// ============================================================================

// Output depth to shadow map
// The depth is automatically written to the shadow map texture
// No explicit output needed - gl_FragDepth is used implicitly

// ============================================================================
// ALPHA TESTING FUNCTIONS
// ============================================================================

/**
 * Performs alpha testing to discard transparent pixels.
 * 
 * This function samples the texture at the given coordinate and discards
 * the fragment if the alpha value is below the threshold. This is necessary
 * for rendering transparent blocks like leaves, glass, and water.
 * 
 * Input: texCoord - texture coordinate
 *        alphaThreshold - minimum alpha value to keep (0.0-1.0)
 * Output: none (discards fragment if alpha < threshold)
 * 
 * Validates: Requirement 5 (Cascaded Shadow Mapping)
 */
void performAlphaTesting(vec2 texCoord, float alphaThreshold) {
    // Sample texture at the given coordinate
    vec4 texColor = texture(tex, texCoord);
    
    // Discard fragment if alpha is below threshold
    if (texColor.a < alphaThreshold) {
        discard;
    }
}

/**
 * Determines the alpha threshold based on block type.
 * 
 * Different block types have different alpha requirements:
 * - Opaque blocks: no alpha testing needed (threshold = 0.0)
 * - Transparent blocks (leaves, glass): threshold = 0.5
 * - Semi-transparent blocks (water): threshold = 0.1
 * 
 * Input: color - vertex color (used to detect block type)
 * Output: alpha threshold value
 * 
 * Validates: Requirement 5 (Cascaded Shadow Mapping)
 */
float getAlphaThreshold(vec4 color) {
    // Detect block type based on vertex color
    // This is a heuristic - different resource packs may have different colors
    
    // Check if this is a transparent block
    // Leaves typically have greenish colors
    float greenDominance = color.g - max(color.r, color.b);
    if (greenDominance > 0.1) {
        // Likely leaves or vegetation - use moderate threshold
        return 0.5;
    }
    
    // Check if this is water or semi-transparent
    // Water typically has bluish colors
    float blueDominance = color.b - max(color.r, color.g);
    if (blueDominance > 0.1) {
        // Likely water - use low threshold
        return 0.1;
    }
    
    // Default: opaque block - no alpha testing needed
    return 0.0;
}

// ============================================================================
// DEPTH BIAS FUNCTIONS
// ============================================================================

/**
 * Calculates adaptive depth bias based on surface normal and light direction.
 * 
 * Depth bias prevents shadow acne (self-shadowing artifacts) and peter-panning
 * (shadows detaching from objects). The bias is adaptive based on the angle
 * between the surface normal and light direction.
 * 
 * Input: normal - surface normal (world space)
 *        lightDirection - direction to light source (world space)
 * Output: adaptive depth bias value
 * 
 * Validates: Requirement 5 (Cascaded Shadow Mapping)
 */
float calculateAdaptiveDepthBias(vec3 normal, vec3 lightDirection) {
    // Calculate the angle between normal and light direction
    float cosAngle = max(dot(normal, lightDirection), 0.0);
    
    // Adaptive bias: larger bias for grazing angles
    // Use SHADOW_BIAS as base, scale by (1 - cosAngle) for angle-dependent adjustment
    float baseBias = SHADOW_BIAS;
    float adaptiveBias = baseBias * (1.0 - cosAngle);
    
    // Clamp bias to reasonable range to prevent over-correction
    return clamp(adaptiveBias, baseBias * 0.5, baseBias * 2.0);
}

/**
 * Applies depth bias to the fragment depth.
 * 
 * This function modifies the fragment depth to apply the calculated bias.
 * The bias is applied in normalized device coordinate (NDC) space.
 * 
 * Input: depth - original fragment depth in NDC space [-1, 1]
 *        bias - depth bias value
 * Output: biased depth value
 * 
 * Validates: Requirement 5 (Cascaded Shadow Mapping)
 */
float applyDepthBias(float depth, float bias) {
    // Apply bias in NDC space
    // Bias is typically small (0.03-0.05) to prevent over-correction
    return depth + bias;
}

// ============================================================================
// MAIN FRAGMENT SHADER
// ============================================================================

void main() {
    // Perform alpha testing to discard transparent pixels
    float alphaThreshold = getAlphaThreshold(vColor);
    performAlphaTesting(vTexCoord, alphaThreshold);
    
    // Calculate light direction (sun direction)
    // For shadow mapping, we typically use the sun direction
    // This is a simplified version - in a full implementation, this would come from a uniform
    vec3 lightDirection = normalize(vec3(0.5, 1.0, 0.5));
    
    // Calculate adaptive depth bias
    float depthBias = calculateAdaptiveDepthBias(vNormal, lightDirection);
    
    // Apply depth bias to fragment depth
    // Note: gl_FragDepth is automatically written to the shadow map
    // We modify it here to apply the bias
    gl_FragDepth = vShadowCoord.z + depthBias * 0.001; // Scale bias for NDC space
    
    // Clamp depth to valid range [0.0, 1.0]
    gl_FragDepth = clamp(gl_FragDepth, 0.0, 1.0);
    
    // Fragment shader output is implicit - depth is written to shadow map
    // No explicit color output needed for shadow pass
}
