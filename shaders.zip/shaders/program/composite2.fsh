/*
 * BlendHer Shader - Bloom Horizontal Blur Pass
 * 
 * This fragment shader implements the horizontal pass of a separable Gaussian blur
 * for bloom effect. Separable blur is more efficient than 2D blur because it
 * reduces the number of samples from O(n²) to O(2n).
 * 
 * Pipeline:
 * 1. Read TAA-resolved color (colortex0)
 * 2. Apply separable Gaussian blur horizontally
 * 3. Adjust bloom intensity based on blend factor
 * 4. Output horizontally blurred bloom
 * 
 * Reference: Requirement 15 (Performance Targets)
 * Compatible with: GLSL 460 core, Iris 1.8.5+, OptiFine
 */

#version 460 core

// ============================================================================
// INCLUDE FILES
// ============================================================================
#include "/lib/settings.glsl"
#include "/lib/uniforms.glsl"
#include "/lib/utils.glsl"
#include "/lib/blendstate.glsl"

// ============================================================================
// INPUT/OUTPUT
// ============================================================================

// Input from vertex shader
in vec2 texCoord;

// Input textures
uniform sampler2D colortex0;  // TAA-resolved color (from composite1.fsh)

// Output
layout(location = 0) out vec4 outColor;

// ============================================================================
// GAUSSIAN BLUR KERNEL
// ============================================================================

// Gaussian blur kernel weights for 7-tap filter
// These weights are pre-calculated for a Gaussian distribution with σ ≈ 1.0
const float kernel[7] = float[](
    0.0625,   // 1/16
    0.125,    // 2/16
    0.1875,   // 3/16
    0.25,     // 4/16 (center)
    0.1875,   // 3/16
    0.125,    // 2/16
    0.0625    // 1/16
);

// Offsets for sampling (in texture coordinates)
const int offsets[7] = int[](
    -3, -2, -1, 0, 1, 2, 3
);

// ============================================================================
// HELPER FUNCTIONS
// ============================================================================

/**
 * Calculate bloom intensity based on blend factor
 * 
 * Bloom intensity varies with blend factor:
 * - BSL (blend factor 1.0): bloom intensity = 0.8 (vibrant)
 * - Spooklementary (blend factor 0.0): bloom intensity = 0.3 (subtle)
 */
float calculateBloomIntensity(float blendFactor) {
    // Clamp blend factor to valid range
    blendFactor = clamp(blendFactor, 0.0, 1.0);
    
    // Interpolate bloom intensity based on blend factor
    // At blend factor 1.0 (BSL): intensity = 0.8
    // At blend factor 0.0 (Spooklementary): intensity = 0.3
    float intensity = mix(0.3, 0.8, blendFactor);
    
    return intensity;
}

/**
 * Extract bright pixels for bloom
 * 
 * Only pixels above a certain brightness threshold contribute to bloom.
 * This prevents the entire scene from blooming and keeps the effect localized
 * to bright areas like lights and emissive surfaces.
 */
vec3 extractBrightPixels(vec3 color, float threshold) {
    // Calculate luminance
    float luminance = dot(color, vec3(0.299, 0.587, 0.114));
    
    // If luminance is below threshold, return black (no bloom)
    if (luminance < threshold) {
        return vec3(0.0);
    }
    
    // Otherwise, return the color (will be blurred)
    return color;
}

// ============================================================================
// MAIN FRAGMENT SHADER
// ============================================================================

void main() {
    // Read current pixel color
    vec3 color = texture(colortex0, texCoord).rgb;
    
    // Extract bright pixels for bloom
    // Only pixels above 0.5 brightness contribute to bloom
    vec3 brightPixels = extractBrightPixels(color, 0.5);
    
    // Apply horizontal Gaussian blur
    vec3 blurred = vec3(0.0);
    
    // Get screen size for proper texel offset calculation
    // Use invScreenSize uniform for efficient calculation (1.0 / screenSize)
    float texelSize = invScreenSize.x;  // Horizontal texel size
    
    // Apply 7-tap Gaussian blur horizontally
    for (int i = 0; i < 7; i++) {
        // Calculate sample coordinate (horizontal offset only)
        vec2 sampleCoord = texCoord + vec2(float(offsets[i]) * texelSize, 0.0);
        
        // Clamp to screen bounds
        sampleCoord = clamp(sampleCoord, vec2(0.0), vec2(1.0));
        
        // Sample and accumulate with kernel weight
        vec3 sample = texture(colortex0, sampleCoord).rgb;
        vec3 brightSample = extractBrightPixels(sample, 0.5);
        blurred += brightSample * kernel[i];
    }
    
    // Get blend factor for bloom intensity adjustment
    float blendFactor = getBlendFactor();
    
    // Calculate bloom intensity based on blend factor
    float bloomIntensity = calculateBloomIntensity(blendFactor);
    
    // Apply bloom intensity
    blurred *= bloomIntensity;
    
    // Clamp to valid range
    blurred = clamp(blurred, vec3(0.0), vec3(1.0));
    
    // Output horizontally blurred bloom
    outColor = vec4(blurred, 1.0);
}
