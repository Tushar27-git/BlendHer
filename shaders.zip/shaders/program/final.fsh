/*
 * BlendHer Shader - Final Pass (Vignette and Gamma Correction)
 * 
 * This fragment shader applies the final post-processing effects:
 * - Vignette effect using radial distance from screen center
 * - Gamma correction (inverse gamma 1/2.2)
 * 
 * Pipeline:
 * 1. Read composite4 result (lit scene with bloom)
 * 2. Apply vignette effect using radial distance from screen center
 * 3. Scale vignette intensity based on blend factor
 * 4. Apply gamma correction (inverse gamma 1/2.2)
 * 5. Clamp output to [0.0, 1.0]
 * 6. Output display-ready color
 * 
 * Reference: Requirement 18 (Composite Pass Pipeline)
 * Compatible with: GLSL 460 core, Iris 1.8.5+, OptiFine
 */

#version 460 core

// ============================================================================
// INCLUDE FILES
// ============================================================================
#include "/lib/settings.glsl"
#include "/lib/uniforms.glsl"
#include "/lib/utils.glsl"
#include "/lib/blendstate.glsl"

// ============================================================================
// INPUT/OUTPUT
// ============================================================================

// Input from vertex shader
in vec2 texCoord;

// Input textures
uniform sampler2D colortex0;  // Composite4 result (lit scene with bloom)

// Output
layout(location = 0) out vec4 outColor;

// ============================================================================
// VIGNETTE EFFECT
// ============================================================================

/**
 * Calculate vignette effect using radial distance from screen center
 * 
 * The vignette darkens the edges of the screen, creating a cinematic effect.
 * The intensity is based on the distance from the screen center.
 */
float calculateVignette(vec2 texCoord, float intensity) {
    // Calculate distance from screen center
    // Screen center is at (0.5, 0.5)
    vec2 centerDist = texCoord - vec2(0.5);
    
    // Calculate radial distance
    float radialDist = length(centerDist) * 1.414;  // Normalize to [0, 1] at corners
    
    // Apply vignette curve using smoothstep
    // This creates a smooth falloff from center to edges
    float vignette = smoothstep(1.0, 0.0, radialDist);
    
    // Apply intensity
    vignette = mix(1.0, vignette, intensity);
    
    return vignette;
}

/**
 * Apply vignette effect to color
 * 
 * Multiplies the color by the vignette factor to darken edges.
 */
vec3 applyVignette(vec3 color, float vignetteIntensity) {
    // Calculate vignette factor
    float vignette = calculateVignette(texCoord, vignetteIntensity);
    
    // Apply vignette by multiplying color
    vec3 vignetted = color * vignette;
    
    return vignetted;
}

// ============================================================================
// GAMMA CORRECTION
// ============================================================================

/**
 * Apply gamma correction (inverse gamma 1/2.2)
 * 
 * Converts from linear color space to sRGB display space.
 * This ensures proper color reproduction on standard displays.
 */
vec3 applyGammaCorrection(vec3 color) {
    // Gamma correction: color^(1/2.2)
    // 1/2.2 ≈ 0.454545
    const float invGamma = 1.0 / 2.2;
    
    // Apply gamma correction per channel
    vec3 corrected = pow(color, vec3(invGamma));
    
    return corrected;
}

// ============================================================================
// MAIN FRAGMENT SHADER
// ============================================================================

void main() {
    // Read composite4 result (lit scene with bloom)
    vec3 sceneColor = texture(colortex0, texCoord).rgb;
    
    // Get blend factor
    float blendFactor = getBlendFactor();
    
    // Calculate vignette intensity based on blend factor
    // Requirement 18: "Scale vignette intensity based on blend factor: vignetteIntensity = mix(0.1, 0.3, blendFactor)"
    // At blend factor 1.0 (BSL): vignette intensity = 0.3 (more prominent)
    // At blend factor 0.0 (Spooklementary): vignette intensity = 0.1 (subtle)
    float vignetteIntensity = mix(0.1, 0.3, blendFactor);
    
    // Apply vignette effect
    vec3 vignetted = applyVignette(sceneColor, vignetteIntensity);
    
    // Apply gamma correction (inverse gamma 1/2.2)
    // Requirement 18: "Apply gamma correction (inverse gamma 1/2.2)"
    vec3 gammaCorrected = applyGammaCorrection(vignetted);
    
    // Clamp output to [0.0, 1.0]
    // Requirement 18: "Clamp output to [0.0, 1.0]"
    vec3 finalColor = clamp(gammaCorrected, vec3(0.0), vec3(1.0));
    
    // Output display-ready color
    outColor = vec4(finalColor, 1.0);
}
