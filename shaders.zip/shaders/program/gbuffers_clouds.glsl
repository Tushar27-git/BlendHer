/*
 * BlendHer Shader - G-Buffer Clouds Pass
 * 
 * This shader writes cloud geometry data to the G-buffers.
 * Clouds are rendered with blend factor adjustment for visual state transitions.
 * 
 * Key Points:
 * - Write colortex0 with cloud color
 * - Apply cloud rendering with blend factor adjustment
 * - Write colortex2.a = 0.0 to mark sky pixels (do NOT discard - critical for dual sky detection)
 * - Clouds transition between BSL (bright, fluffy) and Spooklementary (dark, ominous) aesthetics
 * 
 * Reference: Requirement 14 (Dual Sky Detection)
 * Compatible with: GLSL 460 core, Iris 1.8.5+, OptiFine
 */

#version 460 core

// ============================================================================
// INCLUDE FILES
// ============================================================================
#include "/lib/settings.glsl"
#include "/lib/uniforms.glsl"
#include "/lib/utils.glsl"
#include "/lib/blendstate.glsl"
#include "/lib/atmosphere.glsl"

// ============================================================================
// VERTEX SHADER
// ============================================================================

#ifdef VERTEX_SHADER

// Vertex attributes
in vec3 vaPosition;
in vec2 vaTexCoord;
in vec4 vaColor;

// Uniforms
uniform mat4 modelViewMatrix;
uniform mat4 modelViewProjectionMatrix;

// Vertex shader output
out vec3 vViewPos;
out vec4 vColor;
out vec2 vTexCoord;

void main() {
    // Transform to clip space
    gl_Position = modelViewProjectionMatrix * vec4(vaPosition, 1.0);
    
    // Pass view position for cloud rendering
    vec4 viewPos = modelViewMatrix * vec4(vaPosition, 1.0);
    vViewPos = viewPos.xyz;
    
    // Pass vertex color and texture coordinates
    vColor = vaColor;
    vTexCoord = vaTexCoord;
}

#endif // VERTEX_SHADER

// ============================================================================
// FRAGMENT SHADER
// ============================================================================

#ifdef FRAGMENT_SHADER

// Fragment shader input
in vec3 vViewPos;
in vec4 vColor;
in vec2 vTexCoord;

// Uniforms
uniform mat4 gbufferModelViewInverse;
uniform int worldTime;
uniform float rainStrength;

// Fragment shader output (G-buffers)
layout(location = 0) out vec4 outAlbedo;      // colortex0
layout(location = 1) out vec4 outNormal;      // colortex1
layout(location = 2) out vec4 outLightmap;    // colortex2
layout(location = 3) out vec4 outSpecular;    // colortex3
layout(location = 4) out vec4 outVelocity;    // colortex4

// ============================================================================
// CLOUD RENDERING FUNCTION
// ============================================================================

/**
 * Render cloud color with blend factor adjustment
 * 
 * Calculates cloud color based on blend factor, creating smooth transitions
 * between BSL's bright, fluffy clouds and Spooklementary's dark, ominous clouds.
 * 
 * The cloud color is adjusted using the atmosphere library's cloud color grading
 * function to ensure consistency with the overall visual state system.
 * 
 * Input: blendFactor - blend factor in [0.0, 1.0]
 *        vertexColor - vertex color from cloud geometry
 * Output: cloud color (RGB) with blend factor applied
 * 
 * Validates: Requirement 14 (Dual Sky Detection)
 */
vec3 renderCloudColor(float blendFactor, vec4 vertexColor) {
    // Clamp blend factor to valid range
    blendFactor = clamp(blendFactor, 0.0, 1.0);
    
    // Start with vertex color (from cloud geometry)
    vec3 cloudColor = vertexColor.rgb;
    
    // Apply cloud color grading based on blend factor
    // This function handles:
    // - Brightness adjustment (bright for BSL, dark for Spooklementary)
    // - Purple tint for Spooklementary
    // - Saturation adjustment
    cloudColor = applyCloudColorGrading(cloudColor, blendFactor);
    
    // Apply additional brightness adjustment based on blend factor
    // BSL clouds are brighter and more visible
    // Spooklementary clouds are darker and more ominous
    float brightness = calculateCloudBrightness(blendFactor);
    cloudColor *= brightness;
    
    // Clamp to ensure output is in valid range
    cloudColor = clamp(cloudColor, vec3(0.0), vec3(1.0));
    
    return cloudColor;
}

/**
 * Calculate cloud alpha with blend factor adjustment
 * 
 * Adjusts cloud transparency based on blend factor.
 * BSL clouds are more opaque, Spooklementary clouds are more transparent.
 * 
 * Input: blendFactor - blend factor in [0.0, 1.0]
 *        vertexAlpha - vertex alpha from cloud geometry
 * Output: cloud alpha in [0.0, 1.0]
 * 
 * Validates: Requirement 14 (Dual Sky Detection)
 */
float renderCloudAlpha(float blendFactor, float vertexAlpha) {
    // Clamp inputs to valid range
    blendFactor = clamp(blendFactor, 0.0, 1.0);
    vertexAlpha = clamp(vertexAlpha, 0.0, 1.0);
    
    // Calculate alpha multiplier based on blend factor
    // At blend factor 1.0 (BSL): alpha multiplier = 1.0 (full opacity)
    // At blend factor 0.0 (Spooklementary): alpha multiplier = 0.8 (slightly transparent)
    float alphaMultiplier = mix(0.8, 1.0, blendFactor);
    
    // Apply alpha multiplier to vertex alpha
    float cloudAlpha = vertexAlpha * alphaMultiplier;
    
    // Clamp to ensure output is in valid range
    return clamp(cloudAlpha, 0.0, 1.0);
}

void main() {
    // Get blend factor for cloud rendering
    float blendFactor = getBlendFactor();
    
    // ========================================================================
    // RENDER CLOUD COLOR WITH BLEND FACTOR ADJUSTMENT
    // ========================================================================
    // Clouds transition between BSL (bright, fluffy) and Spooklementary (dark, ominous)
    // based on the blend factor. This creates a cohesive visual experience.
    // 
    // Validates: Requirement 14 (Dual Sky Detection)
    vec3 cloudColor = renderCloudColor(blendFactor, vColor);
    
    // Calculate cloud alpha with blend factor adjustment
    float cloudAlpha = renderCloudAlpha(blendFactor, vColor.a);
    
    // ========================================================================
    // WRITE COLORTEX0: Cloud color (RGB) + material ID (A)
    // ========================================================================
    // Material ID = 3 for clouds (used for material classification in deferred pass)
    // Cloud color is adjusted based on blend factor for visual state transitions
    // 
    // Validates: Requirement 14 (Dual Sky Detection)
    outAlbedo = vec4(cloudColor, 3.0);
    
    // ========================================================================
    // WRITE COLORTEX1: Cloud normals (not used for clouds, but write anyway)
    // ========================================================================
    // Write neutral normals pointing up
    // Clouds don't use normal mapping, so this is just a placeholder
    outNormal = vec4(0.5, 0.5, 1.0, 0.5);
    
    // ========================================================================
    // WRITE COLORTEX2: Lightmap (RG) + material flags (BA)
    // ========================================================================
    // colortex2.a = 0.0 to mark sky pixels (do NOT discard)
    // This is CRITICAL for dual sky detection in the deferred pass
    // 
    // Requirement 14: "WHEN rendering clouds THEN THE Shader SHALL write colortex2.a = 0.0 to mark sky pixels"
    // Requirement 14: "WHEN rendering sky THEN THE Shader SHALL write colortex2.a = 0.0 to mark sky pixels (do NOT discard)"
    // 
    // The dual sky detection formula in deferred.fsh is:
    // bool isSky = (depth >= 1.0) || (texture2D(colortex2, texcoord).a < 0.5)
    // 
    // By writing colortex2.a = 0.0, we mark cloud pixels as sky pixels,
    // enabling proper sky detection and atmospheric effects application.
    // 
    // Validates: Requirement 14 (Dual Sky Detection)
    outLightmap = vec4(0.0, 0.0, 0.0, 0.0);
    
    // ========================================================================
    // WRITE COLORTEX3: Cloud specular data (not used for clouds)
    // ========================================================================
    // Write zero specular data for clouds
    // Clouds don't use PBR material properties
    outSpecular = vec4(0.0, 0.0, 0.0, 0.0);
    
    // ========================================================================
    // WRITE COLORTEX4: Velocity buffer (clouds don't move in world space)
    // ========================================================================
    // Clouds are static in world space, so velocity is zero
    // This prevents TAA artifacts on cloud geometry
    outVelocity = vec4(0.0, 0.0, 0.0, 0.0);
}

#endif // FRAGMENT_SHADER
