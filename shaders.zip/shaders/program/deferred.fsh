/*
 * BlendHer Shader - Deferred Rendering Pass (PBR Lighting)
 * 
 * This fragment shader implements the deferred rendering pass that performs
 * all PBR lighting calculations using the G-buffer data written by gbuffers passes.
 * 
 * Pipeline:
 * 1. Read G-buffer data (colortex0-4, depthtex0, shadowtex0/1)
 * 2. Detect sky pixels using dual detection
 * 3. Decode LabPBR material data
 * 4. Apply cascaded shadow sampling
 * 5. Calculate Cook-Torrance PBR lighting
 * 6. Apply blend factor interpolation
 * 7. Output lit scene color
 * 
 * Reference: Requirement 3 (Deferred Rendering), Requirement 6 (Cook-Torrance PBR)
 * Compatible with: GLSL 460 core, Iris 1.8.5+, OptiFine
 */

#version 460 core

// ============================================================================
// INCLUDE FILES
// ============================================================================
#include "/lib/settings.glsl"
#include "/lib/uniforms.glsl"
#include "/lib/utils.glsl"
#include "/lib/pbr.glsl"
#include "/lib/lighting.glsl"
#include "/lib/shadow.glsl"
#include "/lib/tonemapping.glsl"
#include "/lib/blendstate.glsl"

// ============================================================================
// INPUT/OUTPUT
// ============================================================================

// Input from vertex shader
in vec2 texCoord;

// G-buffer textures
uniform sampler2D colortex0;  // Albedo (RGB) + material ID (A)
uniform sampler2D colortex1;  // Normals (RG) + AO (B) + height (A)
uniform sampler2D colortex2;  // Lightmap (RG) + material flags (BA)
uniform sampler2D colortex3;  // Specular data (RGBA)
uniform sampler2D colortex4;  // Velocity buffer (RG)
uniform sampler2D depthtex0;  // Linear depth

// Shadow maps
uniform sampler2D shadowtex0;
uniform sampler2D shadowtex1;

// Output
layout(location = 0) out vec4 outColor;

// ============================================================================
// HELPER FUNCTIONS
// ============================================================================

/**
 * Detect if a pixel is sky using dual detection
 * 
 * Uses two methods to detect sky pixels:
 * 1. Depth >= 1.0 (far plane)
 * 2. colortex2.a < 0.5 (sky flag from gbuffers)
 * 
 * This dual detection ensures accurate sky detection even with edge cases.
 * 
 * Validates: Requirement 14 (Dual Sky Detection)
 */
bool isSkyPixel(float depth, float skyFlag) {
    // Method 1: Check if depth is at far plane
    // Sky pixels are rendered at maximum depth (1.0)
    bool depthIsSky = (depth >= 0.9999);
    
    // Method 2: Check sky flag from gbuffers (colortex2.a)
    // Non-sky pixels write colortex2.a = 1.0
    // Sky pixels write colortex2.a = 0.0
    bool flagIsSky = (skyFlag < 0.5);
    
    // Return true if either method detects sky
    return depthIsSky || flagIsSky;
}

/**
 * Decode LabPBR normal texture
 * 
 * LabPBR normal format:
 * - Red (X): Surface normal left-right orientation
 * - Green (Y): Surface normal up-down orientation (DirectX format, Y-down)
 * - Blue (Z): Material ambient occlusion
 * - Alpha: Height/displacement for parallax mapping
 * 
 * Validates: Requirement 2 (LabPBR 1.3 Material Support)
 */
vec3 decodeNormal(vec4 normalData) {
    // Extract XY from RG channels
    // Convert from [0,1] to [-1,1] range
    vec2 xy = normalData.rg * 2.0 - 1.0;
    
    // Reconstruct Z from XY using Pythagorean theorem
    // Z = sqrt(1 - X² - Y²)
    float z = sqrt(max(1.0 - dot(xy, xy), 0.0));
    
    // Return normalized normal vector
    return normalize(vec3(xy, z));
}

/**
 * Decode LabPBR specular texture
 * 
 * LabPBR specular format:
 * - Red: Perceptual smoothness (0-1, where 1 = 100% smooth)
 * - Green: F0/Reflectance (0-229) or predefined metals (230-254)
 * - Blue: Porosity (0-64) or subsurface scattering (65-255)
 * - Alpha: Emissive intensity (0-254, 255 ignored)
 * 
 * Validates: Requirement 2 (LabPBR 1.3 Material Support)
 */
struct SpecularData {
    float smoothness;
    float metallic;
    float porosity;
    float emission;
};

SpecularData decodeSpecular(vec4 specularData) {
    SpecularData spec;
    
    // Red channel: Perceptual smoothness (0-1)
    // Higher values = smoother surface = lower roughness
    spec.smoothness = specularData.r;
    
    // Green channel: F0/Reflectance or metal ID
    // 0-229: Linear F0 values (0.0-1.0 range)
    // 230-254: Predefined metals (iron, gold, aluminum, etc.)
    spec.metallic = specularData.g;
    
    // Blue channel: Porosity or SSS
    // 0-64: Porosity (water absorption)
    // 65-255: Subsurface scattering (translucency)
    spec.porosity = specularData.b;
    
    // Alpha channel: Emission intensity
    // 0-254: Emission strength (255 is ignored)
    spec.emission = specularData.a;
    
    return spec;
}

/**
 * Reconstruct world position from screen coordinates and depth
 * 
 * In deferred rendering, we need to reconstruct the world position from
 * the screen coordinates and depth value. This is done by inverting the
 * view-projection transformation.
 * 
 * Input: screenCoord - normalized screen coordinates [0, 1]
 *        depth - linear depth value [0, 1]
 * Output: world position (XYZ)
 */
vec3 reconstructWorldPos(vec2 screenCoord, float depth) {
    // Convert screen coordinates to NDC [-1, 1]
    vec2 ndc = screenCoord * 2.0 - 1.0;
    
    // Reconstruct view-space position
    // This is a simplified reconstruction; a full implementation would use
    // the inverse projection matrix for accurate results
    vec3 viewPos = vec3(ndc, depth);
    
    // For now, return a simplified world position
    // In a full implementation, this would use the inverse view-projection matrix
    return viewPos;
}

/**
 * Calculate view direction from screen coordinates
 * 
 * In deferred rendering, we reconstruct the view direction from the
 * screen coordinates and camera position.
 * 
 * Input: screenCoord - normalized screen coordinates [0, 1]
 * Output: view direction (normalized, from surface to camera)
 */
vec3 calculateViewDir(vec2 screenCoord) {
    // Convert screen coordinates to NDC [-1, 1]
    vec2 ndc = screenCoord * 2.0 - 1.0;
    
    // Create a ray direction in view space
    // This is a simplified approach; a full implementation would use
    // the inverse projection matrix for accurate results
    vec3 rayDir = normalize(vec3(ndc, 1.0));
    
    // Return the ray direction as view direction
    // (pointing from surface toward camera)
    return -rayDir;
}

/**
 * Get sun direction based on world time
 * 
 * Calculates the sun direction based on the current world time.
 * The sun moves in an arc across the sky throughout the day.
 * 
 * Input: worldTime - current world time in ticks (0-24000)
 * Output: sun direction (normalized, from surface to sun)
 */
vec3 getSunDirection(float worldTime) {
    // Normalize world time to [0, 1] range
    float normalizedTime = mod(worldTime, 24000.0) / 24000.0;
    
    // Calculate sun angle (0 = sunrise, 0.5 = sunset)
    float sunAngle = normalizedTime * 3.14159265;
    
    // Calculate sun direction
    // X: East-West (0 = East, 0.5π = South, π = West)
    // Y: Up-Down (0 = horizon, 0.5π = zenith)
    // Z: North-South (constant)
    float sunX = sin(sunAngle);
    float sunY = cos(sunAngle);
    float sunZ = 0.5;
    
    return normalize(vec3(sunX, sunY, sunZ));
}

/**
 * Sample shadow with proper distance calculation
 * 
 * Samples cascaded shadow maps using the fragment position and normal.
 * 
 * Input: worldPos - fragment position in world space
 *        normal - surface normal (world space)
 *        depth - linear depth value
 * Output: shadow factor (0.0 = fully shadowed, 1.0 = fully lit)
 */
float sampleShadowMap(vec3 worldPos, vec3 normal, float depth) {
    // Get sun direction
    float worldTime = float(worldTime);
    vec3 sunDir = getSunDirection(worldTime);
    
    // Calculate distance from camera to fragment
    vec3 cameraToFragment = worldPos - cameraPosition;
    float distance = length(cameraToFragment);
    
    // Sample cascaded shadow map
    // This function is defined in shadow.glsl
    float shadow = sampleCascadedShadowSimple(worldPos, normal, sunDir, distance);
    
    return shadow;
}

// ============================================================================
// MAIN FRAGMENT SHADER
// ============================================================================

void main() {
    // Read G-buffer data
    vec4 albedoData = texture(colortex0, texCoord);
    vec4 normalData = texture(colortex1, texCoord);
    vec4 lightmapData = texture(colortex2, texCoord);
    vec4 specularData = texture(colortex3, texCoord);
    float depth = texture(depthtex0, texCoord).r;
    
    // Extract data from G-buffers
    vec3 albedo = albedoData.rgb;
    float materialID = albedoData.a;
    
    // Decode normal and extract AO
    vec3 normal = decodeNormal(normalData);
    float ao = normalData.b;
    float height = normalData.a;
    
    // Decode lightmap data
    vec2 lightmapCoord = lightmapData.rg;
    float skyFlag = lightmapData.a;
    
    // Decode specular data
    SpecularData spec = decodeSpecular(specularData);
    
    // ========================================================================
    // SKY PIXEL DETECTION (Dual Detection)
    // ========================================================================
    // Validates: Requirement 14 (Dual Sky Detection)
    
    if (isSkyPixel(depth, skyFlag)) {
        // For sky pixels, output the albedo directly (sky color)
        // Sky pixels are rendered by gbuffers_skybasic/skytextured passes
        // and should not receive lighting calculations
        outColor = vec4(albedo, 1.0);
        return;
    }
    
    // ========================================================================
    // RECONSTRUCT WORLD POSITION AND VIEW DIRECTION
    // ========================================================================
    
    // Reconstruct world position from screen coordinates and depth
    vec3 worldPos = reconstructWorldPos(texCoord, depth);
    
    // Calculate view direction (from surface to camera)
    vec3 viewDir = calculateViewDir(texCoord);
    
    // ========================================================================
    // GET LIGHTING PARAMETERS
    // ========================================================================
    
    // Get sun direction based on world time
    float worldTimeFloat = float(worldTime);
    vec3 sunDir = getSunDirection(worldTimeFloat);
    
    // Get blend factor for visual state interpolation
    float blendFactor = getBlendFactor();
    
    // ========================================================================
    // SHADOW SAMPLING
    // ========================================================================
    // Validates: Requirement 5 (Cascaded Shadow Mapping)
    
    // Sample cascaded shadow maps
    float shadow = sampleShadowMap(worldPos, normal, depth);
    
    // ========================================================================
    // LIGHT COLORS
    // ========================================================================
    
    // Sun light color (warm, golden)
    vec3 sunColor = vec3(1.0, 0.95, 0.8);
    
    // Block light color (warm orange/yellow from torches, lava)
    vec3 blockLightColor = vec3(1.0, 0.8, 0.5);
    
    // Sky light color (cool blue from sky)
    vec3 skyLightColor = vec3(0.5, 0.7, 1.0);
    
    // ========================================================================
    // LIGHTMAP INTENSITIES
    // ========================================================================
    
    // Decode lightmap coordinates to intensities
    // Minecraft lightmap: X = block light, Y = sky light
    float blockLightIntensity = lightmapCoord.r;
    float skyLightIntensity = lightmapCoord.g;
    
    // ========================================================================
    // COOK-TORRANCE PBR LIGHTING CALCULATION
    // ========================================================================
    // Validates: Requirement 6 (Cook-Torrance PBR Lighting)
    
    // Calculate complete surface lighting with blend factor modulation
    // This function combines:
    // 1. Direct sun/moon lighting using Cook-Torrance PBR
    // 2. Block light (from torches, lava, etc.)
    // 3. Sky light (from sun/moon and sky)
    // 4. Blend factor interpolation between BSL and Spooklementary
    vec3 litColor = completeLightingBlended(
        albedo,                    // Surface albedo (diffuse color)
        normal,                    // Surface normal (world space)
        viewDir,                   // View direction (from surface to camera)
        sunDir,                    // Sun direction (from surface to sun)
        sunColor * shadow,         // Sun light with shadow applied
        blockLightIntensity,       // Block light intensity (0.0-1.0)
        skyLightIntensity,         // Sky light intensity (0.0-1.0)
        blockLightColor,           // Block light color (warm orange)
        skyLightColor,             // Sky light color (cool blue)
        spec.smoothness,           // Perceptual roughness (0.0 = smooth, 1.0 = rough)
        spec.metallic,             // Metallic factor (0.0 = dielectric, 1.0 = metal)
        blendFactor                // Blend factor (1.0 = BSL, 0.0 = Spooklementary)
    );
    
    // ========================================================================
    // AMBIENT OCCLUSION
    // ========================================================================
    
    // Apply ambient occlusion with 50% blend strength
    // This darkens crevices and corners for added depth
    litColor *= mix(1.0, ao, 0.5);
    
    // ========================================================================
    // EMISSION
    // ========================================================================
    // Validates: Requirement 2 (LabPBR 1.3 Material Support)
    
    // Apply emission if present
    // Emissive materials add their own light
    if (spec.emission > 0.0) {
        // Add emission based on albedo color and emission intensity
        litColor += albedo * spec.emission;
    }
    
    // ========================================================================
    // OUTPUT
    // ========================================================================
    
    // Output lit color with full alpha (opaque)
    outColor = vec4(litColor, 1.0);
}
