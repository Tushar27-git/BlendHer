/*
 * BlendHer Shader - G-Buffer Entities Pass
 * 
 * This shader writes entity geometry data to the G-buffers for deferred rendering.
 * Entities include mobs, players, armor stands, items, etc.
 * 
 * Unlike terrain, entities can move between frames, so velocity calculation
 * must account for object motion in addition to camera motion.
 * 
 * G-Buffer Layout:
 * - colortex0: Entity albedo (RGB) + material ID (A)
 * - colortex1: LabPBR normals (RG) + AO (B) + height (A)
 * - colortex2: Lightmap (RG) + material flags (BA) - colortex2.a = 1.0 for non-sky
 * - colortex3: LabPBR specular data (RGBA)
 * - colortex4: Velocity buffer (RG)
 * 
 * Reference: Requirement 2 (LabPBR Support), Requirement 13 (Velocity Buffer)
 * Compatible with: GLSL 460 core, Iris 1.8.5+, OptiFine
 */

#version 460 core

// ============================================================================
// INCLUDE FILES
// ============================================================================
#include "/lib/settings.glsl"
#include "/lib/uniforms.glsl"
#include "/lib/utils.glsl"
#include "/lib/material.glsl"
#include "/lib/velocity.glsl"

// ============================================================================
// VERTEX SHADER
// ============================================================================

#ifdef VERTEX_SHADER

// Vertex attributes
in vec3 vaPosition;           // Vertex position in model space
in vec2 vaTexCoord;           // Texture coordinate for albedo/normal sampling
in vec2 vaLightmapCoord;      // Lightmap coordinate (block light, sky light)
in vec3 vaNormal;             // Vertex normal
in vec4 vaTangent;            // Vertex tangent

// Uniforms
uniform mat4 modelViewMatrix;
uniform mat4 modelViewProjectionMatrix;
uniform mat4 previousModelViewMatrix;  // Previous frame model-view matrix for velocity

// Vertex shader output
out vec2 vTexCoord;
out vec2 vLightmapCoord;
out vec3 vNormal;
out vec3 vWorldPos;
out vec3 vPreviousWorldPos;

void main() {
    // Get vertex position in model space
    vec3 position = vaPosition;
    
    // Transform to clip space
    gl_Position = modelViewProjectionMatrix * vec4(position, 1.0);
    
    // Pass through texture coordinates and data
    vTexCoord = vaTexCoord;
    vLightmapCoord = vaLightmapCoord;
    vNormal = vaNormal;
    
    // Calculate world position for velocity calculation
    // World position = camera position + view space position
    vec4 viewPos = modelViewMatrix * vec4(position, 1.0);
    vWorldPos = cameraPosition + viewPos.xyz;
    
    // Calculate previous frame world position for velocity
    // This accounts for entity motion between frames
    vec4 previousViewPos = previousModelViewMatrix * vec4(position, 1.0);
    vPreviousWorldPos = cameraPosition + previousViewPos.xyz;
}

#endif // VERTEX_SHADER

// ============================================================================
// FRAGMENT SHADER
// ============================================================================

#ifdef FRAGMENT_SHADER

// Fragment shader input (from vertex shader)
in vec2 vTexCoord;
in vec2 vLightmapCoord;
in vec3 vNormal;
in vec3 vWorldPos;
in vec3 vPreviousWorldPos;

// Texture samplers
uniform sampler2D tex;           // Albedo texture
uniform sampler2D normals;       // Normal map (LabPBR format)
uniform sampler2D specular;      // Specular map (LabPBR format)

// Fragment shader output (G-buffers)
layout(location = 0) out vec4 outAlbedo;      // colortex0: albedo + material ID
layout(location = 1) out vec4 outNormal;      // colortex1: normals + AO + height
layout(location = 2) out vec4 outLightmap;    // colortex2: lightmap + flags
layout(location = 3) out vec4 outSpecular;    // colortex3: specular data
layout(location = 4) out vec4 outVelocity;    // colortex4: velocity buffer

void main() {
    // Sample entity textures
    vec4 albedoSample = texture(tex, vTexCoord);
    vec4 normalSample = texture(normals, vTexCoord);
    vec4 specularSample = texture(specular, vTexCoord);
    
    // Decode LabPBR 1.3 materials
    // Normal texture: RG = normal, B = AO, A = height
    vec3 decodedNormal = decodeNormal(normalSample);
    float ao = decodeAO(normalSample);
    float height = decodeHeight(normalSample);
    
    // Specular texture: R = smoothness, G = F0/metal, B = porosity/SSS, A = emission
    float smoothness = decodeSmoothness(specularSample);
    vec3 f0 = decodeF0(specularSample);
    vec2 porositySSS = decodePorositySSS(specularSample);
    float emission = decodeEmission(specularSample);
    
    // ========================================================================
    // WRITE COLORTEX0: Albedo (RGB) + Material ID (A)
    // ========================================================================
    // Material ID = 1 for entities (used for material classification in deferred pass)
    // Validates: Requirement 2 (LabPBR Support), Task 10.2
    outAlbedo = vec4(albedoSample.rgb, 1.0);
    
    // ========================================================================
    // WRITE COLORTEX1: LabPBR Normals (RG) + AO (B) + Height (A)
    // ========================================================================
    // Encode normal to RG channels, store AO in B, height in A
    // This is the standard LabPBR 1.3 normal texture format
    // Validates: Requirement 2 (LabPBR Support), Task 10.2
    outNormal = encodeNormalTexture(decodedNormal, ao, height);
    
    // ========================================================================
    // WRITE COLORTEX2: Lightmap (RG) + Material Flags (BA)
    // ========================================================================
    // Normalize lightmap coordinates to [0, 1] range
    // Mark as non-sky pixel by setting alpha = 1.0
    // This is used for dual sky detection in the deferred pass
    // Validates: Requirement 14 (Dual Sky Detection), Task 10.2
    vec2 normalizedLightmap = normalizeLightmap(vLightmapCoord);
    outLightmap = vec4(normalizedLightmap, 0.0, 1.0);
    
    // ========================================================================
    // WRITE COLORTEX3: LabPBR Specular Data (RGBA)
    // ========================================================================
    // Encode smoothness, F0, porosity/SSS, and emission
    // This is the standard LabPBR 1.3 specular texture format
    // Validates: Requirement 2 (LabPBR Support), Task 10.2
    outSpecular = encodeSpecularTexture(smoothness, f0.r, porositySSS.x, emission);
    
    // ========================================================================
    // WRITE COLORTEX4: Velocity Buffer (RG)
    // ========================================================================
    // Calculate velocity for TAA reprojection
    // For entities (moving geometry), velocity includes both camera and object motion
    // Validates: Requirement 13 (Velocity Buffer for TAA), Task 10.2
    
    // Project current world position to screen space
    vec4 currentViewPos = viewMatrix * vec4(vWorldPos, 1.0);
    vec4 currentScreenPos = projectionMatrix * currentViewPos;
    currentScreenPos /= currentScreenPos.w;
    
    // Project previous world position to previous frame screen space
    vec4 previousViewPos = previousViewMatrix * vec4(vPreviousWorldPos, 1.0);
    vec4 previousScreenPos = projectionMatrix * previousViewPos;
    previousScreenPos /= previousScreenPos.w;
    
    // Calculate velocity as (current - previous) in screen space
    vec2 velocity = (currentScreenPos.xy - previousScreenPos.xy) / max(frameTime, 0.001);
    
    // Clamp velocity to prevent excessive reprojection
    // Maximum velocity: 0.1 screen space per frame (10% of screen)
    float velocityMagnitude = length(velocity);
    if (velocityMagnitude > 0.1) {
        velocity = normalize(velocity) * 0.1;
    }
    
    // Encode and write velocity to colortex4
    outVelocity = writeVelocityBufferDefault(velocity);
}

#endif // FRAGMENT_SHADER
