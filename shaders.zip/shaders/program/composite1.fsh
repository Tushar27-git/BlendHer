/*
 * BlendHer Shader - Temporal Anti-Aliasing Resolve Pass (composite1.fsh)
 * 
 * This fragment shader implements the TAA resolve pass that performs temporal
 * accumulation using the velocity buffer for frame reprojection.
 * 
 * Pipeline:
 * 1. Read current frame color and velocity buffer
 * 2. Reproject previous frame using velocity
 * 3. Detect disocclusions and reset history
 * 4. Accumulate temporal samples (8-16 history)
 * 5. Apply blue noise jitter for smooth convergence
 * 6. Output TAA-resolved color
 * 
 * Reference: Requirement 4 (Temporal Anti-Aliasing)
 * Compatible with: GLSL 460 core, Iris 1.8.5+, OptiFine
 */

#version 460 core

// ============================================================================
// INCLUDE FILES
// ============================================================================
#include "/lib/settings.glsl"
#include "/lib/uniforms.glsl"
#include "/lib/utils.glsl"
#include "/lib/taa.glsl"

// ============================================================================
// INPUT/OUTPUT
// ============================================================================

// Input from vertex shader
in vec2 texCoord;

// Input textures
uniform sampler2D colortex0;  // Current frame color (from composite.fsh)
uniform sampler2D colortex4;  // Velocity buffer (RG)
uniform sampler2D colortex5;  // Previous frame color (history buffer)
uniform sampler2D depthtex0;  // Current frame depth
uniform sampler2D depthtex1;  // Previous frame depth

// Output
layout(location = 0) out vec4 outColor;

// ============================================================================
// MAIN FRAGMENT SHADER
// ============================================================================

void main() {
    // Step 1: Read current frame data
    // Requirement 4: "WHEN TAA is enabled THEN THE Shader SHALL read current frame color from colortex0"
    vec3 currentColor = texture(colortex0, texCoord).rgb;
    
    // Requirement 4: "WHEN TAA is enabled THEN THE Shader SHALL read velocity buffer (colortex4) for frame reprojection"
    vec2 velocity = texture(colortex4, texCoord).rg;
    
    // Read current frame depth
    float currentDepth = texture(depthtex0, texCoord).r;
    
    // Step 2: Clamp velocity to prevent excessive reprojection
    // Requirement 4: "WHEN calculating velocity THEN THE Shader SHALL clamp values to prevent excessive reprojection"
    velocity = clampVelocity(velocity, TAA_VELOCITY_MAX);
    
    // Step 3: Reproject to previous frame using velocity
    // Requirement 4: "WHEN TAA is enabled THEN THE Shader SHALL reproject previous frame using velocity"
    vec2 reprojectedCoord = reprojectVelocity(texCoord, velocity);
    
    // Step 4: Detect screen-space disocclusion (pixel moved outside screen)
    // Requirement 4: "WHEN TAA is enabled THEN THE Shader SHALL detect disocclusions and reset history appropriately"
    float screenDisocclusion = detectScreenSpaceDisocclusion(reprojectedCoord);
    
    // Step 5: Sample previous frame depth for depth-based disocclusion detection
    // Requirement 4: "WHEN TAA is enabled THEN THE Shader SHALL store previous frame depth in depthtex1"
    float prevDepth = texture(depthtex1, reprojectedCoord).r;
    
    // Detect depth-based disocclusion
    float depthDisocclusion = detectDisocclusion(currentDepth, prevDepth, TAA_DISOCCLUSION_THRESHOLD);
    
    // Combine both disocclusion signals
    float totalDisocclusion = max(screenDisocclusion, depthDisocclusion);
    
    // Step 6: Sample previous frame color (history)
    // Only sample if within screen bounds and not disoccluded
    vec3 historyColor = vec3(0.0);
    if (screenDisocclusion < 0.5) {
        historyColor = texture(colortex5, reprojectedCoord).rgb;
    }
    
    // Step 7: Calculate blend weight based on motion and disocclusion
    // Requirement 4: "WHEN TAA is enabled THEN THE Shader SHALL apply temporal accumulation with 8-16 sample history"
    float velocityMagnitude = length(velocity);
    float blendWeight = calculateBlendWeight(velocityMagnitude, totalDisocclusion);
    
    // Step 8: Accumulate temporal samples
    // Requirement 4: "WHEN TAA is enabled THEN THE Shader SHALL apply temporal accumulation with 8-16 sample history"
    vec3 accumulatedColor = accumulateTemporalSample(currentColor, historyColor, blendWeight);
    
    // Step 9: Apply blue noise jitter for smooth convergence
    // Requirement 4: "WHEN TAA is enabled THEN THE Shader SHALL use low-discrepancy blue noise for jitter patterns"
    #ifdef TAA_BLUE_NOISE_JITTER
    vec2 jitter = generateBlueNoiseJitter(gl_FragCoord.xy, frameCounter);
    
    // Apply jitter to texture coordinate for subpixel sampling
    // This helps with convergence by sampling different subpixel positions each frame
    vec2 jitteredTexCoord = texCoord + jitter / screenSize;
    
    // Sample current color at jittered position for additional convergence
    vec3 jitteredColor = texture(colortex0, jitteredTexCoord).rgb;
    
    // Blend jittered sample with accumulated result (very subtle)
    accumulatedColor = mix(accumulatedColor, jitteredColor, 0.05);
    #endif
    
    // Step 10: Clamp to valid range to prevent artifacts
    accumulatedColor = clamp(accumulatedColor, vec3(0.0), vec3(1.0));
    
    // Step 11: Validate output for NaN/Inf values
    accumulatedColor = validateTAAOutput(accumulatedColor, currentColor);
    
    // Step 12: Output TAA-resolved color
    // Requirement 4: "WHEN TAA is enabled THEN THE Shader SHALL output TAA-resolved color"
    outColor = vec4(accumulatedColor, 1.0);
}
