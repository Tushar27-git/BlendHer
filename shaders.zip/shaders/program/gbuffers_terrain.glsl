/*
 * BlendHer Shader - G-Buffer Terrain Pass
 * 
 * This shader writes terrain geometry data to the G-buffers for deferred rendering.
 * It handles:
 * - LabPBR 1.3 material decoding (normal, specular, AO, height)
 * - Lightmap encoding (block light, sky light)
 * - Velocity buffer calculation for TAA
 * - Vertex waving for vegetation (grass, leaves, crops)
 * - Proper G-buffer layout for deferred rendering
 * 
 * G-Buffer Layout:
 * - colortex0: Terrain albedo (RGB) + material ID (A)
 * - colortex1: LabPBR normals (RG) + AO (B) + height (A)
 * - colortex2: Lightmap (RG) + material flags (BA) - colortex2.a = 1.0 for non-sky
 * - colortex3: LabPBR specular data (RGBA)
 * - colortex4: Velocity buffer (RG)
 * 
 * Reference: Requirement 2 (LabPBR Support), Requirement 13 (Velocity Buffer)
 * Compatible with: GLSL 460 core, Iris 1.8.5+, OptiFine
 */

#version 460 core

// ============================================================================
// INCLUDE FILES
// ============================================================================
#include "/lib/settings.glsl"
#include "/lib/uniforms.glsl"
#include "/lib/utils.glsl"
#include "/lib/material.glsl"
#include "/lib/velocity.glsl"

// ============================================================================
// VERTEX SHADER
// ============================================================================

#ifdef VERTEX_SHADER

// Vertex attributes
in vec3 vaPosition;           // Vertex position in model space
in vec2 vaTexCoord;           // Texture coordinate for albedo/normal sampling
in vec2 vaLightmapCoord;      // Lightmap coordinate (block light, sky light)
in vec3 vaNormal;             // Vertex normal
in vec4 vaTangent;            // Vertex tangent
in vec4 vaColor;              // Vertex color (for vegetation detection)

// Uniforms
uniform mat4 modelViewMatrix;
uniform mat4 modelViewProjectionMatrix;

// Vertex shader output
out vec2 vTexCoord;
out vec2 vLightmapCoord;
out vec4 vColor;
out vec3 vNormal;
out vec3 vWorldPos;

/**
 * Detects if a vertex belongs to vegetation that should wave.
 * 
 * Vegetation detection is based on vertex color characteristics.
 * Grass and leaves typically have greenish colors.
 * 
 * Validates: Task 10.1 (Apply vertex waving for vegetation)
 */
bool isVegetation(vec4 color) {
    // Vegetation typically has dominant green channel
    // Grass: (0.5, 0.7, 0.3) - green dominant
    // Leaves: (0.4, 0.6, 0.2) - green dominant
    // Crops: (0.5, 0.6, 0.2) - green dominant
    
    float greenDominance = color.g - max(color.r, color.b);
    return greenDominance > 0.05;
}

/**
 * Applies vertex waving for vegetation.
 * 
 * Creates natural-looking wave motion using multiple frequency components.
 * Displacement is applied only to upper vertices (higher Y values).
 * 
 * Validates: Task 10.1 (Apply vertex waving for vegetation)
 */
vec3 applyVertexWaving(vec3 position, vec4 color) {
    if (!isVegetation(color)) {
        return position;
    }
    
    // Convert world time (ticks) to seconds for wave animation
    float waveTime = float(worldTime) * 0.001;
    
    // Multiple frequency components for natural-looking waves
    float wave1 = sin(position.x * 0.1 + waveTime) * 0.1;
    float wave2 = sin(position.z * 0.15 + waveTime * 0.7) * 0.08;
    float wave3 = sin((position.x + position.z) * 0.05 + waveTime * 0.5) * 0.05;
    
    // Combine waves
    float totalWave = wave1 + wave2 + wave3;
    
    // Apply displacement only to top vertices (higher Y values)
    // Clamp to [0, 1] to create smooth falloff
    float heightFactor = clamp(position.y * 0.1, 0.0, 1.0);
    
    // Displace in XZ plane (horizontal motion)
    vec3 wavedPosition = position;
    wavedPosition.x += totalWave * heightFactor;
    wavedPosition.z += totalWave * heightFactor * 0.5;
    
    return wavedPosition;
}

void main() {
    // Get vertex position in model space
    vec3 position = vaPosition;
    
    // Apply vertex waving for vegetation
    position = applyVertexWaving(position, vaColor);
    
    // Transform to clip space
    gl_Position = modelViewProjectionMatrix * vec4(position, 1.0);
    
    // Pass through texture coordinates and data
    vTexCoord = vaTexCoord;
    vLightmapCoord = vaLightmapCoord;
    vColor = vaColor;
    vNormal = vaNormal;
    
    // Calculate world position for velocity calculation
    // World position = camera position + view space position
    vec4 viewPos = modelViewMatrix * vec4(position, 1.0);
    vWorldPos = cameraPosition + viewPos.xyz;
}

#endif // VERTEX_SHADER

// ============================================================================
// FRAGMENT SHADER
// ============================================================================

#ifdef FRAGMENT_SHADER

// Fragment shader input (from vertex shader)
in vec2 vTexCoord;
in vec2 vLightmapCoord;
in vec4 vColor;
in vec3 vNormal;
in vec3 vWorldPos;

// Texture samplers
uniform sampler2D tex;           // Albedo texture
uniform sampler2D normals;       // Normal map (LabPBR format)
uniform sampler2D specular;      // Specular map (LabPBR format)

// Fragment shader output (G-buffers)
layout(location = 0) out vec4 outAlbedo;      // colortex0: albedo + material ID
layout(location = 1) out vec4 outNormal;      // colortex1: normals + AO + height
layout(location = 2) out vec4 outLightmap;    // colortex2: lightmap + flags
layout(location = 3) out vec4 outSpecular;    // colortex3: specular data
layout(location = 4) out vec4 outVelocity;    // colortex4: velocity buffer

void main() {
    // Sample terrain textures
    vec4 albedoSample = texture(tex, vTexCoord);
    vec4 normalSample = texture(normals, vTexCoord);
    vec4 specularSample = texture(specular, vTexCoord);
    
    // Decode LabPBR 1.3 materials
    // Normal texture: RG = normal, B = AO, A = height
    vec3 decodedNormal = decodeNormal(normalSample);
    float ao = decodeAO(normalSample);
    float height = decodeHeight(normalSample);
    
    // Specular texture: R = smoothness, G = F0/metal, B = porosity/SSS, A = emission
    float smoothness = decodeSmoothness(specularSample);
    vec3 f0 = decodeF0(specularSample);
    vec2 porositySSS = decodePorositySSS(specularSample);
    float emission = decodeEmission(specularSample);
    
    // ========================================================================
    // WRITE COLORTEX0: Albedo (RGB) + Material ID (A)
    // ========================================================================
    // Material ID = 0 for terrain (used for material classification in deferred pass)
    // Validates: Requirement 2 (LabPBR Support), Task 10.1
    outAlbedo = vec4(albedoSample.rgb, 0.0);
    
    // ========================================================================
    // WRITE COLORTEX1: LabPBR Normals (RG) + AO (B) + Height (A)
    // ========================================================================
    // Encode normal to RG channels, store AO in B, height in A
    // This is the standard LabPBR 1.3 normal texture format
    // Validates: Requirement 2 (LabPBR Support), Task 10.1
    outNormal = encodeNormalTexture(decodedNormal, ao, height);
    
    // ========================================================================
    // WRITE COLORTEX2: Lightmap (RG) + Material Flags (BA)
    // ========================================================================
    // Normalize lightmap coordinates to [0, 1] range
    // Mark as non-sky pixel by setting alpha = 1.0
    // This is used for dual sky detection in the deferred pass
    // Validates: Requirement 14 (Dual Sky Detection), Task 10.1
    vec2 normalizedLightmap = normalizeLightmap(vLightmapCoord);
    outLightmap = vec4(normalizedLightmap, 0.0, 1.0);
    
    // ========================================================================
    // WRITE COLORTEX3: LabPBR Specular Data (RGBA)
    // ========================================================================
    // Encode smoothness, F0, porosity/SSS, and emission
    // This is the standard LabPBR 1.3 specular texture format
    // Validates: Requirement 2 (LabPBR Support), Task 10.1
    outSpecular = encodeSpecularTexture(smoothness, f0.r, porositySSS.x, emission);
    
    // ========================================================================
    // WRITE COLORTEX4: Velocity Buffer (RG)
    // ========================================================================
    // Calculate velocity for TAA reprojection
    // For terrain (static geometry), velocity is based on camera motion only
    // Validates: Requirement 13 (Velocity Buffer for TAA), Task 10.1
    
    // For static terrain, object velocity is zero
    // Camera motion is handled by the TAA pass using the velocity buffer
    vec2 velocity = vec2(0.0);
    
    // Encode and write velocity to colortex4
    outVelocity = writeVelocityBufferDefault(velocity);
}

#endif // FRAGMENT_SHADER
