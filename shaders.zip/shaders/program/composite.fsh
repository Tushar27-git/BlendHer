/*
 * BlendHer Shader - Composite Pass (Blend Factor Application)
 * 
 * This fragment shader applies the blend factor to the deferred lighting result
 * and applies the complete tonemapping pipeline.
 * 
 * Pipeline:
 * 1. Read deferred lighting result (colortex0)
 * 2. Apply blend factor to all color calculations
 * 3. Apply tonemapping pipeline (ACES RRT → ODT → shadow crush → saturation → vibrance)
 * 4. Apply purple ambient floor with additive blending
 * 5. Output blended scene color
 * 
 * Reference: Requirement 7 (Visual State System), Requirement 8 (Advanced Tonemapping)
 * Compatible with: GLSL 460 core, Iris 1.8.5+, OptiFine
 */

#version 460 core

// ============================================================================
// INCLUDE FILES
// ============================================================================
#include "/lib/settings.glsl"
#include "/lib/uniforms.glsl"
#include "/lib/utils.glsl"
#include "/lib/tonemapping.glsl"
#include "/lib/blendstate.glsl"

// ============================================================================
// INPUT/OUTPUT
// ============================================================================

// Input from vertex shader
in vec2 texCoord;

// Input textures
uniform sampler2D colortex0;  // Deferred lighting result

// Output
layout(location = 0) out vec4 outColor;

// ============================================================================
// PURPLE AMBIENT FLOOR
// ============================================================================

/**
 * Calculate purple ambient floor intensity based on blend factor
 * 
 * The purple ambient floor is invisible at blend factor 1.0 (BSL)
 * and becomes increasingly visible as blend factor decreases (Spooklementary).
 * 
 * Intensity curve:
 * - Blend factor 1.0 (BSL): intensity = 0.0 (invisible)
 * - Blend factor 0.5: intensity ≈ 0.3
 * - Blend factor 0.0 (Spooklementary): intensity ≈ 0.6
 */
float calculatePurpleFloorIntensity(float blendFactor) {
    // Clamp blend factor to valid range
    blendFactor = clamp(blendFactor, 0.0, 1.0);
    
    // Calculate intensity using smooth curve
    // At blend factor 1.0: intensity = 0.0
    // At blend factor 0.0: intensity = 0.6
    float intensity = (1.0 - blendFactor) * 0.6;
    
    // Apply smoothstep for smoother transitions
    intensity = smoothstep(0.0, 1.0, intensity);
    
    return intensity;
}

/**
 * Apply purple ambient floor with additive blending
 * 
 * The purple floor is applied using ADDITIVE blending (not multiplicative).
 * This ensures that the effect adds to the scene without destroying visibility.
 * 
 * Purple color: RGB(0.4, 0.2, 0.6)
 * This creates an ominous, atmospheric effect without being too saturated.
 */
vec3 applyPurpleFloor(vec3 sceneColor, float blendFactor) {
    // Calculate purple floor intensity
    float intensity = calculatePurpleFloorIntensity(blendFactor);
    
    // Purple color (ominous, atmospheric)
    vec3 purpleColor = vec3(0.4, 0.2, 0.6);
    
    // Apply purple floor using additive blending
    // This adds the purple color to the scene, creating an atmospheric effect
    vec3 purpleFloor = sceneColor + (purpleColor * intensity);
    
    // Clamp to prevent overbright values
    // Requirement 11: "ensure final color never exceeds 1.0 (no overbright)"
    purpleFloor = clamp(purpleFloor, vec3(0.0), vec3(1.0));
    
    return purpleFloor;
}

// ============================================================================
// MAIN FRAGMENT SHADER
// ============================================================================

void main() {
    // Read deferred lighting result
    vec3 deferredColor = texture(colortex0, texCoord).rgb;
    
    // Get blend factor
    float blendFactor = getBlendFactor();
    
    // Apply tonemapping pipeline with blend factor modulation
    // This applies:
    // 1. ACES RRT (Reference Rendering Transform)
    // 2. ACES ODT (Output Device Transform) for sRGB
    // 3. Adaptive shadow crush based on blend factor
    // 4. Adaptive saturation adjustment (HSV-based)
    // 5. Adaptive vibrance enhancement
    vec3 tonemappedColor = completeTonemappingPipeline(deferredColor, blendFactor);
    
    // Apply purple ambient floor with additive blending
    // Requirement 11: "WHEN applying purple floor THEN THE Shader SHALL use ADDITIVE blending"
    vec3 finalColor = applyPurpleFloor(tonemappedColor, blendFactor);
    
    // Output final blended color
    outColor = vec4(finalColor, 1.0);
}
