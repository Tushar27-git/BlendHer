/*
 * BlendHer Shader - G-Buffer Sky Basic Pass
 * 
 * This shader writes basic sky geometry data to the G-buffers.
 * The sky is rendered without texture (solid color).
 * 
 * Key Points:
 * - Write colortex2.a = 0.0 to mark sky pixels (do NOT discard)
 * - Render stars using world-space coordinates
 * - Apply sky color grading based on blend factor
 * 
 * Reference: Requirement 14 (Dual Sky Detection)
 * Compatible with: GLSL 460 core, Iris 1.8.5+, OptiFine
 */

#version 460 core

// ============================================================================
// INCLUDE FILES
// ============================================================================
#include "/lib/settings.glsl"
#include "/lib/uniforms.glsl"
#include "/lib/utils.glsl"
#include "/lib/blendstate.glsl"

// ============================================================================
// VERTEX SHADER
// ============================================================================

#ifdef VERTEX_SHADER

// Vertex attributes
in vec3 vaPosition;
in vec2 vaTexCoord;
in vec4 vaColor;

// Uniforms
uniform mat4 modelViewMatrix;
uniform mat4 modelViewProjectionMatrix;
uniform mat4 gbufferModelViewInverse;

// Vertex shader output
out vec3 vViewPos;
out vec4 vColor;

void main() {
    // Transform to clip space
    gl_Position = modelViewProjectionMatrix * vec4(vaPosition, 1.0);
    
    // Pass view position for star rendering
    vec4 viewPos = modelViewMatrix * vec4(vaPosition, 1.0);
    vViewPos = viewPos.xyz;
    
    // Pass vertex color
    vColor = vaColor;
}

#endif // VERTEX_SHADER

// ============================================================================
// FRAGMENT SHADER
// ============================================================================

#ifdef FRAGMENT_SHADER

// Fragment shader input
in vec3 vViewPos;
in vec4 vColor;

// Uniforms
uniform mat4 gbufferModelViewInverse;
uniform int worldTime;

// Fragment shader output (G-buffers)
layout(location = 0) out vec4 outAlbedo;      // colortex0
layout(location = 1) out vec4 outNormal;      // colortex1
layout(location = 2) out vec4 outLightmap;    // colortex2
layout(location = 3) out vec4 outSpecular;    // colortex3
layout(location = 4) out vec4 outVelocity;    // colortex4

// ============================================================================
// STAR RENDERING FUNCTION
// ============================================================================

/**
 * Renders stars using world-space coordinates.
 * 
 * Stars are rendered using a procedural noise-based approach that creates
 * a fixed star field in world space. This ensures stars remain fixed in the
 * sky and don't rotate with the camera.
 * 
 * The star field is generated using multiple noise samples to create a
 * natural-looking distribution of stars with varying brightness.
 * 
 * Validates: Requirement 14 (Dual Sky Detection)
 */
float renderStars(vec3 viewPos) {
    // Convert view position to world position
    // Normalize to get direction vector
    vec3 worldPos = (gbufferModelViewInverse * vec4(viewPos * 100.0, 1.0)).xyz;
    
    // Project onto a plane for star coordinate calculation
    // Use the ratio of horizontal to vertical distance
    vec3 planeCoord = worldPos / (worldPos.y + length(worldPos.xz));
    
    // Create star coordinates from plane projection
    vec2 starCoord = planeCoord.xz * 0.5;
    
    // Generate star field using multiple noise samples
    // This creates a natural-looking distribution of stars
    float star = 1.0;
    
    // Only render stars in upper hemisphere (worldPos.y > 0)
    if (worldPos.y > 0.0) {
        // Multiple noise samples for natural star distribution
        // Use different offsets to create variation
        float noise1 = fract(sin(dot(starCoord, vec2(12.9898, 78.233))) * 43758.5453);
        float noise2 = fract(sin(dot(starCoord + 0.10, vec2(12.9898, 78.233))) * 43758.5453);
        float noise3 = fract(sin(dot(starCoord + 0.23, vec2(12.9898, 78.233))) * 43758.5453);
        
        // Combine noise samples
        star = noise1 * noise2 * noise3;
        
        // Threshold to create discrete stars (not continuous noise)
        // Clamp to create bright point stars
        star = clamp(star - 0.8125, 0.0, 1.0);
        
        // Fade stars based on height above horizon
        float heightFade = sqrt(sqrt(max(worldPos.y, 0.0) / length(worldPos)));
        star *= heightFade * 5.0;
        
        // Fade stars based on time (moon visibility)
        // Stars are only visible at night
        float moonVisibility = clamp(dot(normalize(worldPos), vec3(0.0, 1.0, 0.0)) * 10.0 + 0.5, 0.0, 1.0);
        star *= moonVisibility;
    } else {
        star = 0.0;
    }
    
    return clamp(star, 0.0, 1.0);
}

void main() {
    // Get blend factor for sky color grading
    float blendFactor = getBlendFactor();
    
    // Calculate sky color based on blend factor
    // BSL (blend factor 1.0): bright blue sky
    // Spooklementary (blend factor 0.0): dark purple sky
    vec3 bslSkyColor = vec3(0.5, 0.7, 1.0);  // Bright blue
    vec3 spookSkyColor = vec3(0.2, 0.1, 0.3);  // Dark purple
    vec3 skyColor = mix(spookSkyColor, bslSkyColor, blendFactor);
    
    // Render stars
    float starBrightness = renderStars(vViewPos);
    vec3 starColor = vec3(1.0, 0.95, 0.9) * starBrightness;  // Warm white stars
    
    // Blend stars into sky color
    skyColor = mix(skyColor, starColor, starBrightness);
    
    // ========================================================================
    // WRITE COLORTEX0: Sky color (RGB) + material ID (A)
    // ========================================================================
    // Material ID = 2 for sky (used for material classification in deferred pass)
    // Validates: Requirement 14 (Dual Sky Detection)
    outAlbedo = vec4(skyColor, 2.0);
    
    // ========================================================================
    // WRITE COLORTEX1: Sky normals (not used for sky, but write anyway)
    // ========================================================================
    // Write neutral normals pointing up
    outNormal = vec4(0.5, 0.5, 1.0, 0.5);
    
    // ========================================================================
    // WRITE COLORTEX2: Lightmap (RG) + material flags (BA)
    // ========================================================================
    // colortex2.a = 0.0 to mark sky pixels (do NOT discard)
    // This is critical for dual sky detection in the deferred pass
    // Requirement 14: "WHEN rendering sky THEN THE Shader SHALL write colortex2.a = 0.0 to mark sky pixels (do NOT discard)"
    // Validates: Requirement 14 (Dual Sky Detection)
    outLightmap = vec4(0.0, 0.0, 0.0, 0.0);
    
    // ========================================================================
    // WRITE COLORTEX3: Sky specular data (not used for sky)
    // ========================================================================
    // Write zero specular data for sky
    outSpecular = vec4(0.0, 0.0, 0.0, 0.0);
    
    // ========================================================================
    // WRITE COLORTEX4: Velocity buffer (sky doesn't move)
    // ========================================================================
    // Sky is static, so velocity is zero
    outVelocity = vec4(0.0, 0.0, 0.0, 0.0);
}

#endif // FRAGMENT_SHADER
