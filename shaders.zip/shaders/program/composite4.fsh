/*
 * BlendHer Shader - Bloom Merge and Tone Mapping Pass
 * 
 * This fragment shader merges the bloom effect with the original scene and
 * applies final tone mapping adjustments. This is the final composite pass
 * before vignette and gamma correction in final.fsh.
 * 
 * Pipeline:
 * 1. Read original scene color (colortex0) - from composite.fsh with blend factor applied
 * 2. Read bloom result (colortex1) - from composite3.fsh (vertical blur)
 * 3. Blend bloom with original using additive blending
 * 4. Apply final tone mapping adjustments (optional additional color grading)
 * 5. Ensure output is in valid [0.0, 1.0] range
 * 6. Output final lit scene with bloom
 * 
 * The bloom merge uses additive blending to add the bloom effect to the scene
 * without destroying the original colors. The bloom intensity is already
 * controlled in composite2.fsh based on the blend factor.
 * 
 * Reference: Requirement 15 (Performance Targets)
 * Reference: Requirement 18 (Composite Pass Pipeline)
 * Compatible with: GLSL 460 core, Iris 1.8.5+, OptiFine
 */

#version 460 core

// ============================================================================
// INCLUDE FILES
// ============================================================================
#include "/lib/settings.glsl"
#include "/lib/uniforms.glsl"
#include "/lib/utils.glsl"
#include "/lib/tonemapping.glsl"
#include "/lib/blendstate.glsl"

// ============================================================================
// INPUT/OUTPUT
// ============================================================================

// Input from vertex shader
in vec2 texCoord;

// Input textures
uniform sampler2D colortex0;  // Original scene color (from composite.fsh with blend factor applied)
uniform sampler2D colortex1;  // Bloom result (from composite3.fsh - vertical blur)

// Output
layout(location = 0) out vec4 outColor;

// ============================================================================
// BLOOM MERGE FUNCTIONS
// ============================================================================

/**
 * Blend bloom with original scene using additive blending
 * 
 * Additive blending adds the bloom color to the scene color:
 * result = sceneColor + bloomColor
 * 
 * This preserves the original scene colors while adding the bloom effect
 * to bright areas. The bloom intensity is already controlled in composite2.fsh
 * based on the blend factor.
 * 
 * Input: sceneColor - original scene color (from composite.fsh)
 *        bloomColor - bloom result (from composite3.fsh)
 * Output: blended color with bloom applied
 * 
 * Validates: Requirement 15 (Performance Targets)
 */
vec3 blendBloomAdditive(vec3 sceneColor, vec3 bloomColor) {
    // Clamp inputs to valid range
    sceneColor = clamp(sceneColor, vec3(0.0), vec3(1.0));
    bloomColor = clamp(bloomColor, vec3(0.0), vec3(1.0));
    
    // Additive blending: result = sceneColor + bloomColor
    vec3 bloomedColor = sceneColor + bloomColor;
    
    // Clamp to prevent overbright values
    // This ensures the final color stays in [0.0, 1.0] range
    bloomedColor = clamp(bloomedColor, vec3(0.0), vec3(1.0));
    
    return bloomedColor;
}

/**
 * Apply final tone mapping adjustments
 * 
 * This applies optional additional color grading after bloom merge.
 * In the current implementation, this is minimal since the main tonemapping
 * pipeline was already applied in composite.fsh. This function ensures
 * the color is in valid range and applies any final adjustments.
 * 
 * Input: color - bloomed scene color
 *        blendFactor - blend factor for adaptive adjustments
 * Output: final color with tone mapping adjustments
 * 
 * Validates: Requirement 15 (Performance Targets)
 */
vec3 applyFinalToneMappingAdjustments(vec3 color, float blendFactor) {
    // Clamp blend factor to valid range
    blendFactor = clamp(blendFactor, 0.0, 1.0);
    
    // Clamp color to valid range
    color = clamp(color, vec3(0.0), vec3(1.0));
    
    // Optional: Apply subtle final color grading based on blend factor
    // This can enhance the bloom effect by adjusting its intensity
    // based on the visual state (BSL vs Spooklementary)
    
    // In BSL (blend factor 1.0): bloom is more vibrant
    // In Spooklementary (blend factor 0.0): bloom is more subtle
    float bloomVibrancy = mix(0.8, 1.2, blendFactor);
    
    // Apply bloom vibrancy adjustment
    // This slightly enhances or reduces the bloom effect based on visual state
    color = color * bloomVibrancy;
    
    // Clamp again to ensure output is in valid range
    color = clamp(color, vec3(0.0), vec3(1.0));
    
    return color;
}

/**
 * Validate and clamp final color
 * 
 * Ensures the final color is valid and in the [0.0, 1.0] range.
 * Detects and handles NaN/Inf values that could cause rendering issues.
 * 
 * Input: color - color to validate
 * Output: valid color in [0.0, 1.0] range, or black if invalid
 * 
 * Validates: Requirement 15 (Performance Targets)
 */
vec3 validateFinalColor(vec3 color) {
    // Check for NaN: NaN != NaN
    if (color.r != color.r || color.g != color.g || color.b != color.b) {
        return vec3(0.0); // Return black for NaN
    }
    
    // Check for Inf: Inf > 1e10
    if (abs(color.r) > 1e10 || abs(color.g) > 1e10 || abs(color.b) > 1e10) {
        return vec3(0.0); // Return black for Inf
    }
    
    // Clamp to valid range
    return clamp(color, vec3(0.0), vec3(1.0));
}

// ============================================================================
// MAIN FRAGMENT SHADER
// ============================================================================

void main() {
    // Read original scene color (from composite.fsh with blend factor applied)
    // This color already has:
    // - Deferred PBR lighting applied
    // - Blend factor interpolation applied
    // - Complete tonemapping pipeline applied (ACES RRT → ODT → shadow crush → saturation → vibrance)
    // - Purple ambient floor applied
    vec3 sceneColor = texture(colortex0, texCoord).rgb;
    
    // Read bloom result (from composite3.fsh - vertical blur)
    // This is the final bloom after:
    // - Bright pixel extraction (threshold 0.5)
    // - Horizontal Gaussian blur (7-tap kernel)
    // - Vertical Gaussian blur (7-tap kernel)
    // - Bloom intensity adjustment based on blend factor
    vec3 bloomColor = texture(colortex1, texCoord).rgb;
    
    // Blend bloom with original using additive blending
    // Requirement 15: "WHEN bloom is enabled THEN THE Shader SHALL use separable Gaussian blur"
    // This is the merge step after the separable blur passes (composite2.fsh and composite3.fsh)
    // 
    // Additive blending formula: result = sceneColor + bloomColor
    // This adds the bloom effect to bright areas without destroying the original colors
    vec3 bloomedColor = blendBloomAdditive(sceneColor, bloomColor);
    
    // Get blend factor for adaptive adjustments
    float blendFactor = getBlendFactor();
    
    // Apply final tone mapping adjustments
    // This applies optional additional color grading after bloom merge
    // In the current implementation, this applies subtle bloom vibrancy adjustment
    // based on the visual state (BSL vs Spooklementary)
    vec3 finalColor = applyFinalToneMappingAdjustments(bloomedColor, blendFactor);
    
    // Validate and clamp final color
    // Ensures the color is in valid [0.0, 1.0] range and handles NaN/Inf values
    finalColor = validateFinalColor(finalColor);
    
    // Output final lit scene with bloom
    // This color will be passed to final.fsh for vignette and gamma correction
    outColor = vec4(finalColor, 1.0);
}
