/*
 * BlendHer Shader - G-Buffer Water Pass
 * 
 * This shader writes water geometry data to the G-buffers with Gerstner wave displacement.
 * 
 * G-Buffer Layout:
 * - colortex0: Water albedo (RGB) + material ID (A)
 * - colortex1: Displaced normals (RG) + AO (B) + height (A)
 * - colortex2: Lightmap (RG) + material flags (BA) - colortex2.a = 1.0 for non-sky
 * - colortex3: Water specular data (RGBA)
 * - colortex4: Velocity buffer (RG)
 * 
 * Reference: Requirement 9 (Gerstner Wave Water), Requirement 13 (Velocity Buffer)
 * Compatible with: GLSL 460 core, Iris 1.8.5+, OptiFine
 */

#version 460 core

// ============================================================================
// INCLUDE FILES
// ============================================================================
#include "/lib/settings.glsl"
#include "/lib/uniforms.glsl"
#include "/lib/utils.glsl"
#include "/lib/water.glsl"
#include "/lib/velocity.glsl"
#include "/lib/blendstate.glsl"
#include "/lib/material.glsl"

// ============================================================================
// VERTEX SHADER
// ============================================================================

#ifdef VERTEX_SHADER

// Vertex attributes
in vec3 vaPosition;           // Vertex position in model space
in vec2 vaTexCoord;           // Texture coordinate
in vec2 vaLightmapCoord;      // Lightmap coordinate
in vec3 vaNormal;             // Vertex normal
in vec4 vaTangent;            // Vertex tangent

// Uniforms
uniform mat4 modelViewMatrix;
uniform mat4 modelViewProjectionMatrix;

// Varyings (passed to fragment shader)
out vec3 fsPosition;
out vec2 fsTexCoord;
out vec2 fsLightmapCoord;
out vec3 fsNormal;
out vec4 fsTangent;

void main() {
    // Pass data to fragment shader
    fsPosition = vaPosition;
    fsTexCoord = vaTexCoord;
    fsLightmapCoord = vaLightmapCoord;
    fsNormal = vaNormal;
    fsTangent = vaTangent;
    
    // Transform vertex to clip space
    gl_Position = modelViewProjectionMatrix * vec4(vaPosition, 1.0);
}

#endif

// ============================================================================
// FRAGMENT SHADER
// ============================================================================

#ifdef FRAGMENT_SHADER

// Varyings (from vertex shader)
in vec3 fsPosition;
in vec2 fsTexCoord;
in vec2 fsLightmapCoord;
in vec3 fsNormal;
in vec4 fsTangent;

// Output to G-buffers
layout(location = 0) out vec4 outAlbedo;      // colortex0
layout(location = 1) out vec4 outNormal;      // colortex1
layout(location = 2) out vec4 outLightmap;    // colortex2
layout(location = 3) out vec4 outSpecular;    // colortex3
layout(location = 4) out vec4 outVelocity;    // colortex4

// ============================================================================
// HELPER FUNCTIONS
// ============================================================================

/**
 * Encodes a normal vector into RG channels for G-buffer storage.
 * 
 * Uses octahedral encoding to compress a 3D normal into 2D texture coordinates.
 * This is a standard technique for normal map compression.
 * 
 * Input: normal - normalized normal vector
 * Output: encoded normal in [0, 1] range for RG channels
 * 
 * Validates: Requirement 9 (Gerstner Wave Water)
 */
vec2 encodeNormal(vec3 normal) {
    // Normalize the normal vector
    normal = normalize(normal);
    
    // Octahedral encoding: project onto octahedron
    // Fold the normal into the positive octant
    float l1norm = abs(normal.x) + abs(normal.y) + abs(normal.z);
    vec3 octNormal = normal / l1norm;
    
    // Fold the octahedron into the plane
    vec2 encoded;
    if (octNormal.z < 0.0) {
        float temp = octNormal.x;
        octNormal.x = (1.0 - abs(octNormal.y)) * (temp >= 0.0 ? 1.0 : -1.0);
        octNormal.y = (1.0 - abs(temp)) * (octNormal.y >= 0.0 ? 1.0 : -1.0);
    }
    
    // Convert from [-1, 1] to [0, 1]
    encoded = octNormal.xy * 0.5 + 0.5;
    
    return encoded;
}

/**
 * Decodes a normal vector from RG channels.
 * 
 * Inverse of encodeNormal using octahedral decoding.
 * 
 * Input: encoded - encoded normal in [0, 1] range
 * Output: decoded normal vector (normalized)
 * 
 * Validates: Requirement 9 (Gerstner Wave Water)
 */
vec3 decodeNormal(vec2 encoded) {
    // Convert from [0, 1] to [-1, 1]
    vec2 octNormal = encoded * 2.0 - 1.0;
    
    // Reconstruct the 3D normal
    vec3 normal = vec3(octNormal.x, octNormal.y, 1.0 - abs(octNormal.x) - abs(octNormal.y));
    
    // Unfold the octahedron
    if (normal.z < 0.0) {
        float temp = normal.x;
        normal.x = (1.0 - abs(normal.y)) * (temp >= 0.0 ? 1.0 : -1.0);
        normal.y = (1.0 - abs(temp)) * (normal.y >= 0.0 ? 1.0 : -1.0);
    }
    
    return normalize(normal);
}

/**
 * Applies 3D displacement normal map to water surface.
 * 
 * Combines the Gerstner wave normal with a detail normal map
 * for additional surface complexity.
 * 
 * Input: baseNormal - base normal from Gerstner waves
 *        texCoord - texture coordinate for normal map sampling
 *        time - animation time
 * Output: combined normal with detail
 * 
 * Validates: Requirement 9 (Gerstner Wave Water)
 */
vec3 applyDisplacementNormalMap(vec3 baseNormal, vec2 texCoord, float time) {
    // Create animated detail normal map using procedural noise
    // This simulates a 3D displacement normal map without requiring a texture
    
    // Animate texture coordinates over time
    vec2 animatedCoord = texCoord + time * 0.05;
    
    // Create detail normal using sine waves at different frequencies
    // This creates a ripple pattern on the water surface
    float detailX = sin(animatedCoord.x * 10.0 + time) * 0.1;
    float detailY = sin(animatedCoord.y * 10.0 + time * 0.7) * 0.1;
    
    // Create detail normal vector
    vec3 detailNormal = normalize(vec3(detailX, 0.1, detailY));
    
    // Blend base normal with detail normal
    // Use a simple blend to combine the two normals
    vec3 combinedNormal = normalize(baseNormal + detailNormal * 0.3);
    
    return combinedNormal;
}

// ============================================================================
// MAIN FRAGMENT SHADER
// ============================================================================

void main() {
    // Get blend factor for water color grading
    float blendFactor = getBlendFactor();
    
    // Calculate water color based on blend factor
    // BSL (blend factor 1.0): bright blue water
    // Spooklementary (blend factor 0.0): dark murky water
    // Requirement 9: "WHEN rendering water THEN THE Shader SHALL apply water-specific color grading based on blend factor"
    vec3 bslWaterColor = vec3(0.2, 0.5, 0.8);  // Bright blue
    vec3 spookWaterColor = vec3(0.1, 0.15, 0.2);  // Dark murky
    vec3 waterColor = mix(spookWaterColor, bslWaterColor, blendFactor);
    
    // Apply Gerstner wave displacement
    // Requirement 9: "WHEN rendering water THEN THE Shader SHALL apply Gerstner wave displacement with 4-8 frequency components"
    // Requirement 9: "WHEN calculating displacement THEN THE Shader SHALL use vertical displacement only (world-space Y-axis)"
    vec3 displacedPos = applyGerstnerWaves(fsPosition);
    
    // Calculate displaced normals from wave displacement
    // Requirement 9: "WHEN calculating displacement THEN THE Shader SHALL reconstruct normals from displacement gradient"
    vec3 displacedNormal = calculateWaveNormals(fsPosition, displacedPos);
    
    // Apply 3D displacement normal map for surface detail
    // Requirement 9: "WHEN rendering water THEN THE Shader SHALL apply 3D displacement normal map"
    displacedNormal = applyDisplacementNormalMap(displacedNormal, fsTexCoord, float(worldTime) * 0.05);
    
    // Encode normal for G-buffer (RG channels)
    vec2 encodedNormal = encodeNormal(displacedNormal);
    
    // Normalize lightmap coordinates
    vec2 normalizedLightmap = normalizeLightmap(fsLightmapCoord);
    
    // ========================================================================
    // Write G-Buffer Data
    // ========================================================================
    
    // Write colortex0: Water albedo (RGB) + material ID (A)
    // Requirement 9: "WHEN rendering water THEN THE Shader SHALL write colortex0 with water albedo"
    // Material ID = 3 for water (used in deferred pass for material identification)
    outAlbedo = vec4(waterColor, 3.0);
    
    // Write colortex1: Displaced normals (RG) + AO (B) + height (A)
    // Requirement 9: "WHEN rendering water THEN THE Shader SHALL write colortex1 with displaced normals"
    // AO = 1.0 (water has no ambient occlusion)
    // Height = 0.5 (neutral height for water surface)
    outNormal = vec4(encodedNormal, 1.0, 0.5);
    
    // Write colortex2: Lightmap (RG) + material flags (BA)
    // Requirement 14: "WHEN rendering terrain THEN THE Shader SHALL write colortex2.a = 1.0 to mark non-sky pixels"
    // colortex2.a = 1.0 marks this as a non-sky pixel (water is not sky)
    outLightmap = vec4(normalizedLightmap, 0.0, 1.0);
    
    // Write colortex3: Water specular data (RGBA)
    // Requirement 9: "WHEN rendering water THEN THE Shader SHALL write colortex3 with water specular data"
    // Water is highly reflective and smooth (like glass)
    // Format: smoothness (R), F0/metallic (G), porosity (B), emission (A)
    vec4 waterSpecular = vec4(
        0.95,  // High smoothness (very smooth water surface)
        0.04,  // Low F0 (dielectric, not metallic)
        0.0,   // No porosity (water is not porous)
        0.0    // No emission (water doesn't emit light)
    );
    outSpecular = waterSpecular;
    
    // Write colortex4: Velocity buffer (RG)
    // Requirement 13: "WHEN rendering THEN THE Shader SHALL write velocity data to colortex4 (RG channels)"
    // Requirement 9: "WHEN rendering water THEN THE Shader SHALL write colortex4 with velocity"
    // For water, velocity is calculated from the displaced position
    vec2 velocity = calculateVelocity(displacedPos);
    
    // Encode velocity into RG channels
    // Velocity is encoded as: (velocity * 0.5 + 0.5) to fit in [0, 1] range
    vec2 encodedVelocity = clamp(velocity * 0.5 + 0.5, 0.0, 1.0);
    outVelocity = vec4(encodedVelocity, 0.0, 1.0);
}

#endif
