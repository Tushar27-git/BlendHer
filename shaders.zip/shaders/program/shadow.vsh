/*
 * BlendHer Shader - Shadow Vertex Shader
 * 
 * This shader transforms vertices to shadow space for cascaded shadow map rendering.
 * It handles:
 * - Vertex transformation to shadow space for each cascade
 * - Vertex waving for vegetation (grass, leaves, crops)
 * - Proper depth calculation for shadow mapping
 * 
 * Compatible with: GLSL 460 core, Iris 1.8.5+, OptiFine
 * References: Requirement 5 (Cascaded Shadow Mapping)
 */

#version 460 core

// ============================================================================
// VERTEX ATTRIBUTES
// ============================================================================

// Vertex position in model space
in vec3 vaPosition;

// Vertex texture coordinate (for alpha testing)
in vec2 vaTexCoord;

// Vertex color (for alpha blending)
in vec4 vaColor;

// Vertex normal (for waving calculations)
in vec3 vaNormal;

// ============================================================================
// UNIFORMS
// ============================================================================

// Include modern uniforms
#include "/lib/uniforms.glsl"
#include "/lib/settings.glsl"

// Model-view matrix (transforms from model space to view space)
uniform mat4 modelViewMatrix;

// Model-view-projection matrix (transforms from model space to clip space)
uniform mat4 modelViewProjectionMatrix;

// Shadow model-view matrix (transforms from world space to shadow view space)
uniform mat4 shadowModelView;

// Shadow projection matrix (transforms from shadow view space to shadow clip space)
uniform mat4 shadowProjection;

// ============================================================================
// VERTEX SHADER OUTPUT
// ============================================================================

// Shadow map coordinate (for depth comparison in fragment shader)
out vec3 vShadowCoord;

// Texture coordinate (for alpha testing in fragment shader)
out vec2 vTexCoord;

// Vertex color (for alpha blending in fragment shader)
out vec4 vColor;

// Vertex normal (for adaptive depth bias in fragment shader)
out vec3 vNormal;

// ============================================================================
// VERTEX WAVING FUNCTIONS
// ============================================================================

/**
 * Applies vertex waving to vegetation (grass, leaves, crops).
 * 
 * This function displaces vertices based on their position and time to create
 * a natural waving effect for vegetation. The displacement is applied in the
 * XZ plane (horizontal) to simulate wind.
 * 
 * Input: position - vertex position in world space
 *        normal - vertex normal
 *        color - vertex color (used to detect vegetation)
 * Output: displaced position in world space
 * 
 * Validates: Requirement 5 (Cascaded Shadow Mapping)
 */
vec3 applyVertexWaving(vec3 position, vec3 normal, vec4 color) {
    // Only apply waving to vegetation (detected by color or normal)
    // Vegetation typically has specific color values or normals
    
    // Calculate wave displacement based on position and time
    float waveTime = float(worldTime) * 0.001; // Convert ticks to seconds
    
    // Multiple frequency components for natural-looking waves
    float wave1 = sin(position.x * 0.1 + waveTime) * 0.1;
    float wave2 = sin(position.z * 0.15 + waveTime * 0.7) * 0.08;
    float wave3 = sin((position.x + position.z) * 0.05 + waveTime * 0.5) * 0.05;
    
    // Combine waves
    float totalWave = wave1 + wave2 + wave3;
    
    // Apply displacement only to top vertices (higher Y values)
    // This creates a natural bending effect
    float heightFactor = clamp(position.y * 0.1, 0.0, 1.0);
    
    // Displace in XZ plane (horizontal)
    vec3 displaced = position;
    displaced.x += totalWave * heightFactor;
    displaced.z += totalWave * heightFactor * 0.5;
    
    return displaced;
}

/**
 * Detects if a vertex belongs to vegetation that should wave.
 * 
 * Vegetation detection is based on vertex color and normal characteristics.
 * Different block types have different color signatures.
 * 
 * Input: color - vertex color
 *        normal - vertex normal
 * Output: true if vertex is vegetation, false otherwise
 */
bool isVegetation(vec4 color, vec3 normal) {
    // Vegetation typically has specific color ranges
    // Grass: greenish colors
    // Leaves: green colors
    // Crops: green/brown colors
    
    // Simple heuristic: if green channel is dominant, likely vegetation
    float greenDominance = color.g - max(color.r, color.b);
    
    return greenDominance > 0.1;
}

// ============================================================================
// MAIN VERTEX SHADER
// ============================================================================

void main() {
    // Get vertex position in world space
    vec3 worldPos = (modelViewMatrix * vec4(vaPosition, 1.0)).xyz;
    
    // Apply vertex waving for vegetation
    if (isVegetation(vaColor, vaNormal)) {
        worldPos = applyVertexWaving(worldPos, vaNormal, vaColor);
    }
    
    // Transform to shadow view space
    vec4 shadowViewPos = shadowModelView * vec4(worldPos, 1.0);
    
    // Transform to shadow clip space
    vec4 shadowClipPos = shadowProjection * shadowViewPos;
    
    // Output shadow clip position
    gl_Position = shadowClipPos;
    
    // Calculate shadow map coordinate (NDC to texture space)
    // NDC coordinates are in [-1, 1], convert to [0, 1] for texture sampling
    vec3 shadowNDC = shadowClipPos.xyz / shadowClipPos.w;
    vShadowCoord = shadowNDC * 0.5 + 0.5;
    
    // Pass through texture coordinate for alpha testing
    vTexCoord = vaTexCoord;
    
    // Pass through vertex color for alpha blending
    vColor = vaColor;
    
    // Pass through vertex normal for adaptive depth bias
    // Transform normal to world space
    vNormal = normalize((modelViewMatrix * vec4(vaNormal, 0.0)).xyz);
}
