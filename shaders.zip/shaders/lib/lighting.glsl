/*
 * BlendHer Shader - PBR Lighting Library
 * 
 * This library provides forward lighting calculations for the deferred rendering pass:
 * - Forward lighting calculation using Cook-Torrance PBR model
 * - Blend factor interpolation between BSL and Spooklementary lighting
 * - Block light and sky light application with LabPBR support
 * - Metallic surface handling (albedo as F0 tint)
 * 
 * The lighting system combines PBR calculations with the blend system to create
 * smooth transitions between vibrant daylight (BSL) and atmospheric darkness
 * (Spooklementary) based on time of day and environmental conditions.
 * 
 * Reference: Requirement 6 (Cook-Torrance PBR), Requirement 2 (LabPBR Support)
 * Compatible with: GLSL 460 core, Iris 1.8.5+, OptiFine
 */

#ifndef LIGHTING_GLSL
#define LIGHTING_GLSL

// Include dependencies
#include "uniforms.glsl"
#include "utils.glsl"
#include "pbr.glsl"

// ============================================================================
// FORWARD LIGHTING CALCULATION
// ============================================================================
// Calculates direct lighting from sun/moon using Cook-Torrance PBR model.
// This is the core lighting function that combines all PBR components.

/**
 * Calculate forward lighting using Cook-Torrance PBR
 * 
 * Computes direct lighting from a single light source (sun or moon) using the
 * Cook-Torrance physically-based rendering model. This function handles all
 * aspects of PBR lighting including Fresnel, distribution, and geometry.
 * 
 * Input: albedo - surface albedo (diffuse color)
 *        normal - surface normal (normalized, world-space)
 *        viewDir - view direction (normalized, from surface to camera)
 *        lightDir - light direction (normalized, from surface to light)
 *        lightColor - light color and intensity (RGB)
 *        roughness - perceptual roughness (0.0 = smooth, 1.0 = rough)
 *        metallic - metallic factor (0.0 = dielectric, 1.0 = metal)
 *        F0 - reflectance at normal incidence (use albedo for metals, 0.04 for dielectrics)
 * Output: outgoing radiance from direct lighting
 * 
 * Validates: Requirement 6 (Cook-Torrance PBR)
 */
vec3 forwardLighting(
    vec3 albedo,
    vec3 normal,
    vec3 viewDir,
    vec3 lightDir,
    vec3 lightColor,
    float roughness,
    float metallic,
    vec3 F0
) {
    // Use the Cook-Torrance implementation from pbr.glsl
    return cookTorrance(
        albedo,
        normal,
        viewDir,
        lightDir,
        lightColor,
        roughness,
        metallic,
        F0
    );
}

/**
 * Calculate forward lighting with automatic F0 selection
 * 
 * Convenience function that automatically selects F0 based on metallic factor.
 * For metals (metallic > 0.5), uses albedo as F0 tint.
 * For dielectrics (metallic <= 0.5), uses standard dielectric F0 (0.04).
 * 
 * Input: albedo - surface albedo (diffuse color)
 *        normal - surface normal (normalized, world-space)
 *        viewDir - view direction (normalized, from surface to camera)
 *        lightDir - light direction (normalized, from surface to light)
 *        lightColor - light color and intensity (RGB)
 *        roughness - perceptual roughness (0.0 = smooth, 1.0 = rough)
 *        metallic - metallic factor (0.0 = dielectric, 1.0 = metal)
 * Output: outgoing radiance from direct lighting
 * 
 * Validates: Requirement 6 (Cook-Torrance PBR), Requirement 2 (LabPBR Support)
 */
vec3 forwardLightingAuto(
    vec3 albedo,
    vec3 normal,
    vec3 viewDir,
    vec3 lightDir,
    vec3 lightColor,
    float roughness,
    float metallic
) {
    // Select F0 based on metallic factor
    vec3 F0;
    if (metallic > 0.5) {
        // For metals, use albedo as F0 tint
        F0 = getMetallicF0(albedo);
    } else {
        // For dielectrics, use standard F0 (0.04)
        F0 = getDielectricF0();
    }
    
    // Calculate lighting with selected F0
    return forwardLighting(
        albedo,
        normal,
        viewDir,
        lightDir,
        lightColor,
        roughness,
        metallic,
        F0
    );
}

// ============================================================================
// BLEND FACTOR INTERPOLATION FOR LIGHTING
// ============================================================================
// Interpolates lighting parameters between BSL and Spooklementary based on blend factor.
// This creates smooth transitions between the two visual states.

/**
 * Interpolate light color based on blend factor
 * 
 * Blends between BSL light color (warm, golden) and Spooklementary light color
 * (cool, desaturated) based on the blend factor.
 * 
 * Input: bslLightColor - BSL light color (warm, golden)
 *        spookLightColor - Spooklementary light color (cool, desaturated)
 *        blendFactor - blend factor in [0.0, 1.0]
 *                      1.0 = BSL (vibrant), 0.0 = Spooklementary (dark)
 * Output: interpolated light color
 * 
 * Validates: Requirement 7 (Visual State System)
 */
vec3 blendLightColor(vec3 bslLightColor, vec3 spookLightColor, float blendFactor) {
    // Clamp blend factor to valid range
    blendFactor = clamp(blendFactor, 0.0, 1.0);
    
    // Linear interpolation between BSL and Spooklementary
    return mix(spookLightColor, bslLightColor, blendFactor);
}

/**
 * Interpolate light intensity based on blend factor
 * 
 * Adjusts light intensity based on the blend factor.
 * BSL (blend factor 1.0) has higher intensity for vibrant daylight.
 * Spooklementary (blend factor 0.0) has lower intensity for atmospheric darkness.
 * 
 * Input: bslIntensity - BSL light intensity (typically 1.0-1.2)
 *        spookIntensity - Spooklementary light intensity (typically 0.6-0.8)
 *        blendFactor - blend factor in [0.0, 1.0]
 * Output: interpolated light intensity
 * 
 * Validates: Requirement 7 (Visual State System)
 */
float blendLightIntensity(float bslIntensity, float spookIntensity, float blendFactor) {
    // Clamp blend factor to valid range
    blendFactor = clamp(blendFactor, 0.0, 1.0);
    
    // Linear interpolation between BSL and Spooklementary
    return mix(spookIntensity, bslIntensity, blendFactor);
}

/**
 * Interpolate roughness based on blend factor
 * 
 * Adjusts surface roughness based on the blend factor.
 * This can create subtle differences in material appearance between visual states.
 * 
 * Input: bslRoughness - BSL roughness value
 *        spookRoughness - Spooklementary roughness value
 *        blendFactor - blend factor in [0.0, 1.0]
 * Output: interpolated roughness
 * 
 * Validates: Requirement 7 (Visual State System)
 */
float blendRoughness(float bslRoughness, float spookRoughness, float blendFactor) {
    // Clamp blend factor to valid range
    blendFactor = clamp(blendFactor, 0.0, 1.0);
    
    // Linear interpolation between BSL and Spooklementary
    return mix(spookRoughness, bslRoughness, blendFactor);
}

/**
 * Interpolate specular intensity based on blend factor
 * 
 * Adjusts specular reflection intensity based on the blend factor.
 * BSL has more specular highlights for vibrant appearance.
 * Spooklementary has reduced specular for atmospheric effect.
 * 
 * Input: bslSpecular - BSL specular intensity (typically 1.0)
 *        spookSpecular - Spooklementary specular intensity (typically 0.7)
 *        blendFactor - blend factor in [0.0, 1.0]
 * Output: interpolated specular intensity
 * 
 * Validates: Requirement 7 (Visual State System)
 */
float blendSpecularIntensity(float bslSpecular, float spookSpecular, float blendFactor) {
    // Clamp blend factor to valid range
    blendFactor = clamp(blendFactor, 0.0, 1.0);
    
    // Linear interpolation between BSL and Spooklementary
    return mix(spookSpecular, bslSpecular, blendFactor);
}

// ============================================================================
// BLOCK LIGHT APPLICATION
// ============================================================================
// Applies block light (from torches, lava, etc.) to surfaces with proper
// color and intensity handling for LabPBR materials.

/**
 * Apply block light to surface
 * 
 * Adds block light contribution to the surface lighting. Block light is
 * typically warm (orange/yellow) and comes from torches, lava, and other
 * light-emitting blocks.
 * 
 * Input: baseColor - base surface color (from previous lighting calculations)
 *        blockLightIntensity - block light intensity (0.0-1.0)
 *        blockLightColor - block light color (typically warm orange/yellow)
 * Output: color with block light applied
 * 
 * Validates: Requirement 2 (LabPBR Support)
 */
vec3 applyBlockLight(vec3 baseColor, float blockLightIntensity, vec3 blockLightColor) {
    // Clamp intensity to valid range
    blockLightIntensity = clamp(blockLightIntensity, 0.0, 1.0);
    
    // Apply block light using additive blending
    // Block light adds to the base color, creating warm highlights
    vec3 blockLit = baseColor + (blockLightColor * blockLightIntensity);
    
    // Clamp to prevent overbright values
    blockLit = clamp(blockLit, vec3(0.0), vec3(1.0));
    
    return blockLit;
}

/**
 * Apply block light with blend factor modulation
 * 
 * Applies block light with intensity adjusted based on blend factor.
 * In BSL (blend factor 1.0), block light is more visible.
 * In Spooklementary (blend factor 0.0), block light is more prominent (creates atmosphere).
 * 
 * Input: baseColor - base surface color
 *        blockLightIntensity - block light intensity (0.0-1.0)
 *        blockLightColor - block light color
 *        blendFactor - blend factor in [0.0, 1.0]
 * Output: color with blend-modulated block light applied
 * 
 * Validates: Requirement 2 (LabPBR Support), Requirement 7 (Visual State System)
 */
vec3 applyBlockLightBlended(
    vec3 baseColor,
    float blockLightIntensity,
    vec3 blockLightColor,
    float blendFactor
) {
    // Clamp blend factor to valid range
    blendFactor = clamp(blendFactor, 0.0, 1.0);
    
    // Adjust block light intensity based on blend factor
    // In Spooklementary (blend factor 0.0), block light is more prominent
    // In BSL (blend factor 1.0), block light is more subtle
    float adjustedIntensity = blendLightIntensity(0.8, 1.2, blendFactor) * blockLightIntensity;
    
    // Apply block light with adjusted intensity
    return applyBlockLight(baseColor, adjustedIntensity, blockLightColor);
}

// ============================================================================
// SKY LIGHT APPLICATION
// ============================================================================
// Applies sky light (from sun/moon and sky) to surfaces with proper
// color and intensity handling for LabPBR materials.

/**
 * Apply sky light to surface
 * 
 * Adds sky light contribution to the surface lighting. Sky light is
 * typically cool (blue) and comes from the sky and sun/moon.
 * 
 * Input: baseColor - base surface color (from previous lighting calculations)
 *        skyLightIntensity - sky light intensity (0.0-1.0)
 *        skyLightColor - sky light color (typically cool blue)
 * Output: color with sky light applied
 * 
 * Validates: Requirement 2 (LabPBR Support)
 */
vec3 applySkyLight(vec3 baseColor, float skyLightIntensity, vec3 skyLightColor) {
    // Clamp intensity to valid range
    skyLightIntensity = clamp(skyLightIntensity, 0.0, 1.0);
    
    // Apply sky light using additive blending
    // Sky light adds to the base color, creating cool highlights
    vec3 skyLit = baseColor + (skyLightColor * skyLightIntensity);
    
    // Clamp to prevent overbright values
    skyLit = clamp(skyLit, vec3(0.0), vec3(1.0));
    
    return skyLit;
}

/**
 * Apply sky light with blend factor modulation
 * 
 * Applies sky light with intensity adjusted based on blend factor.
 * In BSL (blend factor 1.0), sky light is more visible (bright daylight).
 * In Spooklementary (blend factor 0.0), sky light is reduced (dark night).
 * 
 * Input: baseColor - base surface color
 *        skyLightIntensity - sky light intensity (0.0-1.0)
 *        skyLightColor - sky light color
 *        blendFactor - blend factor in [0.0, 1.0]
 * Output: color with blend-modulated sky light applied
 * 
 * Validates: Requirement 2 (LabPBR Support), Requirement 7 (Visual State System)
 */
vec3 applySkyLightBlended(
    vec3 baseColor,
    float skyLightIntensity,
    vec3 skyLightColor,
    float blendFactor
) {
    // Clamp blend factor to valid range
    blendFactor = clamp(blendFactor, 0.0, 1.0);
    
    // Adjust sky light intensity based on blend factor
    // In BSL (blend factor 1.0), sky light is more prominent
    // In Spooklementary (blend factor 0.0), sky light is reduced
    float adjustedIntensity = blendLightIntensity(0.3, 1.0, blendFactor) * skyLightIntensity;
    
    // Apply sky light with adjusted intensity
    return applySkyLight(baseColor, adjustedIntensity, skyLightColor);
}

/**
 * Apply combined block and sky light
 * 
 * Applies both block and sky light in sequence for complete lightmap lighting.
 * This is the typical use case for applying Minecraft's lightmap data.
 * 
 * Input: baseColor - base surface color
 *        blockLightIntensity - block light intensity (0.0-1.0)
 *        skyLightIntensity - sky light intensity (0.0-1.0)
 *        blockLightColor - block light color
 *        skyLightColor - sky light color
 * Output: color with both block and sky light applied
 * 
 * Validates: Requirement 2 (LabPBR Support)
 */
vec3 applyLightmapLighting(
    vec3 baseColor,
    float blockLightIntensity,
    float skyLightIntensity,
    vec3 blockLightColor,
    vec3 skyLightColor
) {
    // Apply block light first
    vec3 blockLit = applyBlockLight(baseColor, blockLightIntensity, blockLightColor);
    
    // Apply sky light second
    vec3 finalColor = applySkyLight(blockLit, skyLightIntensity, skyLightColor);
    
    return finalColor;
}

/**
 * Apply combined block and sky light with blend factor modulation
 * 
 * Applies both block and sky light with blend factor adjustment.
 * This creates smooth transitions between BSL and Spooklementary lighting.
 * 
 * Input: baseColor - base surface color
 *        blockLightIntensity - block light intensity (0.0-1.0)
 *        skyLightIntensity - sky light intensity (0.0-1.0)
 *        blockLightColor - block light color
 *        skyLightColor - sky light color
 *        blendFactor - blend factor in [0.0, 1.0]
 * Output: color with blend-modulated block and sky light applied
 * 
 * Validates: Requirement 2 (LabPBR Support), Requirement 7 (Visual State System)
 */
vec3 applyLightmapLightingBlended(
    vec3 baseColor,
    float blockLightIntensity,
    float skyLightIntensity,
    vec3 blockLightColor,
    vec3 skyLightColor,
    float blendFactor
) {
    // Apply block light with blend modulation
    vec3 blockLit = applyBlockLightBlended(
        baseColor,
        blockLightIntensity,
        blockLightColor,
        blendFactor
    );
    
    // Apply sky light with blend modulation
    vec3 finalColor = applySkyLightBlended(
        blockLit,
        skyLightIntensity,
        skyLightColor,
        blendFactor
    );
    
    return finalColor;
}

// ============================================================================
// METALLIC SURFACE HANDLING
// ============================================================================
// Handles metallic surfaces where albedo is used as F0 tint instead of diffuse.
// This is a key aspect of LabPBR material support.

/**
 * Calculate F0 for metallic surface
 * 
 * For metallic surfaces, the albedo color is used as the F0 (reflectance at
 * normal incidence) tint. This creates realistic metal rendering where the
 * metal's color affects its reflectivity.
 * 
 * Input: albedo - surface albedo (metal color)
 *        metallic - metallic factor (0.0 = dielectric, 1.0 = metal)
 * Output: F0 value for use in Cook-Torrance
 * 
 * Validates: Requirement 6 (Cook-Torrance PBR), Requirement 2 (LabPBR Support)
 */
vec3 calculateMetallicF0(vec3 albedo, float metallic) {
    // Clamp metallic to valid range
    metallic = clamp(metallic, 0.0, 1.0);
    
    // For metals, use albedo as F0 tint
    // For dielectrics, use standard F0 (0.04)
    vec3 dielectricF0 = getDielectricF0();
    vec3 metallicF0 = getMetallicF0(albedo);
    
    // Interpolate between dielectric and metallic F0 based on metallic factor
    return mix(dielectricF0, metallicF0, metallic);
}

/**
 * Apply metallic surface lighting
 * 
 * Applies Cook-Torrance lighting specifically for metallic surfaces.
 * For metals, the albedo is used as F0 tint and there is no diffuse component.
 * 
 * Input: albedo - metal color (used as F0 tint)
 *        normal - surface normal (normalized, world-space)
 *        viewDir - view direction (normalized, from surface to camera)
 *        lightDir - light direction (normalized, from surface to light)
 *        lightColor - light color and intensity (RGB)
 *        roughness - perceptual roughness (0.0 = smooth, 1.0 = rough)
 * Output: outgoing radiance from metallic surface
 * 
 * Validates: Requirement 6 (Cook-Torrance PBR), Requirement 2 (LabPBR Support)
 */
vec3 applyMetallicLighting(
    vec3 albedo,
    vec3 normal,
    vec3 viewDir,
    vec3 lightDir,
    vec3 lightColor,
    float roughness
) {
    // For metals, use albedo as F0 tint
    vec3 F0 = getMetallicF0(albedo);
    
    // Apply Cook-Torrance with metallic = 1.0 (full metal)
    return forwardLighting(
        albedo,
        normal,
        viewDir,
        lightDir,
        lightColor,
        roughness,
        1.0,  // metallic = 1.0 for full metal
        F0
    );
}

/**
 * Apply metallic surface lighting with blend factor modulation
 * 
 * Applies metallic lighting with intensity adjusted based on blend factor.
 * This creates smooth transitions between BSL and Spooklementary metal appearance.
 * 
 * Input: albedo - metal color (used as F0 tint)
 *        normal - surface normal (normalized, world-space)
 *        viewDir - view direction (normalized, from surface to camera)
 *        lightDir - light direction (normalized, from surface to light)
 *        lightColor - light color and intensity (RGB)
 *        roughness - perceptual roughness (0.0 = smooth, 1.0 = rough)
 *        blendFactor - blend factor in [0.0, 1.0]
 * Output: outgoing radiance from metallic surface with blend modulation
 * 
 * Validates: Requirement 6 (Cook-Torrance PBR), Requirement 7 (Visual State System)
 */
vec3 applyMetallicLightingBlended(
    vec3 albedo,
    vec3 normal,
    vec3 viewDir,
    vec3 lightDir,
    vec3 lightColor,
    float roughness,
    float blendFactor
) {
    // Clamp blend factor to valid range
    blendFactor = clamp(blendFactor, 0.0, 1.0);
    
    // Adjust light color based on blend factor
    vec3 bslLightColor = lightColor;
    vec3 spookLightColor = lightColor * 0.7;  // Reduce intensity for Spooklementary
    vec3 adjustedLightColor = blendLightColor(bslLightColor, spookLightColor, blendFactor);
    
    // Apply metallic lighting with adjusted light color
    return applyMetallicLighting(
        albedo,
        normal,
        viewDir,
        lightDir,
        adjustedLightColor,
        roughness
    );
}

/**
 * Blend between dielectric and metallic lighting
 * 
 * Smoothly interpolates between dielectric (non-metal) and metallic lighting
 * based on the metallic factor. This handles partially metallic surfaces.
 * 
 * Input: albedo - surface albedo
 *        normal - surface normal (normalized, world-space)
 *        viewDir - view direction (normalized, from surface to camera)
 *        lightDir - light direction (normalized, from surface to light)
 *        lightColor - light color and intensity (RGB)
 *        roughness - perceptual roughness (0.0 = smooth, 1.0 = rough)
 *        metallic - metallic factor (0.0 = dielectric, 1.0 = metal)
 * Output: outgoing radiance blended between dielectric and metallic
 * 
 * Validates: Requirement 6 (Cook-Torrance PBR), Requirement 2 (LabPBR Support)
 */
vec3 blendDielectricMetallicLighting(
    vec3 albedo,
    vec3 normal,
    vec3 viewDir,
    vec3 lightDir,
    vec3 lightColor,
    float roughness,
    float metallic
) {
    // Clamp metallic to valid range
    metallic = clamp(metallic, 0.0, 1.0);
    
    // Calculate F0 based on metallic factor
    vec3 F0 = calculateMetallicF0(albedo, metallic);
    
    // Apply Cook-Torrance with interpolated metallic factor
    return forwardLighting(
        albedo,
        normal,
        viewDir,
        lightDir,
        lightColor,
        roughness,
        metallic,
        F0
    );
}

// ============================================================================
// COMPLETE LIGHTING CALCULATION
// ============================================================================
// Combines all lighting components into a single function for convenience.

/**
 * Calculate complete surface lighting
 * 
 * Combines direct lighting (sun/moon), block light, and sky light into a
 * single comprehensive lighting calculation. This is the main function used
 * in the deferred lighting pass.
 * 
 * Input: albedo - surface albedo
 *        normal - surface normal (normalized, world-space)
 *        viewDir - view direction (normalized, from surface to camera)
 *        sunDir - sun direction (normalized, from surface to sun)
 *        sunColor - sun light color and intensity
 *        blockLightIntensity - block light intensity (0.0-1.0)
 *        skyLightIntensity - sky light intensity (0.0-1.0)
 *        blockLightColor - block light color
 *        skyLightColor - sky light color
 *        roughness - perceptual roughness (0.0 = smooth, 1.0 = rough)
 *        metallic - metallic factor (0.0 = dielectric, 1.0 = metal)
 * Output: complete surface lighting
 * 
 * Validates: Requirement 6 (Cook-Torrance PBR), Requirement 2 (LabPBR Support)
 */
vec3 completeLighting(
    vec3 albedo,
    vec3 normal,
    vec3 viewDir,
    vec3 sunDir,
    vec3 sunColor,
    float blockLightIntensity,
    float skyLightIntensity,
    vec3 blockLightColor,
    vec3 skyLightColor,
    float roughness,
    float metallic
) {
    // Calculate direct sun/moon lighting using Cook-Torrance
    vec3 directLighting = forwardLightingAuto(
        albedo,
        normal,
        viewDir,
        sunDir,
        sunColor,
        roughness,
        metallic
    );
    
    // Apply lightmap lighting (block + sky light)
    vec3 lightmapLighting = applyLightmapLighting(
        directLighting,
        blockLightIntensity,
        skyLightIntensity,
        blockLightColor,
        skyLightColor
    );
    
    return lightmapLighting;
}

/**
 * Calculate complete surface lighting with blend factor modulation
 * 
 * Combines all lighting components with blend factor adjustment for smooth
 * transitions between BSL and Spooklementary visual states.
 * 
 * Input: albedo - surface albedo
 *        normal - surface normal (normalized, world-space)
 *        viewDir - view direction (normalized, from surface to camera)
 *        sunDir - sun direction (normalized, from surface to sun)
 *        sunColor - sun light color and intensity
 *        blockLightIntensity - block light intensity (0.0-1.0)
 *        skyLightIntensity - sky light intensity (0.0-1.0)
 *        blockLightColor - block light color
 *        skyLightColor - sky light color
 *        roughness - perceptual roughness (0.0 = smooth, 1.0 = rough)
 *        metallic - metallic factor (0.0 = dielectric, 1.0 = metal)
 *        blendFactor - blend factor in [0.0, 1.0]
 * Output: complete surface lighting with blend modulation
 * 
 * Validates: Requirement 6 (Cook-Torrance PBR), Requirement 7 (Visual State System)
 */
vec3 completeLightingBlended(
    vec3 albedo,
    vec3 normal,
    vec3 viewDir,
    vec3 sunDir,
    vec3 sunColor,
    float blockLightIntensity,
    float skyLightIntensity,
    vec3 blockLightColor,
    vec3 skyLightColor,
    float roughness,
    float metallic,
    float blendFactor
) {
    // Clamp blend factor to valid range
    blendFactor = clamp(blendFactor, 0.0, 1.0);
    
    // Blend sun color based on blend factor
    vec3 bslSunColor = sunColor;
    vec3 spookSunColor = sunColor * 0.6;  // Reduce intensity for Spooklementary
    vec3 adjustedSunColor = blendLightColor(bslSunColor, spookSunColor, blendFactor);
    
    // Calculate direct sun/moon lighting with blended color
    vec3 directLighting = forwardLightingAuto(
        albedo,
        normal,
        viewDir,
        sunDir,
        adjustedSunColor,
        roughness,
        metallic
    );
    
    // Apply lightmap lighting with blend modulation
    vec3 lightmapLighting = applyLightmapLightingBlended(
        directLighting,
        blockLightIntensity,
        skyLightIntensity,
        blockLightColor,
        skyLightColor,
        blendFactor
    );
    
    return lightmapLighting;
}

#endif // LIGHTING_GLSL
