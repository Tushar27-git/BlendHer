/*
 * BlendHer Shader - PBR Library
 * Cook-Torrance Physically-Based Rendering Implementation
 * 
 * This library provides core PBR functions for the deferred lighting pass:
 * - Fresnel-Schlick approximation for F0 interpolation
 * - GGX/Trowbridge-Reitz microfacet distribution
 * - Smith's geometry function with Schlick-Beckmann
 * - Energy conservation validation
 * - Metal F0 lookup table (LabPBR 1.3 standard)
 * 
 * Reference: Requirement 6 (Cook-Torrance PBR Lighting)
 */

#ifndef PBR_GLSL
#define PBR_GLSL

// ============================================================================
// Metal F0 Lookup Table (LabPBR 1.3 Standard)
// ============================================================================
// Predefined metals (230-254) with complex refractive index (N, K) values
// These are converted to F0 (reflectance at normal incidence) for use in PBR
// Reference: LabPBR 1.3 specification

/**
 * Get F0 value for a predefined metal
 * @param metalID Metal identifier (230-237)
 * @return F0 reflectance value at normal incidence
 * 
 * Metal IDs:
 * 230: Iron (N: 2.91, 2.95, 2.58)
 * 231: Gold (N: 0.18, 0.42, 1.37)
 * 232: Aluminum (N: 1.35, 0.97, 0.62)
 * 233: Chrome (N: 3.11, 3.18, 2.32)
 * 234: Copper (N: 0.27, 0.68, 1.32)
 * 235: Lead (N: 1.91, 1.83, 1.44)
 * 236: Platinum (N: 2.38, 2.08, 1.85)
 * 237: Silver (N: 0.16, 0.15, 0.14)
 */
vec3 getMetalF0(int metalID) {
    switch(metalID) {
        case 230: return vec3(0.77, 0.78, 0.78);  // Iron
        case 231: return vec3(1.00, 0.71, 0.29);  // Gold
        case 232: return vec3(0.91, 0.92, 0.92);  // Aluminum
        case 233: return vec3(0.95, 0.93, 0.88);  // Chrome
        case 234: return vec3(0.95, 0.64, 0.54);  // Copper
        case 235: return vec3(0.66, 0.66, 0.67);  // Lead
        case 236: return vec3(0.95, 0.93, 0.88);  // Platinum
        case 237: return vec3(0.97, 0.96, 0.91);  // Silver
        default:  return vec3(0.04);              // Default dielectric
    }
}

// ============================================================================
// Fresnel-Schlick Approximation
// ============================================================================
// Approximates the Fresnel effect: how reflectivity changes with viewing angle
// Formula: F(h,v) = F0 + (1 - F0) * pow(1 - cos(h,v), 5.0)
// 
// This is more efficient than exact Fresnel calculations while maintaining
// physical plausibility. The exponent of 5.0 is empirically derived.

/**
 * Calculate Fresnel-Schlick approximation
 * @param F0 Reflectance at normal incidence (0.0-1.0)
 * @param cosTheta Cosine of angle between half-vector and view direction
 * @return Fresnel reflectance value
 */
float fresnelSchlick(float F0, float cosTheta) {
    // Clamp cosTheta to [0, 1] to prevent numerical issues
    cosTheta = clamp(cosTheta, 0.0, 1.0);
    
    // Schlick approximation: F0 + (1 - F0) * (1 - cos)^5
    float oneMinusCos = 1.0 - cosTheta;
    return F0 + (1.0 - F0) * (oneMinusCos * oneMinusCos * oneMinusCos * oneMinusCos * oneMinusCos);
}

/**
 * Calculate Fresnel-Schlick approximation for vec3 (RGB channels)
 * @param F0 Reflectance at normal incidence (RGB)
 * @param cosTheta Cosine of angle between half-vector and view direction
 * @return Fresnel reflectance value (RGB)
 */
vec3 fresnelSchlick(vec3 F0, float cosTheta) {
    // Clamp cosTheta to [0, 1] to prevent numerical issues
    cosTheta = clamp(cosTheta, 0.0, 1.0);
    
    // Schlick approximation applied per channel
    float oneMinusCos = 1.0 - cosTheta;
    float factor = oneMinusCos * oneMinusCos * oneMinusCos * oneMinusCos * oneMinusCos;
    return F0 + (vec3(1.0) - F0) * factor;
}

// ============================================================================
// GGX/Trowbridge-Reitz Microfacet Distribution
// ============================================================================
// Models the distribution of microfacet normals on the surface
// Formula: D(h) = α² / (π * ((h·n)² * (α² - 1) + 1)²)
// where α = roughness²
//
// GGX is widely used in modern PBR because it produces realistic tail behavior
// for rough surfaces and matches measured material data well.

/**
 * Calculate GGX/Trowbridge-Reitz distribution
 * @param NdotH Cosine of angle between normal and half-vector
 * @param roughness Perceptual roughness (0.0 = smooth, 1.0 = rough)
 * @return Distribution value
 */
float distributionGGX(float NdotH, float roughness) {
    // Clamp NdotH to [0, 1] to prevent numerical issues
    NdotH = clamp(NdotH, 0.0, 1.0);
    
    // Convert perceptual roughness to α (alpha)
    // Using α = roughness² for better perceptual distribution
    float alpha = roughness * roughness;
    float alphaSq = alpha * alpha;
    
    // GGX formula: α² / (π * ((h·n)² * (α² - 1) + 1)²)
    float NdotHSq = NdotH * NdotH;
    float denominator = NdotHSq * (alphaSq - 1.0) + 1.0;
    denominator = 3.14159265 * denominator * denominator;
    
    // Prevent division by zero
    return alphaSq / max(denominator, 0.001);
}

// ============================================================================
// Smith's Geometry Function with Schlick-Beckmann
// ============================================================================
// Models how microfacets shadow and mask each other
// Formula: G(l,v,h) = G1(l) * G1(v)
// where G1(x) = 2(x·n) / ((x·n) + sqrt(α² + (1-α²)(x·n)²))
//
// Smith's method is more accurate than simpler geometry functions and
// properly accounts for both light and view direction shadowing.

/**
 * Calculate Smith's G1 function (single direction)
 * @param NdotX Cosine of angle between normal and direction (light or view)
 * @param roughness Perceptual roughness (0.0 = smooth, 1.0 = rough)
 * @return G1 value
 */
float smithG1(float NdotX, float roughness) {
    // Clamp NdotX to [0, 1] to prevent numerical issues
    NdotX = clamp(NdotX, 0.0, 1.0);
    
    // Convert perceptual roughness to α (alpha)
    float alpha = roughness * roughness;
    float alphaSq = alpha * alpha;
    
    // Schlick-Beckmann approximation for Smith's G1
    // G1(x) = 2(x·n) / ((x·n) + sqrt(α² + (1-α²)(x·n)²))
    float NdotXSq = NdotX * NdotX;
    float denominator = NdotX + sqrt(alphaSq + (1.0 - alphaSq) * NdotXSq);
    
    // Prevent division by zero
    return (2.0 * NdotX) / max(denominator, 0.001);
}

/**
 * Calculate Smith's geometry function (both light and view directions)
 * @param NdotL Cosine of angle between normal and light direction
 * @param NdotV Cosine of angle between normal and view direction
 * @param roughness Perceptual roughness (0.0 = smooth, 1.0 = rough)
 * @return Smith's G value
 */
float geometrySmith(float NdotL, float NdotV, float roughness) {
    // Calculate G1 for both directions and multiply
    float G1L = smithG1(NdotL, roughness);
    float G1V = smithG1(NdotV, roughness);
    return G1L * G1V;
}

// ============================================================================
// Cook-Torrance PBR Lighting Model
// ============================================================================
// Complete Cook-Torrance implementation combining all components
// Formula: Lo = (kd * c/π + ks * DFG/(4(wo·n)(wi·n))) * Li * (wi·n)
//
// This is the industry-standard PBR model used in modern game engines
// and provides physically plausible results across all material types.

/**
 * Calculate Cook-Torrance PBR lighting
 * @param albedo Surface albedo (diffuse color)
 * @param normal Surface normal (normalized)
 * @param viewDir View direction (normalized, from surface to camera)
 * @param lightDir Light direction (normalized, from surface to light)
 * @param lightColor Light color and intensity
 * @param roughness Perceptual roughness (0.0 = smooth, 1.0 = rough)
 * @param metallic Metallic factor (0.0 = dielectric, 1.0 = metal)
 * @param F0 Reflectance at normal incidence (use albedo for metals, 0.04 for dielectrics)
 * @return Outgoing radiance
 */
vec3 cookTorrance(
    vec3 albedo,
    vec3 normal,
    vec3 viewDir,
    vec3 lightDir,
    vec3 lightColor,
    float roughness,
    float metallic,
    vec3 F0
) {
    // Calculate half-vector
    vec3 halfVec = normalize(viewDir + lightDir);
    
    // Calculate dot products
    float NdotL = dot(normal, lightDir);
    float NdotV = dot(normal, viewDir);
    float NdotH = dot(normal, halfVec);
    float HdotV = dot(halfVec, viewDir);
    
    // Clamp NdotL to prevent back-facing surfaces
    NdotL = max(NdotL, 0.0);
    NdotV = max(NdotV, 0.0);
    
    // If either dot product is zero, no light reaches the surface
    if (NdotL == 0.0 || NdotV == 0.0) {
        return vec3(0.0);
    }
    
    // Calculate Fresnel (F)
    vec3 F = fresnelSchlick(F0, HdotV);
    
    // Calculate Distribution (D)
    float D = distributionGGX(NdotH, roughness);
    
    // Calculate Geometry (G)
    float G = geometrySmith(NdotL, NdotV, roughness);
    
    // Calculate specular component: DFG / (4 * (wo·n) * (wi·n))
    vec3 specular = (D * F * G) / max(4.0 * NdotV * NdotL, 0.001);
    
    // Calculate diffuse component: kd * c / π
    // For metals, kd = 0; for dielectrics, kd = 1 - ks
    vec3 kd = (vec3(1.0) - F) * (1.0 - metallic);
    vec3 diffuse = kd * albedo / 3.14159265;
    
    // Combine diffuse and specular: (kd * c/π + ks * DFG/(4(wo·n)(wi·n))) * Li * (wi·n)
    vec3 Lo = (diffuse + specular) * lightColor * NdotL;
    
    return Lo;
}

// ============================================================================
// Energy Conservation Validation
// ============================================================================
// Ensures that the sum of diffuse and specular reflectance does not exceed 1.0
// This is a fundamental property of physically-based rendering.

/**
 * Check if a material satisfies energy conservation
 * @param diffuse Diffuse reflectance (0.0-1.0)
 * @param specular Specular reflectance (0.0-1.0)
 * @return true if diffuse + specular <= 1.0, false otherwise
 */
bool isEnergyConserving(float diffuse, float specular) {
    return (diffuse + specular) <= 1.0;
}

/**
 * Check if a material satisfies energy conservation (RGB)
 * @param diffuse Diffuse reflectance (RGB, 0.0-1.0)
 * @param specular Specular reflectance (RGB, 0.0-1.0)
 * @return true if all channels satisfy energy conservation, false otherwise
 */
bool isEnergyConserving(vec3 diffuse, vec3 specular) {
    return isEnergyConserving(diffuse.r, specular.r) &&
           isEnergyConserving(diffuse.g, specular.g) &&
           isEnergyConserving(diffuse.b, specular.b);
}

/**
 * Clamp material to satisfy energy conservation
 * @param diffuse Diffuse reflectance (0.0-1.0)
 * @param specular Specular reflectance (0.0-1.0)
 * @return Clamped specular value ensuring diffuse + specular <= 1.0
 */
float enforceEnergyConservation(float diffuse, float specular) {
    float maxSpecular = 1.0 - diffuse;
    return min(specular, maxSpecular);
}

/**
 * Clamp material to satisfy energy conservation (RGB)
 * @param diffuse Diffuse reflectance (RGB, 0.0-1.0)
 * @param specular Specular reflectance (RGB, 0.0-1.0)
 * @return Clamped specular value ensuring diffuse + specular <= 1.0 per channel
 */
vec3 enforceEnergyConservation(vec3 diffuse, vec3 specular) {
    return vec3(
        enforceEnergyConservation(diffuse.r, specular.r),
        enforceEnergyConservation(diffuse.g, specular.g),
        enforceEnergyConservation(diffuse.b, specular.b)
    );
}

// ============================================================================
// Utility Functions for PBR
// ============================================================================

/**
 * Convert linear roughness to perceptual roughness
 * @param linearRoughness Linear roughness value (0.0-1.0)
 * @return Perceptual roughness value
 */
float linearToPerceptualRoughness(float linearRoughness) {
    // Perceptual roughness = sqrt(linear roughness)
    return sqrt(linearRoughness);
}

/**
 * Convert perceptual roughness to linear roughness
 * @param perceptualRoughness Perceptual roughness value (0.0-1.0)
 * @return Linear roughness value
 */
float perceptualToLinearRoughness(float perceptualRoughness) {
    // Linear roughness = perceptual roughness²
    return perceptualRoughness * perceptualRoughness;
}

/**
 * Calculate F0 for dielectric materials
 * Most dielectric materials have F0 around 0.04 (4% reflectance)
 * @return F0 value for typical dielectric
 */
vec3 getDielectricF0() {
    return vec3(0.04);
}

/**
 * Calculate F0 for metallic materials
 * For metals, F0 is derived from the albedo color
 * @param albedo Surface albedo (diffuse color)
 * @return F0 value for metal
 */
vec3 getMetallicF0(vec3 albedo) {
    // For metals, use albedo as F0 (with slight adjustment for physical accuracy)
    return albedo;
}

#endif // PBR_GLSL
