/*
 * BlendHer Shader - Modern Water Rendering Library
 * 
 * This library provides the complete water rendering system:
 * - Gerstner wave displacement (4-8 frequency components)
 * - Vertical displacement only (world-space Y-axis)
 * - Normal reconstruction from displacement gradient
 * - Caustic patterns using screen-space derivatives
 * - Water color grading based on blend factor
 * 
 * Gerstner waves create realistic water surface displacement that responds
 * to multiple frequency components, creating natural-looking wave patterns.
 * The system maintains vertical displacement only to preserve water surface
 * integrity while providing visual depth through normal variations.
 * 
 * Reference: Requirement 9 (Gerstner Wave Water)
 * Compatible with: GLSL 460 core, Iris 1.8.5+, OptiFine
 */

#ifndef WATER_GLSL
#define WATER_GLSL

// ============================================================================
// GERSTNER WAVE PARAMETERS
// ============================================================================
// Gerstner waves are defined by frequency, amplitude, and phase parameters.
// Multiple frequency components create complex, realistic wave patterns.
//
// Reference: Requirement 9 (Gerstner Wave Water)

/**
 * Gerstner wave frequency components
 * 
 * Defines the frequency (wavelength) for each wave component.
 * Higher frequencies create smaller, faster waves.
 * Lower frequencies create larger, slower waves.
 * 
 * Validates: Requirement 9 (Gerstner Wave Water)
 */
const float WAVE_FREQUENCIES[8] = float[](
    0.5,    // Component 0: Large, slow waves
    1.0,    // Component 1: Medium waves
    2.0,    // Component 2: Medium-small waves
    4.0,    // Component 3: Small waves
    8.0,    // Component 4: Smaller waves
    16.0,   // Component 5: Fine detail waves
    32.0,   // Component 6: Very fine waves
    64.0    // Component 7: Micro waves
);

/**
 * Gerstner wave amplitude components
 * 
 * Defines the amplitude (height) for each wave component.
 * Amplitudes decrease for higher frequencies to create natural wave hierarchy.
 * 
 * Validates: Requirement 9 (Gerstner Wave Water)
 */
const float WAVE_AMPLITUDES[8] = float[](
    0.08,   // Component 0: Large amplitude
    0.04,   // Component 1: Medium amplitude
    0.02,   // Component 2: Medium-small amplitude
    0.01,   // Component 3: Small amplitude
    0.005,  // Component 4: Smaller amplitude
    0.0025, // Component 5: Fine detail amplitude
    0.001,  // Component 6: Very fine amplitude
    0.0005  // Component 7: Micro amplitude
);

/**
 * Gerstner wave phase offsets
 * 
 * Defines the phase offset for each wave component.
 * Different phases prevent all waves from aligning, creating more natural patterns.
 * 
 * Validates: Requirement 9 (Gerstner Wave Water)
 */
const float WAVE_PHASES[8] = float[](
    0.0,
    1.57,   // π/2
    3.14,   // π
    4.71,   // 3π/2
    1.0,
    2.0,
    3.0,
    4.0
);

/**
 * Gerstner wave direction vectors (XZ plane)
 * 
 * Defines the direction for each wave component in the XZ plane.
 * Different directions create crossing wave patterns.
 * 
 * Validates: Requirement 9 (Gerstner Wave Water)
 */
const vec2 WAVE_DIRECTIONS[8] = vec2[](
    vec2(1.0, 0.0),      // Component 0: X direction
    vec2(0.707, 0.707),  // Component 1: Diagonal
    vec2(0.0, 1.0),      // Component 2: Z direction
    vec2(-0.707, 0.707), // Component 3: Diagonal
    vec2(-1.0, 0.0),     // Component 4: -X direction
    vec2(-0.707, -0.707),// Component 5: Diagonal
    vec2(0.0, -1.0),     // Component 6: -Z direction
    vec2(0.707, -0.707)  // Component 7: Diagonal
);

// ============================================================================
// GERSTNER WAVE CALCULATION
// ============================================================================
// Gerstner waves calculate vertical displacement based on position and time.
// The formula creates realistic wave patterns with multiple frequency components.
//
// Reference: Requirement 9 (Gerstner Wave Water)

/**
 * Calculate Gerstner wave displacement at a world position
 * 
 * Computes vertical displacement (Y-axis only) for a given world position
 * using multiple Gerstner wave frequency components. The displacement is
 * calculated as the sum of sine waves with different frequencies, amplitudes,
 * and phases.
 * 
 * Formula: displacement = Σ amplitude * sin(frequency * (direction · position) + phase + time)
 * 
 * Input: worldPos - world position (XYZ)
 *        time - animation time (typically worldTime or frameTime)
 *        numComponents - number of wave components to use (1-8)
 * Output: vertical displacement in world-space Y-axis
 * 
 * Validates: Requirement 9 (Gerstner Wave Water)
 */
float calculateGerstnerWaveDisplacement(vec3 worldPos, float time, int numComponents) {
    // Clamp number of components to valid range
    numComponents = clamp(numComponents, 1, 8);
    
    // Initialize displacement
    float displacement = 0.0;
    
    // Sum contributions from each wave component
    for (int i = 0; i < numComponents; i++) {
        // Get wave parameters
        float frequency = WAVE_FREQUENCIES[i];
        float amplitude = WAVE_AMPLITUDES[i];
        float phase = WAVE_PHASES[i];
        vec2 direction = WAVE_DIRECTIONS[i];
        
        // Calculate wave argument: frequency * (direction · position) + phase + time
        float waveArg = frequency * dot(direction, worldPos.xz) + phase + time;
        
        // Calculate sine wave contribution
        float waveContribution = amplitude * sin(waveArg);
        
        // Add to total displacement
        displacement += waveContribution;
    }
    
    // Clamp displacement to reasonable range to prevent extreme values
    displacement = clamp(displacement, -0.5, 0.5);
    
    return displacement;
}

/**
 * Calculate Gerstner wave displacement with custom parameters
 * 
 * Computes vertical displacement using custom frequency, amplitude, and phase arrays.
 * Allows for flexible wave configuration beyond the default parameters.
 * 
 * Input: worldPos - world position (XYZ)
 *        time - animation time
 *        frequencies - array of wave frequencies
 *        amplitudes - array of wave amplitudes
 *        phases - array of wave phases
 *        directions - array of wave direction vectors
 *        numComponents - number of components to use
 * Output: vertical displacement in world-space Y-axis
 * 
 * Validates: Requirement 9 (Gerstner Wave Water)
 */
float calculateGerstnerWaveDisplacementCustom(
    vec3 worldPos, 
    float time,
    float frequencies[8],
    float amplitudes[8],
    float phases[8],
    vec2 directions[8],
    int numComponents
) {
    // Clamp number of components to valid range
    numComponents = clamp(numComponents, 1, 8);
    
    // Initialize displacement
    float displacement = 0.0;
    
    // Sum contributions from each wave component
    for (int i = 0; i < numComponents; i++) {
        // Get wave parameters
        float frequency = frequencies[i];
        float amplitude = amplitudes[i];
        float phase = phases[i];
        vec2 direction = directions[i];
        
        // Clamp parameters to valid ranges
        frequency = max(frequency, 0.0);
        amplitude = max(amplitude, 0.0);
        
        // Calculate wave argument
        float waveArg = frequency * dot(direction, worldPos.xz) + phase + time;
        
        // Calculate sine wave contribution
        float waveContribution = amplitude * sin(waveArg);
        
        // Add to total displacement
        displacement += waveContribution;
    }
    
    // Clamp displacement to reasonable range
    displacement = clamp(displacement, -0.5, 0.5);
    
    return displacement;
}

// ============================================================================
// NORMAL RECONSTRUCTION FROM DISPLACEMENT GRADIENT
// ============================================================================
// Normals are reconstructed from the displacement gradient to create
// realistic lighting on the water surface.
//
// Reference: Requirement 9 (Gerstner Wave Water)

/**
 * Calculate displacement gradient for normal reconstruction
 * 
 * Computes the gradient (partial derivatives) of the displacement function
 * using finite differences. The gradient is used to reconstruct surface normals.
 * 
 * Input: worldPos - world position (XYZ)
 *        time - animation time
 *        numComponents - number of wave components
 *        epsilon - finite difference step size (default 0.1)
 * Output: gradient vector (dDisplacement/dX, dDisplacement/dZ)
 * 
 * Validates: Requirement 9 (Gerstner Wave Water)
 */
vec2 calculateDisplacementGradient(vec3 worldPos, float time, int numComponents, float epsilon) {
    // Clamp epsilon to prevent division by zero
    epsilon = max(epsilon, 0.001);
    
    // Calculate displacement at current position
    float displacementCenter = calculateGerstnerWaveDisplacement(worldPos, time, numComponents);
    
    // Calculate displacement at offset positions (finite differences)
    float displacementX = calculateGerstnerWaveDisplacement(
        worldPos + vec3(epsilon, 0.0, 0.0), time, numComponents
    );
    float displacementZ = calculateGerstnerWaveDisplacement(
        worldPos + vec3(0.0, 0.0, epsilon), time, numComponents
    );
    
    // Calculate partial derivatives
    float dDisplacementDx = (displacementX - displacementCenter) / epsilon;
    float dDisplacementDz = (displacementZ - displacementCenter) / epsilon;
    
    // Clamp gradients to prevent extreme values
    dDisplacementDx = clamp(dDisplacementDx, -1.0, 1.0);
    dDisplacementDz = clamp(dDisplacementDz, -1.0, 1.0);
    
    return vec2(dDisplacementDx, dDisplacementDz);
}

/**
 * Reconstruct surface normal from displacement gradient
 * 
 * Converts the displacement gradient into a surface normal vector.
 * The normal is calculated as the cross product of tangent vectors
 * derived from the displacement gradient.
 * 
 * Formula: normal = normalize(vec3(-dDisplacement/dX, 1.0, -dDisplacement/dZ))
 * 
 * Input: gradient - displacement gradient (dDisplacement/dX, dDisplacement/dZ)
 * Output: surface normal vector (normalized)
 * 
 * Validates: Requirement 9 (Gerstner Wave Water)
 */
vec3 reconstructNormalFromGradient(vec2 gradient) {
    // Clamp gradient to valid range
    gradient = clamp(gradient, vec2(-1.0), vec2(1.0));
    
    // Reconstruct normal from gradient
    // The normal is perpendicular to the surface, derived from the gradient
    vec3 normal = vec3(-gradient.x, 1.0, -gradient.y);
    
    // Normalize the normal vector
    normal = normalize(normal);
    
    // Ensure normal is valid (not NaN or Inf)
    if (any(isnan(normal)) || any(isinf(normal))) {
        normal = vec3(0.0, 1.0, 0.0); // Fallback to vertical normal
    }
    
    return normal;
}

/**
 * Calculate water surface normal at a world position
 * 
 * Combines displacement gradient calculation and normal reconstruction
 * into a single function for convenience.
 * 
 * Input: worldPos - world position (XYZ)
 *        time - animation time
 *        numComponents - number of wave components
 * Output: surface normal vector (normalized)
 * 
 * Validates: Requirement 9 (Gerstner Wave Water)
 */
vec3 calculateWaterSurfaceNormal(vec3 worldPos, float time, int numComponents) {
    // Calculate displacement gradient
    vec2 gradient = calculateDisplacementGradient(worldPos, time, numComponents, 0.1);
    
    // Reconstruct normal from gradient
    vec3 normal = reconstructNormalFromGradient(gradient);
    
    return normal;
}

// ============================================================================
// CAUSTIC PATTERNS
// ============================================================================
// Caustic patterns create realistic underwater light patterns using
// screen-space derivatives of the displacement.
//
// Reference: Requirement 9 (Gerstner Wave Water)

/**
 * Calculate caustic pattern using screen-space derivatives
 * 
 * Generates caustic patterns by applying screen-space derivatives to the
 * displacement gradient. This creates realistic underwater light patterns
 * that animate with the water surface.
 * 
 * Input: screenCoord - screen-space texture coordinate [0.0, 1.0]
 *        displacement - water displacement at this position
 *        gradient - displacement gradient (dDisplacement/dX, dDisplacement/dZ)
 *        time - animation time
 * Output: caustic intensity in [0.0, 1.0]
 * 
 * Validates: Requirement 9 (Gerstner Wave Water)
 */
float calculateCausticPattern(vec2 screenCoord, float displacement, vec2 gradient, float time) {
    // Clamp inputs to valid ranges
    screenCoord = clamp(screenCoord, vec2(0.0), vec2(1.0));
    displacement = clamp(displacement, -0.5, 0.5);
    gradient = clamp(gradient, vec2(-1.0), vec2(1.0));
    
    // Calculate caustic UV coordinates using displacement gradient
    // The gradient is used to distort the caustic pattern
    vec2 causticUV = screenCoord + gradient * 0.1;
    
    // Animate caustic pattern over time
    causticUV += time * 0.05;
    
    // Create caustic pattern using sine waves
    // Multiple frequencies create complex caustic patterns
    float caustic = 0.0;
    
    // Primary caustic pattern
    caustic += sin(causticUV.x * 10.0) * sin(causticUV.y * 10.0) * 0.5;
    
    // Secondary caustic pattern (different frequency)
    caustic += sin(causticUV.x * 7.0 + time) * sin(causticUV.y * 7.0 + time) * 0.3;
    
    // Tertiary caustic pattern (fine detail)
    caustic += sin(causticUV.x * 15.0 - time * 0.5) * sin(causticUV.y * 15.0 - time * 0.5) * 0.2;
    
    // Normalize caustic to [0.0, 1.0] range
    caustic = caustic * 0.5 + 0.5;
    
    // Apply displacement-based modulation
    // Stronger displacement creates more pronounced caustics
    float displacementFactor = abs(displacement) * 2.0;
    caustic = mix(0.5, caustic, displacementFactor);
    
    // Clamp to valid range
    caustic = clamp(caustic, 0.0, 1.0);
    
    return caustic;
}

/**
 * Calculate animated caustic pattern
 * 
 * Generates caustic patterns with smooth animation over time.
 * Uses multiple sine waves at different frequencies for complex patterns.
 * 
 * Input: screenCoord - screen-space texture coordinate [0.0, 1.0]
 *        time - animation time
 * Output: caustic intensity in [0.0, 1.0]
 * 
 * Validates: Requirement 9 (Gerstner Wave Water)
 */
float calculateAnimatedCausticPattern(vec2 screenCoord, float time) {
    // Clamp screen coordinate to valid range
    screenCoord = clamp(screenCoord, vec2(0.0), vec2(1.0));
    
    // Create animated caustic pattern
    float caustic = 0.0;
    
    // Layer 1: Large caustic pattern
    caustic += sin(screenCoord.x * 8.0 + time * 0.3) * 
              sin(screenCoord.y * 8.0 + time * 0.3) * 0.4;
    
    // Layer 2: Medium caustic pattern
    caustic += sin(screenCoord.x * 12.0 - time * 0.2) * 
              sin(screenCoord.y * 12.0 - time * 0.2) * 0.3;
    
    // Layer 3: Fine caustic pattern
    caustic += sin(screenCoord.x * 20.0 + time * 0.1) * 
              sin(screenCoord.y * 20.0 + time * 0.1) * 0.2;
    
    // Layer 4: Very fine caustic pattern
    caustic += sin(screenCoord.x * 30.0 - time * 0.05) * 
              sin(screenCoord.y * 30.0 - time * 0.05) * 0.1;
    
    // Normalize to [0.0, 1.0]
    caustic = caustic * 0.5 + 0.5;
    
    // Apply smoothstep to enhance contrast
    caustic = smoothstep(0.3, 0.7, caustic);
    
    // Clamp to valid range
    caustic = clamp(caustic, 0.0, 1.0);
    
    return caustic;
}

// ============================================================================
// WATER COLOR GRADING
// ============================================================================
// Water color is graded based on the blend factor to create smooth transitions
// between BSL's clear water and Spooklementary's murky water.
//
// Reference: Requirement 9 (Gerstner Wave Water)

/**
 * Calculate water color based on blend factor
 * 
 * Adjusts water color to match the visual state.
 * BSL water is clear and blue, Spooklementary water is murky and dark.
 * 
 * Input: blendFactor - blend factor in [0.0, 1.0]
 *                      1.0 = BSL (clear, vibrant water)
 *                      0.0 = Spooklementary (murky, dark water)
 * Output: water color (RGB)
 * 
 * Validates: Requirement 9 (Gerstner Wave Water)
 */
vec3 calculateWaterColor(float blendFactor) {
    // Clamp blend factor to valid range
    blendFactor = clamp(blendFactor, 0.0, 1.0);
    
    // BSL water color: clear blue (RGB: 0.1, 0.3, 0.6)
    vec3 bslWaterColor = vec3(0.1, 0.3, 0.6);
    
    // Spooklementary water color: murky dark (RGB: 0.05, 0.1, 0.15)
    vec3 spookWaterColor = vec3(0.05, 0.1, 0.15);
    
    // Blend between BSL and Spooklementary water colors
    vec3 waterColor = mix(spookWaterColor, bslWaterColor, blendFactor);
    
    // Clamp to ensure output is in valid range
    waterColor = clamp(waterColor, vec3(0.0), vec3(1.0));
    
    return waterColor;
}

/**
 * Apply water color grading to scene color
 * 
 * Applies water-specific color grading based on blend factor.
 * Adjusts saturation, brightness, and tint to match the visual state.
 * 
 * Input: sceneColor - original scene color (RGB)
 *        blendFactor - blend factor in [0.0, 1.0]
 * Output: color-graded water color
 * 
 * Validates: Requirement 9 (Gerstner Wave Water)
 */
vec3 applyWaterColorGrading(vec3 sceneColor, float blendFactor) {
    // Clamp inputs to valid range
    sceneColor = clamp(sceneColor, vec3(0.0), vec3(1.0));
    blendFactor = clamp(blendFactor, 0.0, 1.0);
    
    // Calculate water color
    vec3 waterColor = calculateWaterColor(blendFactor);
    
    // Calculate saturation multiplier based on blend factor
    // At blend factor 1.0 (BSL): saturation = 1.0 (vibrant)
    // At blend factor 0.0 (Spooklementary): saturation = 0.5 (desaturated)
    float saturation = mix(0.5, 1.0, blendFactor);
    
    // Calculate brightness multiplier based on blend factor
    // At blend factor 1.0 (BSL): brightness = 1.0 (bright)
    // At blend factor 0.0 (Spooklementary): brightness = 0.6 (dark)
    float brightness = mix(0.6, 1.0, blendFactor);
    
    // Apply brightness adjustment
    vec3 gradedColor = sceneColor * brightness;
    
    // Apply saturation adjustment using desaturation technique
    // Calculate luminance
    float luminance = dot(gradedColor, vec3(0.299, 0.587, 0.114));
    
    // Interpolate between desaturated (luminance) and saturated (original)
    gradedColor = mix(vec3(luminance), gradedColor, saturation);
    
    // Blend with water color
    gradedColor = mix(gradedColor, waterColor, 0.3);
    
    // Clamp to ensure output is in valid range
    gradedColor = clamp(gradedColor, vec3(0.0), vec3(1.0));
    
    return gradedColor;
}

/**
 * Calculate water transparency based on depth and blend factor
 * 
 * Adjusts water transparency based on depth and visual state.
 * Deeper water is more opaque, and Spooklementary water is more opaque than BSL.
 * 
 * Input: depth - water depth (in blocks)
 *        blendFactor - blend factor in [0.0, 1.0]
 * Output: water transparency in [0.0, 1.0]
 *         0.0 = fully transparent
 *         1.0 = fully opaque
 * 
 * Validates: Requirement 9 (Gerstner Wave Water)
 */
float calculateWaterTransparency(float depth, float blendFactor) {
    // Clamp inputs to valid range
    depth = max(depth, 0.0);
    blendFactor = clamp(blendFactor, 0.0, 1.0);
    
    // Calculate base transparency based on depth
    // Deeper water is more opaque
    float depthTransparency = 1.0 - exp(-depth * 0.1);
    
    // Calculate blend-based transparency multiplier
    // At blend factor 1.0 (BSL): transparency = 0.3 (more transparent)
    // At blend factor 0.0 (Spooklementary): transparency = 0.7 (more opaque)
    float blendTransparency = mix(0.7, 0.3, blendFactor);
    
    // Combine depth and blend transparency
    float transparency = depthTransparency * blendTransparency;
    
    // Clamp to valid range
    transparency = clamp(transparency, 0.0, 1.0);
    
    return transparency;
}

// ============================================================================
// COMPLETE WATER RENDERING
// ============================================================================
// Combines all water effects in a cohesive system.

/**
 * Apply complete water displacement and normal calculation
 * 
 * Calculates water displacement, reconstructs normals, and applies
 * caustic patterns in a single function.
 * 
 * Input: worldPos - world position (XYZ)
 *        screenCoord - screen-space texture coordinate [0.0, 1.0]
 *        time - animation time
 *        numComponents - number of wave components (1-8)
 * Output: struct containing displacement, normal, and caustic
 * 
 * Validates: Requirement 9 (Gerstner Wave Water)
 */
struct WaterSurfaceData {
    float displacement;
    vec3 normal;
    float caustic;
};

/**
 * Calculate complete water surface data
 * 
 * Computes all water surface properties including displacement, normal, and caustics.
 * 
 * Input: worldPos - world position (XYZ)
 *        screenCoord - screen-space texture coordinate [0.0, 1.0]
 *        time - animation time
 *        numComponents - number of wave components (1-8)
 * Output: WaterSurfaceData struct with all properties
 * 
 * Validates: Requirement 9 (Gerstner Wave Water)
 */
WaterSurfaceData calculateWaterSurfaceData(vec3 worldPos, vec2 screenCoord, float time, int numComponents) {
    WaterSurfaceData data;
    
    // Calculate displacement
    data.displacement = calculateGerstnerWaveDisplacement(worldPos, time, numComponents);
    
    // Calculate normal
    data.normal = calculateWaterSurfaceNormal(worldPos, time, numComponents);
    
    // Calculate caustic pattern
    vec2 gradient = calculateDisplacementGradient(worldPos, time, numComponents, 0.1);
    data.caustic = calculateCausticPattern(screenCoord, data.displacement, gradient, time);
    
    return data;
}

/**
 * Apply complete water rendering to scene color
 * 
 * Applies water displacement, normal mapping, caustics, and color grading
 * to create the final water appearance.
 * 
 * Input: sceneColor - original scene color (RGB)
 *        worldPos - world position (XYZ)
 *        screenCoord - screen-space texture coordinate [0.0, 1.0]
 *        time - animation time
 *        blendFactor - blend factor in [0.0, 1.0]
 *        numComponents - number of wave components (1-8)
 * Output: scene color with water effects applied
 * 
 * Validates: Requirement 9 (Gerstner Wave Water)
 */
vec3 applyWaterRendering(vec3 sceneColor, vec3 worldPos, vec2 screenCoord, 
                         float time, float blendFactor, int numComponents) {
    // Clamp inputs to valid range
    sceneColor = clamp(sceneColor, vec3(0.0), vec3(1.0));
    blendFactor = clamp(blendFactor, 0.0, 1.0);
    numComponents = clamp(numComponents, 1, 8);
    
    // Calculate water surface data
    WaterSurfaceData waterData = calculateWaterSurfaceData(worldPos, screenCoord, time, numComponents);
    
    // Apply water color grading
    vec3 waterColor = applyWaterColorGrading(sceneColor, blendFactor);
    
    // Apply caustic pattern to water color
    // Caustics brighten the water surface
    waterColor = mix(waterColor, waterColor * 1.2, waterData.caustic * 0.3);
    
    // Apply normal-based lighting adjustment
    // Normals facing up (towards camera) are brighter
    float normalLighting = max(waterData.normal.y, 0.0);
    waterColor = mix(waterColor * 0.8, waterColor, normalLighting);
    
    // Clamp to ensure output is in valid range
    waterColor = clamp(waterColor, vec3(0.0), vec3(1.0));
    
    return waterColor;
}

// ============================================================================
// UTILITY FUNCTIONS
// ============================================================================

/**
 * Check if water surface data is valid
 * 
 * Detects invalid floating-point values in water calculations.
 * 
 * Input: data - WaterSurfaceData struct to check
 * Output: true if data is valid, false otherwise
 */
bool isValidWaterSurfaceData(WaterSurfaceData data) {
    // Check displacement for NaN or Inf
    if (data.displacement != data.displacement || abs(data.displacement) > 1e10) {
        return false;
    }
    
    // Check normal for NaN or Inf
    if (any(isnan(data.normal)) || any(isinf(data.normal))) {
        return false;
    }
    
    // Check caustic for NaN or Inf
    if (data.caustic != data.caustic || abs(data.caustic) > 1e10) {
        return false;
    }
    
    // Check normal is normalized (length close to 1.0)
    float normalLength = length(data.normal);
    if (abs(normalLength - 1.0) > 0.1) {
        return false;
    }
    
    return true;
}

/**
 * Safely apply water rendering with validation
 * 
 * Applies water rendering with fallback to scene color if invalid values detected.
 * 
 * Input: sceneColor - original scene color (RGB)
 *        worldPos - world position (XYZ)
 *        screenCoord - screen-space texture coordinate [0.0, 1.0]
 *        time - animation time
 *        blendFactor - blend factor in [0.0, 1.0]
 *        numComponents - number of wave components (1-8)
 * Output: scene color with water effects applied, or original if invalid
 */
vec3 safeApplyWaterRendering(vec3 sceneColor, vec3 worldPos, vec2 screenCoord, 
                             float time, float blendFactor, int numComponents) {
    // Calculate water surface data
    WaterSurfaceData waterData = calculateWaterSurfaceData(worldPos, screenCoord, time, numComponents);
    
    // Check if data is valid
    if (!isValidWaterSurfaceData(waterData)) {
        return sceneColor; // Return original scene color if invalid
    }
    
    // Apply water rendering
    return applyWaterRendering(sceneColor, worldPos, screenCoord, time, blendFactor, numComponents);
}

#endif // WATER_GLSL


// ============================================================================
// SIMPLIFIED WATER FUNCTIONS FOR GBUFFERS
// ============================================================================

/**
 * Apply Gerstner wave displacement to world position.
 * 
 * Simplified version for gbuffers passes that applies vertical displacement only.
 * 
 * Input: worldPos - world position (XYZ)
 * Output: displaced position with vertical displacement applied
 * 
 * Validates: Requirement 9 (Gerstner Wave Water)
 */
vec3 applyGerstnerWaves(vec3 worldPos) {
    // Calculate displacement using default parameters
    float displacement = calculateGerstnerWaveDisplacement(worldPos, worldTime, 8);
    
    // Apply vertical displacement only (Y-axis)
    vec3 displacedPos = worldPos;
    displacedPos.y += displacement;
    
    return displacedPos;
}

/**
 * Calculate wave normals from displaced position.
 * 
 * Reconstructs surface normals from the displacement gradient.
 * 
 * Input: originalPos - original world position
 *        displacedPos - displaced world position
 * Output: surface normal vector (normalized)
 * 
 * Validates: Requirement 9 (Gerstner Wave Water)
 */
vec3 calculateWaveNormals(vec3 originalPos, vec3 displacedPos) {
    // Calculate displacement gradient
    vec2 gradient = calculateDisplacementGradient(originalPos, worldTime, 8, 0.1);
    
    // Reconstruct normal from gradient
    vec3 normal = reconstructNormalFromGradient(gradient);
    
    return normal;
}

