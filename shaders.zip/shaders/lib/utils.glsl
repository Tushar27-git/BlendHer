/*
 * BlendHer Shader - Modern Utility Functions
 * 
 * This file provides reusable utility functions used across multiple shader passes:
 * - Lightmap normalization for LabPBR material support
 * - Color space conversion (linear ↔ sRGB) for accurate color handling
 * - Hermite smoothstep for smooth visual state transitions
 * - Blue noise sampling for TAA jitter patterns
 * - Common math utilities (fade functions, safe division, etc.)
 * 
 * These functions are fundamental to the shader pipeline and are included
 * in all passes that require their functionality.
 * 
 * Compatible with: GLSL 460 core, Iris 1.8.5+, OptiFine
 * References: Requirement 7 (Visual State System), Requirement 4 (TAA)
 */

#ifndef UTILS_GLSL
#define UTILS_GLSL

// ============================================================================
// LIGHTMAP NORMALIZATION
// ============================================================================

/**
 * Normalizes Minecraft lightmap coordinates to [0.0, 1.0] range.
 * 
 * Minecraft provides lightmap coordinates as 16x16 texture coordinates.
 * This function normalizes them to standard [0.0, 1.0] range for sampling.
 * 
 * Input: lightmapCoord - raw Minecraft lightmap coordinate (typically 0-15)
 * Output: normalized coordinate in [0.0, 1.0]
 * 
 * Validates: Requirement 7 (Visual State System)
 */
vec2 normalizeLightmap(vec2 lightmapCoord) {
    // Minecraft lightmap is 16x16, normalize to [0.0, 1.0]
    // Add 0.5 to sample from center of texel, divide by 16.0
    return (lightmapCoord + 0.5) / 16.0;
}

/**
 * Denormalizes lightmap coordinates from [0.0, 1.0] back to Minecraft format.
 * 
 * Inverse operation of normalizeLightmap for cases where we need to work
 * with raw Minecraft lightmap coordinates.
 * 
 * Input: normalizedCoord - normalized coordinate in [0.0, 1.0]
 * Output: Minecraft lightmap coordinate (0-15)
 */
vec2 denormalizeLightmap(vec2 normalizedCoord) {
    // Inverse of normalization: multiply by 16.0, subtract 0.5
    return normalizedCoord * 16.0 - 0.5;
}

/**
 * Extracts block light intensity from Minecraft lightmap.
 * 
 * Minecraft stores block light in the X channel (0-15) and sky light in Y channel.
 * This function extracts and normalizes block light to [0.0, 1.0].
 * 
 * Input: lightmapCoord - normalized lightmap coordinate [0.0, 1.0]
 * Output: block light intensity in [0.0, 1.0]
 */
float getBlockLight(vec2 lightmapCoord) {
    // Block light is in X channel, normalize from 0-15 to 0.0-1.0
    return lightmapCoord.x;
}

/**
 * Extracts sky light intensity from Minecraft lightmap.
 * 
 * Minecraft stores sky light in the Y channel (0-15).
 * This function extracts and normalizes sky light to [0.0, 1.0].
 * 
 * Input: lightmapCoord - normalized lightmap coordinate [0.0, 1.0]
 * Output: sky light intensity in [0.0, 1.0]
 */
float getSkyLight(vec2 lightmapCoord) {
    // Sky light is in Y channel, normalize from 0-15 to 0.0-1.0
    return lightmapCoord.y;
}

// ============================================================================
// COLOR SPACE CONVERSION (LINEAR ↔ SRGB)
// ============================================================================

/**
 * Converts linear RGB color to sRGB color space.
 * 
 * sRGB is the standard color space for display output. This function applies
 * the sRGB gamma curve to convert from linear (physically-accurate) to sRGB
 * (perceptually-accurate) color space.
 * 
 * Formula: sRGB = linear^(1/2.2) for linear > 0.0031308
 *          sRGB = 12.92 * linear for linear <= 0.0031308
 * 
 * Input: linearColor - color in linear RGB space
 * Output: color in sRGB space
 * 
 * Validates: Requirement 8 (Advanced Tonemapping)
 */
vec3 linearToSRGB(vec3 linearColor) {
    // Apply sRGB gamma curve
    // For values > 0.0031308, use power curve
    // For values <= 0.0031308, use linear approximation
    bvec3 cutoff = lessThanEqual(linearColor, vec3(0.0031308));
    vec3 lower = linearColor * 12.92;
    vec3 upper = 1.055 * pow(linearColor, vec3(1.0 / 2.2)) - 0.055;
    return mix(upper, lower, cutoff);
}

/**
 * Converts sRGB color to linear RGB color space.
 * 
 * Linear RGB is used for physically-accurate lighting calculations.
 * This function removes the sRGB gamma curve to convert from sRGB
 * (perceptually-accurate) to linear (physically-accurate) color space.
 * 
 * Formula: linear = sRGB^2.2 for sRGB > 0.04045
 *          linear = sRGB / 12.92 for sRGB <= 0.04045
 * 
 * Input: srgbColor - color in sRGB space
 * Output: color in linear RGB space
 * 
 * Validates: Requirement 8 (Advanced Tonemapping)
 */
vec3 sRGBToLinear(vec3 srgbColor) {
    // Remove sRGB gamma curve
    // For values > 0.04045, use power curve
    // For values <= 0.04045, use linear approximation
    bvec3 cutoff = lessThanEqual(srgbColor, vec3(0.04045));
    vec3 lower = srgbColor / 12.92;
    vec3 upper = pow((srgbColor + 0.055) / 1.055, vec3(2.2));
    return mix(upper, lower, cutoff);
}

/**
 * Fast approximation of linear to sRGB conversion.
 * 
 * Uses a simple power function without the piecewise linear approximation.
 * Faster but less accurate than linearToSRGB. Suitable for real-time rendering
 * where the small error is acceptable.
 * 
 * Input: linearColor - color in linear RGB space
 * Output: approximate sRGB color
 */
vec3 linearToSRGBFast(vec3 linearColor) {
    // Fast approximation: just apply gamma 1/2.2
    return pow(linearColor, vec3(1.0 / 2.2));
}

/**
 * Fast approximation of sRGB to linear conversion.
 * 
 * Uses a simple power function without the piecewise linear approximation.
 * Faster but less accurate than sRGBToLinear. Suitable for real-time rendering.
 * 
 * Input: srgbColor - color in sRGB space
 * Output: approximate linear RGB color
 */
vec3 sRGBToLinearFast(vec3 srgbColor) {
    // Fast approximation: just apply gamma 2.2
    return pow(srgbColor, vec3(2.2));
}

// ============================================================================
// HERMITE SMOOTHSTEP FOR SMOOTH TRANSITIONS
// ============================================================================

/**
 * Hermite smoothstep function for smooth interpolation.
 * 
 * Provides smooth, continuous transitions between 0.0 and 1.0 using
 * Hermite polynomial interpolation. The curve has zero velocity at both
 * endpoints, creating smooth acceleration and deceleration.
 * 
 * Formula: t = clamp((x - edge0) / (edge1 - edge0), 0.0, 1.0)
 *          result = t * t * (3.0 - 2.0 * t)
 * 
 * Input: x - input value
 *        edge0 - lower edge (where output = 0.0)
 *        edge1 - upper edge (where output = 1.0)
 * Output: smoothly interpolated value in [0.0, 1.0]
 * 
 * Validates: Requirement 7 (Visual State System)
 */
float hermiteSmootstep(float x, float edge0, float edge1) {
    // Normalize x to [0.0, 1.0] range
    float t = clamp((x - edge0) / (edge1 - edge0), 0.0, 1.0);
    
    // Apply Hermite polynomial: t * t * (3.0 - 2.0 * t)
    // This is equivalent to: 3*t^2 - 2*t^3
    return t * t * (3.0 - 2.0 * t);
}

/**
 * Smoother smoothstep function (quintic Hermite).
 * 
 * Provides even smoother transitions than hermiteSmootstep using a quintic
 * polynomial. The curve has zero velocity AND zero acceleration at endpoints,
 * creating ultra-smooth transitions.
 * 
 * Formula: t = clamp((x - edge0) / (edge1 - edge0), 0.0, 1.0)
 *          result = t * t * t * (t * (t * 6.0 - 15.0) + 10.0)
 * 
 * Input: x - input value
 *        edge0 - lower edge (where output = 0.0)
 *        edge1 - upper edge (where output = 1.0)
 * Output: smoothly interpolated value in [0.0, 1.0]
 * 
 * Validates: Requirement 7 (Visual State System)
 */
float smootherSmootstep(float x, float edge0, float edge1) {
    // Normalize x to [0.0, 1.0] range
    float t = clamp((x - edge0) / (edge1 - edge0), 0.0, 1.0);
    
    // Apply quintic polynomial: t^3 * (t * (t * 6 - 15) + 10)
    // This is equivalent to: 6*t^5 - 15*t^4 + 10*t^3
    return t * t * t * (t * (t * 6.0 - 15.0) + 10.0);
}

/**
 * Blend factor interpolation using Hermite curves.
 * 
 * Calculates smooth blend factor transitions between visual states using
 * Hermite smoothstep. This is the core function for the Visual State System.
 * 
 * Input: t - normalized time parameter (0.0 to 1.0)
 * Output: blend factor in [0.0, 1.0]
 * 
 * Validates: Requirement 7 (Visual State System)
 */
float blendFactorHermite(float t) {
    // Use Hermite smoothstep for smooth blend factor interpolation
    return hermiteSmootstep(t, 0.0, 1.0);
}

// ============================================================================
// BLUE NOISE SAMPLING FOR TAA JITTER
// ============================================================================

/**
 * Generates blue noise jitter pattern for TAA.
 * 
 * Blue noise provides low-discrepancy sampling patterns that are perceptually
 * superior to random noise. This function generates a blue noise sample based
 * on screen coordinates and frame number.
 * 
 * Input: screenCoord - screen-space coordinate (typically gl_FragCoord.xy)
 *        frameNumber - current frame number (typically frameCounter)
 * Output: blue noise value in [0.0, 1.0]
 * 
 * Note: This is a procedural approximation. For best results, use a precomputed
 * blue noise texture, but this function provides reasonable results for TAA.
 * 
 * Validates: Requirement 4 (Temporal Anti-Aliasing)
 */
float blueNoiseSample(vec2 screenCoord, int frameNumber) {
    // Procedural blue noise using interleaved gradient noise
    // This approximates blue noise characteristics without a texture
    
    // Create a pseudo-random seed from screen coordinates and frame
    vec3 seed = vec3(screenCoord, float(frameNumber));
    
    // Interleaved gradient noise (IGN) - provides blue noise-like properties
    // Based on: "Interleaved Gradient Noise" by Jimenez et al.
    float x = dot(seed, vec3(12.9898, 78.233, 45.164));
    float noise = fract(sin(x) * 43758.5453);
    
    return noise;
}

/**
 * Generates 2D blue noise jitter for TAA.
 * 
 * Produces a 2D jitter vector suitable for TAA subpixel sampling.
 * The jitter is in normalized screen space [-0.5, 0.5].
 * 
 * Input: screenCoord - screen-space coordinate
 *        frameNumber - current frame number
 * Output: 2D jitter vector in [-0.5, 0.5] range
 * 
 * Validates: Requirement 4 (Temporal Anti-Aliasing)
 */
vec2 blueNoiseJitter2D(vec2 screenCoord, int frameNumber) {
    // Generate two independent blue noise samples
    float noise1 = blueNoiseSample(screenCoord, frameNumber);
    float noise2 = blueNoiseSample(screenCoord + vec2(0.5), frameNumber);
    
    // Convert to [-0.5, 0.5] range for subpixel jitter
    return vec2(noise1 - 0.5, noise2 - 0.5);
}

/**
 * Generates Halton sequence sample for TAA (alternative to blue noise).
 * 
 * Halton sequences provide low-discrepancy sampling patterns.
 * This function generates a 2D Halton sample for frame-based jitter.
 * 
 * Input: frameNumber - current frame number (0, 1, 2, ...)
 * Output: 2D Halton sample in [0.0, 1.0] range
 * 
 * Validates: Requirement 4 (Temporal Anti-Aliasing)
 */
vec2 haltonSequence(int frameNumber) {
    // Halton sequence with bases 2 and 3
    // Provides low-discrepancy sampling for TAA
    
    // Halton base 2
    float x = 0.0;
    float f = 0.5;
    int n = frameNumber;
    while (n > 0) {
        x += f * float(n & 1);
        f *= 0.5;
        n >>= 1;
    }
    
    // Halton base 3
    float y = 0.0;
    f = 1.0 / 3.0;
    n = frameNumber;
    while (n > 0) {
        y += f * float(n % 3);
        f /= 3.0;
        n /= 3;
    }
    
    return vec2(x, y);
}

// ============================================================================
// COMMON MATH UTILITIES
// ============================================================================

/**
 * Safe division that prevents division by zero.
 * 
 * Returns a default value if the denominator is too close to zero.
 * Useful for preventing NaN and Inf values in calculations.
 * 
 * Input: numerator - the dividend
 *        denominator - the divisor
 *        defaultValue - value to return if denominator ≈ 0
 * Output: numerator / denominator, or defaultValue if denominator ≈ 0
 */
float safeDivide(float numerator, float denominator, float defaultValue) {
    // Check if denominator is close to zero (epsilon = 1e-6)
    if (abs(denominator) < 1e-6) {
        return defaultValue;
    }
    return numerator / denominator;
}

/**
 * Safe division for vectors.
 * 
 * Component-wise safe division for vec3 or vec4.
 * 
 * Input: numerator - the dividend vector
 *        denominator - the divisor vector
 *        defaultValue - value to return for components where denominator ≈ 0
 * Output: component-wise division with safety checks
 */
vec3 safeDivideVec3(vec3 numerator, vec3 denominator, vec3 defaultValue) {
    return vec3(
        safeDivide(numerator.x, denominator.x, defaultValue.x),
        safeDivide(numerator.y, denominator.y, defaultValue.y),
        safeDivide(numerator.z, denominator.z, defaultValue.z)
    );
}

/**
 * Fade function for smooth transitions (Perlin noise style).
 * 
 * Provides a smooth fade curve commonly used in procedural noise generation.
 * Equivalent to: 6*t^5 - 15*t^4 + 10*t^3
 * 
 * Input: t - input value (typically 0.0 to 1.0)
 * Output: faded value with smooth acceleration/deceleration
 */
float fade(float t) {
    // Perlin noise fade function: 6t^5 - 15t^4 + 10t^3
    return t * t * t * (t * (t * 6.0 - 15.0) + 10.0);
}

/**
 * Linear fade function (simple linear interpolation).
 * 
 * Basic linear interpolation between 0.0 and 1.0.
 * 
 * Input: t - input value (typically 0.0 to 1.0)
 * Output: linearly interpolated value
 */
float linearFade(float t) {
    return clamp(t, 0.0, 1.0);
}

/**
 * Quadratic fade function (ease-in-out).
 * 
 * Provides quadratic easing for smooth transitions.
 * 
 * Input: t - input value (typically 0.0 to 1.0)
 * Output: quadratically eased value
 */
float quadraticFade(float t) {
    t = clamp(t, 0.0, 1.0);
    return t < 0.5 ? 2.0 * t * t : -1.0 + (4.0 - 2.0 * t) * t;
}

/**
 * Cubic fade function (ease-in-out).
 * 
 * Provides cubic easing for smooth transitions.
 * 
 * Input: t - input value (typically 0.0 to 1.0)
 * Output: cubically eased value
 */
float cubicFade(float t) {
    t = clamp(t, 0.0, 1.0);
    return t < 0.5 ? 4.0 * t * t * t : 1.0 + (t - 1.0) * (2.0 * (t - 2.0) * (t - 2.0));
}

/**
 * Clamps a value to a range and returns the clamped value.
 * 
 * Standard clamping function.
 * 
 * Input: value - value to clamp
 *        minVal - minimum value
 *        maxVal - maximum value
 * Output: clamped value in [minVal, maxVal]
 */
float clampRange(float value, float minVal, float maxVal) {
    return clamp(value, minVal, maxVal);
}

/**
 * Remaps a value from one range to another.
 * 
 * Converts a value from [inMin, inMax] to [outMin, outMax].
 * 
 * Input: value - value to remap
 *        inMin - input range minimum
 *        inMax - input range maximum
 *        outMin - output range minimum
 *        outMax - output range maximum
 * Output: remapped value in [outMin, outMax]
 */
float remap(float value, float inMin, float inMax, float outMin, float outMax) {
    // Normalize to [0, 1]
    float normalized = (value - inMin) / (inMax - inMin);
    // Remap to output range
    return outMin + normalized * (outMax - outMin);
}

/**
 * Checks if a value is within a range (inclusive).
 * 
 * Input: value - value to check
 *        minVal - minimum value
 *        maxVal - maximum value
 * Output: true if value is in [minVal, maxVal], false otherwise
 */
bool inRange(float value, float minVal, float maxVal) {
    return value >= minVal && value <= maxVal;
}

/**
 * Calculates the distance between two points.
 * 
 * Input: p1 - first point
 *        p2 - second point
 * Output: Euclidean distance between p1 and p2
 */
float distance(vec3 p1, vec3 p2) {
    return length(p1 - p2);
}

/**
 * Calculates squared distance (faster than distance when comparison is needed).
 * 
 * Input: p1 - first point
 *        p2 - second point
 * Output: squared Euclidean distance between p1 and p2
 */
float distanceSquared(vec3 p1, vec3 p2) {
    vec3 diff = p1 - p2;
    return dot(diff, diff);
}

/**
 * Converts RGB color to grayscale using luminance weights.
 * 
 * Uses standard luminance formula: 0.299*R + 0.587*G + 0.114*B
 * 
 * Input: color - RGB color
 * Output: grayscale value in [0.0, 1.0]
 */
float rgbToGrayscale(vec3 color) {
    return dot(color, vec3(0.299, 0.587, 0.114));
}

/**
 * Converts RGB to HSV (Hue, Saturation, Value).
 * 
 * Input: rgb - RGB color in [0.0, 1.0]
 * Output: HSV color (H in [0.0, 1.0], S in [0.0, 1.0], V in [0.0, 1.0])
 */
vec3 rgbToHsv(vec3 rgb) {
    float maxC = max(rgb.r, max(rgb.g, rgb.b));
    float minC = min(rgb.r, min(rgb.g, rgb.b));
    float delta = maxC - minC;
    
    // Value
    float v = maxC;
    
    // Saturation
    float s = safeDivide(delta, maxC, 0.0);
    
    // Hue
    float h = 0.0;
    if (delta > 0.0) {
        if (maxC == rgb.r) {
            h = mod((rgb.g - rgb.b) / delta, 6.0) / 6.0;
        } else if (maxC == rgb.g) {
            h = ((rgb.b - rgb.r) / delta + 2.0) / 6.0;
        } else {
            h = ((rgb.r - rgb.g) / delta + 4.0) / 6.0;
        }
    }
    
    return vec3(h, s, v);
}

/**
 * Converts HSV to RGB.
 * 
 * Input: hsv - HSV color (H in [0.0, 1.0], S in [0.0, 1.0], V in [0.0, 1.0])
 * Output: RGB color in [0.0, 1.0]
 */
vec3 hsvToRgb(vec3 hsv) {
    float h = hsv.x * 6.0;
    float s = hsv.y;
    float v = hsv.z;
    
    float c = v * s;
    float x = c * (1.0 - abs(mod(h, 2.0) - 1.0));
    float m = v - c;
    
    vec3 rgb;
    if (h < 1.0) {
        rgb = vec3(c, x, 0.0);
    } else if (h < 2.0) {
        rgb = vec3(x, c, 0.0);
    } else if (h < 3.0) {
        rgb = vec3(0.0, c, x);
    } else if (h < 4.0) {
        rgb = vec3(0.0, x, c);
    } else if (h < 5.0) {
        rgb = vec3(x, 0.0, c);
    } else {
        rgb = vec3(c, 0.0, x);
    }
    
    return rgb + m;
}

#endif // UTILS_GLSL
