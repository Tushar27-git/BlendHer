/*
 * LabPBR 1.3 Material Decoding Functions
 * 
 * This file contains all functions for decoding LabPBR 1.3 material data from textures.
 * LabPBR 1.3 is a physically-based rendering material standard that encodes material
 * properties in normal and specular textures.
 * 
 * Reference: Requirement 2 (LabPBR 1.3 Material Support)
 * 
 * Texture Formats:
 * - Normal Texture (_n): RG normals + AO (B) + height (A)
 * - Specular Texture (_s): smoothness (R) + F0/metals (G) + porosity/SSS (B) + emission (A)
 */

#ifndef MATERIAL_GLSL
#define MATERIAL_GLSL

// ============================================================================
// Normal Texture Decoding
// ============================================================================

/**
 * Decodes a LabPBR 1.3 normal texture into normal vector, AO, and height.
 * 
 * Input format (from texture):
 * - R: Normal X (left-right orientation) [0, 255] → [-1, 1]
 * - G: Normal Y (up-down orientation, DirectX format Y-down) [0, 255] → [-1, 1]
 * - B: Ambient Occlusion [0, 255] → [0, 1]
 * - A: Height/Displacement [0, 255] → [0, 1]
 * 
 * Output:
 * - normal: Reconstructed 3D normal vector (normalized)
 * - ao: Ambient occlusion factor [0, 1]
 * - height: Height/displacement value [0, 1]
 * 
 * Validates: Requirement 2.1 (Decode normal texture)
 */
void decodeNormalTexture(
    in vec4 normalTexel,
    out vec3 normal,
    out float ao,
    out float height
) {
    // Decode XY components from [0, 1] to [-1, 1]
    normal.x = normalTexel.r * 2.0 - 1.0;
    normal.y = normalTexel.g * 2.0 - 1.0;
    
    // Reconstruct Z from XY using unit normal constraint: x² + y² + z² = 1
    // z = sqrt(1 - x² - y²), clamped to prevent NaN from floating point errors
    float xy_dot = dot(normal.xy, normal.xy);
    normal.z = sqrt(max(0.0, 1.0 - xy_dot));
    
    // Normalize to ensure unit length (handles edge cases)
    normal = normalize(normal);
    
    // Decode AO from blue channel [0, 1]
    // 0 = fully occluded, 1 = no occlusion
    ao = normalTexel.b;
    
    // Decode height from alpha channel [0, 1]
    // Used for parallax occlusion mapping and surface detail
    height = normalTexel.a;
}

/**
 * Simplified version that only decodes the normal vector.
 * Useful when AO and height are not needed.
 * 
 * Validates: Requirement 2.1 (Decode normal texture)
 */
vec3 decodeNormal(in vec4 normalTexel) {
    vec3 normal;
    normal.x = normalTexel.r * 2.0 - 1.0;
    normal.y = normalTexel.g * 2.0 - 1.0;
    normal.z = sqrt(max(0.0, 1.0 - dot(normal.xy, normal.xy)));
    return normalize(normal);
}

/**
 * Decodes only the AO value from a normal texture.
 * 
 * Validates: Requirement 2.1 (Extract AO from B)
 */
float decodeAO(in vec4 normalTexel) {
    return normalTexel.b;
}

/**
 * Decodes only the height value from a normal texture.
 * 
 * Validates: Requirement 2.1 (Extract height from A)
 */
float decodeHeight(in vec4 normalTexel) {
    return normalTexel.a;
}

// ============================================================================
// Specular Texture Decoding
// ============================================================================

/**
 * Decodes a LabPBR 1.3 specular texture into material properties.
 * 
 * Input format (from texture):
 * - R: Perceptual smoothness [0, 255] → [0, 1]
 * - G: F0/Reflectance or metal ID [0, 255]
 *   - [0-229]: Linear F0 values [0, 1]
 *   - [230-254]: Predefined metal IDs
 *   - 255: Reserved (ignored)
 * - B: Porosity/SSS [0, 255]
 *   - [0-64]: Porosity [0, 1]
 *   - [65-255]: Subsurface scattering [0, 1]
 * - A: Emissive intensity [0, 254] → [0, 1]
 *   - 255: Reserved (ignored)
 * 
 * Output:
 * - smoothness: Perceptual smoothness [0, 1]
 * - roughness: Perceptual roughness [0, 1] (1 - smoothness)
 * - f0: Fresnel reflectance value [0, 1] or metal F0 (RGB)
 * - porosity: Porosity/wetness factor [0, 1]
 * - sss: Subsurface scattering factor [0, 1]
 * - emission: Emissive intensity [0, 1]
 * 
 * Validates: Requirement 2.2 (Decode specular texture)
 */
void decodeSpecularTexture(
    in vec4 specularTexel,
    out float smoothness,
    out float roughness,
    out vec3 f0,
    out float porosity,
    out float sss,
    out float emission
) {
    // Decode smoothness from red channel [0, 1]
    smoothness = specularTexel.r;
    
    // Calculate roughness as inverse of smoothness
    // roughness = 1 - smoothness
    roughness = 1.0 - smoothness;
    
    // Decode F0/metal ID from green channel
    uint f0Id = uint(round(specularTexel.g * 255.0));
    
    // Determine F0 based on ID
    if (f0Id >= 230u && f0Id <= 237u) {
        // Predefined metal - use metal F0 lookup
        f0 = getMetalF0(f0Id);
    } else if (f0Id == 255u) {
        // Reserved value - use dielectric default
        f0 = vec3(0.04);
    } else {
        // Linear F0 for dielectrics [0-229]
        // Map [0, 229] to [0, 1] range
        float f0Value = float(f0Id) / 255.0;
        f0 = vec3(f0Value);
    }
    
    // Decode porosity/SSS from blue channel
    uint porositySssId = uint(round(specularTexel.b * 255.0));
    
    if (porositySssId <= 64u) {
        // Porosity mode [0-64]
        porosity = float(porositySssId) / 64.0;
        sss = 0.0;
    } else {
        // Subsurface scattering mode [65-255]
        porosity = 0.0;
        sss = float(porositySssId - 65u) / 190.0;
    }
    
    // Decode emission from alpha channel [0, 254]
    // Value 255 is reserved and ignored
    uint emissionId = uint(round(specularTexel.a * 255.0));
    if (emissionId == 255u) {
        emission = 0.0;
    } else {
        emission = float(emissionId) / 254.0;
    }
}

/**
 * Simplified version that only decodes smoothness and F0.
 * Useful for basic PBR calculations.
 * 
 * Validates: Requirement 2.2 (Extract smoothness and F0)
 */
void decodeSpecularSimple(
    in vec4 specularTexel,
    out float smoothness,
    out vec3 f0
) {
    smoothness = specularTexel.r;
    
    uint f0Id = uint(round(specularTexel.g * 255.0));
    
    if (f0Id >= 230u && f0Id <= 237u) {
        f0 = getMetalF0(f0Id);
    } else if (f0Id == 255u) {
        f0 = vec3(0.04);
    } else {
        f0 = vec3(float(f0Id) / 255.0);
    }
}

/**
 * Decodes only the smoothness value from a specular texture.
 * 
 * Validates: Requirement 2.2 (Extract smoothness)
 */
float decodeSmoothness(in vec4 specularTexel) {
    return specularTexel.r;
}

/**
 * Decodes only the roughness value from a specular texture.
 * Roughness = 1 - smoothness
 * 
 * Validates: Requirement 2.2 (Extract smoothness)
 */
float decodeRoughness(in vec4 specularTexel) {
    return 1.0 - specularTexel.r;
}

/**
 * Decodes only the F0/metal ID from a specular texture.
 * Returns the F0 value as a vec3 (handles both linear F0 and metal F0).
 * 
 * Validates: Requirement 2.2 (Extract F0/metals)
 */
vec3 decodeF0(in vec4 specularTexel) {
    uint f0Id = uint(round(specularTexel.g * 255.0));
    
    if (f0Id >= 230u && f0Id <= 237u) {
        return getMetalF0(f0Id);
    } else if (f0Id == 255u) {
        return vec3(0.04);
    } else {
        return vec3(float(f0Id) / 255.0);
    }
}

/**
 * Decodes only the porosity/SSS value from a specular texture.
 * Returns porosity in x, sss in y.
 * 
 * Validates: Requirement 2.2 (Extract porosity/SSS)
 */
vec2 decodePorositySSS(in vec4 specularTexel) {
    uint porositySssId = uint(round(specularTexel.b * 255.0));
    
    if (porositySssId <= 64u) {
        return vec2(float(porositySssId) / 64.0, 0.0);
    } else {
        return vec2(0.0, float(porositySssId - 65u) / 190.0);
    }
}

/**
 * Decodes only the emission value from a specular texture.
 * 
 * Validates: Requirement 2.2 (Extract emission)
 */
float decodeEmission(in vec4 specularTexel) {
    uint emissionId = uint(round(specularTexel.a * 255.0));
    if (emissionId == 255u) {
        return 0.0;
    } else {
        return float(emissionId) / 254.0;
    }
}

// ============================================================================
// Metal F0 Lookup Table
// ============================================================================

/**
 * Predefined metal F0 values (complex refractive index N).
 * These values are used for physically-accurate metal rendering.
 * 
 * Metal IDs [230-237]:
 * - 230: Iron (N: 2.91, 2.95, 2.58)
 * - 231: Gold (N: 0.18, 0.42, 1.37)
 * - 232: Aluminum (N: 1.35, 0.97, 0.62)
 * - 233: Chrome (N: 3.11, 3.18, 2.32)
 * - 234: Copper (N: 0.27, 0.68, 1.32)
 * - 235: Lead (N: 1.91, 1.83, 1.44)
 * - 236: Platinum (N: 2.38, 2.08, 1.85)
 * - 237: Silver (N: 0.16, 0.15, 0.14)
 * 
 * Validates: Requirement 2.3 (Metal F0 lookup for predefined metals)
 */
vec3 getMetalF0(uint metalId) {
    switch(metalId) {
        case 230u: return vec3(2.91, 2.95, 2.58);  // Iron
        case 231u: return vec3(0.18, 0.42, 1.37);  // Gold
        case 232u: return vec3(1.35, 0.97, 0.62);  // Aluminum
        case 233u: return vec3(3.11, 3.18, 2.32);  // Chrome
        case 234u: return vec3(0.27, 0.68, 1.32);  // Copper
        case 235u: return vec3(1.91, 1.83, 1.44);  // Lead
        case 236u: return vec3(2.38, 2.08, 1.85);  // Platinum
        case 237u: return vec3(0.16, 0.15, 0.14);  // Silver
        default:  return vec3(0.04);               // Dielectric default
    }
}

/**
 * Checks if a given F0 ID is a predefined metal.
 * 
 * Validates: Requirement 2.3 (Metal F0 lookup for predefined metals)
 */
bool isMetalF0(uint f0Id) {
    return f0Id >= 230u && f0Id <= 237u;
}

/**
 * Checks if a given F0 ID is a linear dielectric F0 value.
 * 
 * Validates: Requirement 2.4 (Linear F0 handling for dielectrics)
 */
bool isDielectricF0(uint f0Id) {
    return f0Id < 230u;
}

// ============================================================================
// Linear F0 Handling for Dielectrics
// ============================================================================

/**
 * Converts a linear F0 ID [0-229] to a normalized F0 value [0, 1].
 * 
 * For dielectric materials, F0 typically ranges from 0.02 to 0.08.
 * This function maps the 8-bit ID to the full [0, 1] range for flexibility.
 * 
 * Validates: Requirement 2.4 (Linear F0 handling for dielectrics)
 */
float linearF0ToValue(uint f0Id) {
    // Clamp to valid dielectric range [0-229]
    f0Id = min(f0Id, 229u);
    return float(f0Id) / 255.0;
}

/**
 * Converts a linear F0 value [0, 1] to an 8-bit ID [0-229].
 * Inverse of linearF0ToValue.
 * 
 * Validates: Requirement 2.4 (Linear F0 handling for dielectrics)
 */
uint valueToLinearF0(float f0Value) {
    uint id = uint(round(f0Value * 255.0));
    return min(id, 229u);
}

/**
 * Gets the default F0 value for a dielectric material.
 * Most dielectrics have F0 ≈ 0.04 (4% reflectance).
 * 
 * Validates: Requirement 2.4 (Linear F0 handling for dielectrics)
 */
vec3 getDielectricF0() {
    return vec3(0.04);
}

// ============================================================================
// Combined Material Decoding
// ============================================================================

/**
 * Complete material decoding from both normal and specular textures.
 * This is the primary function for decoding full LabPBR 1.3 materials.
 * 
 * Validates: Requirements 2.1-2.4 (Complete LabPBR 1.3 decoding)
 */
struct Material {
    vec3 normal;        // Surface normal (normalized)
    float ao;           // Ambient occlusion [0, 1]
    float height;       // Height/displacement [0, 1]
    float smoothness;   // Perceptual smoothness [0, 1]
    float roughness;    // Perceptual roughness [0, 1]
    vec3 f0;            // Fresnel reflectance [0, 1] or metal F0
    float porosity;     // Porosity/wetness [0, 1]
    float sss;          // Subsurface scattering [0, 1]
    float emission;     // Emissive intensity [0, 1]
};

/**
 * Decodes a complete LabPBR 1.3 material from normal and specular textures.
 * 
 * Validates: Requirements 2.1-2.4 (Complete LabPBR 1.3 decoding)
 */
Material decodeMaterial(in vec4 normalTexel, in vec4 specularTexel) {
    Material mat;
    
    // Decode normal texture
    decodeNormalTexture(normalTexel, mat.normal, mat.ao, mat.height);
    
    // Decode specular texture
    decodeSpecularTexture(
        specularTexel,
        mat.smoothness,
        mat.roughness,
        mat.f0,
        mat.porosity,
        mat.sss,
        mat.emission
    );
    
    return mat;
}

#endif // MATERIAL_GLSL


// ============================================================================
// NORMAL ENCODING FOR G-BUFFER WRITING
// ============================================================================

/**
 * Encodes a normal vector for storage in G-buffer (colortex1 RG channels).
 * 
 * Converts a 3D normal vector to 2D encoded format suitable for storage
 * in texture RG channels. This is the inverse of decodeNormal.
 * 
 * Input: normal - surface normal vector (should be normalized)
 * Output: encoded normal in [0, 1] range for RG channels
 * 
 * Validates: Requirement 2.1 (Encode normal texture)
 */
vec2 encodeNormal(vec3 normal) {
    // Normalize input to ensure unit length
    normal = normalize(normal);
    
    // Encode XY components from [-1, 1] to [0, 1]
    vec2 encoded;
    encoded.x = normal.x * 0.5 + 0.5;
    encoded.y = normal.y * 0.5 + 0.5;
    
    // Clamp to ensure valid range
    encoded = clamp(encoded, vec2(0.0), vec2(1.0));
    
    return encoded;
}

/**
 * Encodes a complete normal texture data for G-buffer writing.
 * 
 * Encodes normal, AO, and height into the format used by colortex1.
 * 
 * Input: normal - surface normal vector (normalized)
 *        ao - ambient occlusion factor [0, 1]
 *        height - height/displacement value [0, 1]
 * Output: vec4 for colortex1 (RG = encoded normal, B = AO, A = height)
 * 
 * Validates: Requirement 2.1 (Encode normal texture)
 */
vec4 encodeNormalTexture(vec3 normal, float ao, float height) {
    // Encode normal to RG
    vec2 encodedNormal = encodeNormal(normal);
    
    // Clamp AO and height to valid ranges
    ao = clamp(ao, 0.0, 1.0);
    height = clamp(height, 0.0, 1.0);
    
    // Pack into vec4
    return vec4(encodedNormal, ao, height);
}

/**
 * Encodes specular texture data for G-buffer writing.
 * 
 * Encodes smoothness, F0/metal ID, porosity/SSS, and emission into
 * the format used by colortex3.
 * 
 * Input: smoothness - perceptual smoothness [0, 1]
 *        f0OrMetalId - F0 value [0, 1] or metal ID [230-254]
 *        porosityOrSSS - porosity [0, 1] or SSS [0, 1]
 *        emission - emissive intensity [0, 1]
 * Output: vec4 for colortex3 (R = smoothness, G = F0/metal, B = porosity/SSS, A = emission)
 * 
 * Validates: Requirement 2.2 (Encode specular texture)
 */
vec4 encodeSpecularTexture(float smoothness, float f0OrMetalId, 
                           float porosityOrSSS, float emission) {
    // Clamp all values to valid ranges
    smoothness = clamp(smoothness, 0.0, 1.0);
    f0OrMetalId = clamp(f0OrMetalId, 0.0, 1.0);
    porosityOrSSS = clamp(porosityOrSSS, 0.0, 1.0);
    emission = clamp(emission, 0.0, 1.0);
    
    // Pack into vec4
    return vec4(smoothness, f0OrMetalId, porosityOrSSS, emission);
}

