/*
 * BlendHer Shader - Modern 2025 Edition
 * Settings Configuration File
 * 
 * GLSL #version 460 core
 * Compatible with Iris 1.8.5+ Fabric 1.21.4+
 * OptiFine compatibility maintained
 * Distant Horizons 2.1+ support
 * 
 * This file defines all shader configuration parameters including:
 * - LabPBR 1.3 material support flags
 * - Cascaded shadow mapping parameters
 * - Temporal anti-aliasing (TAA) configuration
 * - Adaptive quality scaling thresholds
 * - Visual state system parameters
 * - Performance optimization settings
 */

#ifndef SETTINGS_GLSL
#define SETTINGS_GLSL

// ============================================================================
// GLSL VERSION & PLATFORM SUPPORT
// ============================================================================

// Target GLSL version: 460 core (OpenGL 4.6)
// Iris 1.8.5+ Fabric 1.21.4+ primary target
// OptiFine compatibility maintained for broader accessibility
// Distant Horizons 2.1+ support enabled

// ============================================================================
// LABPBR 1.3 MATERIAL SUPPORT FLAGS
// ============================================================================

// Enable LabPBR 1.3 material standard support
#define LABPBR_1_3

// Enable normal map decoding (RG normals + AO in B + height in A)
#define LABPBR_NORMAL_DECODE

// Enable specular texture decoding (smoothness, F0/metals, porosity/SSS, emission)
#define LABPBR_SPECULAR_DECODE

// Enable metal F0 lookup table (predefined metals 230-254)
#define LABPBR_METAL_LOOKUP

// Enable parallax occlusion mapping using height data
#define LABPBR_PARALLAX

// Enable subsurface scattering for organic materials
#define LABPBR_SSS

// Enable porosity/wetness effects
#define LABPBR_POROSITY

// Enable emissive material support
#define LABPBR_EMISSIVE

// ============================================================================
// CASCADED SHADOW MAPPING PARAMETERS
// ============================================================================

// Number of shadow cascades (3-4 recommended)
const int SHADOW_CASCADE_COUNT = 4;

// Shadow map resolution (2K = 2048x2048)
const int SHADOW_MAP_RESOLUTION = 2048;

// Shadow map distance (blocks)
const float SHADOW_DISTANCE = 256.0;

// Cascade split distances (in blocks from camera)
// Cascade 0: 0-64 blocks (high detail)
// Cascade 1: 64-128 blocks (medium detail)
// Cascade 2: 128-256 blocks (low detail)
// Cascade 3: 256+ blocks (fade out)
const vec4 CASCADE_SPLITS = vec4(64.0, 128.0, 256.0, 512.0);

// PCF kernel size (3x3 = 9 samples)
const int PCF_KERNEL_SIZE = 3;

// Adaptive depth bias (NVIDIA: 0.03, AMD: 0.05)
const float SHADOW_BIAS_NVIDIA = 0.03;
const float SHADOW_BIAS_AMD = 0.05;
const float SHADOW_BIAS = SHADOW_BIAS_NVIDIA; // Default to NVIDIA

// Shadow fade distance (blocks beyond which shadows fade)
const float SHADOW_FADE_DISTANCE = 256.0;

// Cascade blend width (smooth transition between cascades)
const float CASCADE_BLEND_WIDTH = 16.0;

// Enable cascade blending for smooth transitions
#define SHADOW_CASCADE_BLEND

// Enable PCF filtering for soft shadows
#define SHADOW_PCF_FILTER

// ============================================================================
// TEMPORAL ANTI-ALIASING (TAA) PARAMETERS
// ============================================================================

// Enable TAA
#define TAA_ENABLED

// TAA sample count (8-16 recommended)
const int TAA_SAMPLE_COUNT = 16;

// TAA history blend weight (1/N where N is sample count)
const float TAA_BLEND_WEIGHT = 1.0 / float(TAA_SAMPLE_COUNT);

// TAA jitter pattern type (0 = blue noise, 1 = Halton sequence)
const int TAA_JITTER_PATTERN = 0;

// TAA disocclusion detection threshold
const float TAA_DISOCCLUSION_THRESHOLD = 0.1;

// TAA velocity clamping (prevents excessive reprojection)
const float TAA_VELOCITY_MAX = 0.5;

// Enable blue noise jitter for smooth convergence
#define TAA_BLUE_NOISE_JITTER

// Enable disocclusion detection and history reset
#define TAA_DISOCCLUSION_DETECTION

// ============================================================================
// ADAPTIVE QUALITY SCALING THRESHOLDS
// ============================================================================

// Enable adaptive quality scaling
#define ADAPTIVE_QUALITY_SCALING

// Scene complexity detection threshold (fragment shader time in microseconds)
const float COMPLEXITY_THRESHOLD_HIGH = 2.0;
const float COMPLEXITY_THRESHOLD_MEDIUM = 1.0;
const float COMPLEXITY_THRESHOLD_LOW = 0.5;

// High complexity: reduce shadow cascade count
const int SHADOW_CASCADE_COUNT_HIGH = 2;

// High complexity: reduce shadow map resolution
const int SHADOW_MAP_RESOLUTION_HIGH = 1024;

// High complexity: reduce bloom blur radius
const int BLOOM_RADIUS_HIGH = 1;

// High complexity: reduce TAA sample count
const int TAA_SAMPLE_COUNT_HIGH = 8;

// Medium complexity: standard settings
// (uses default values defined above)

// Low complexity: increase quality
const int SHADOW_CASCADE_COUNT_LOW = 4;
const int SHADOW_MAP_RESOLUTION_LOW = 2048;
const int BLOOM_RADIUS_LOW = 3;
const int TAA_SAMPLE_COUNT_LOW = 16;

// ============================================================================
// VISUAL STATE SYSTEM PARAMETERS
// ============================================================================

// Enable visual state system (blend factor calculation)
#define VISUAL_STATE_SYSTEM

// Blend factor range [0.0 = Spooklementary, 1.0 = BSL Vibrancy]
const float BLEND_FACTOR_MIN = 0.0;
const float BLEND_FACTOR_MAX = 1.0;

// Transition duration (ticks) for smooth Hermite interpolation
const float TRANSITION_DURATION = 1200.0;

// Noon vibrancy state (blend factor = 1.0)
const float NOON_VIBRANCY_BLEND = 1.0;

// Creeping shadows state (blend factor = 0.0-0.3)
const float CREEPING_SHADOWS_BLEND_MIN = 0.0;
const float CREEPING_SHADOWS_BLEND_MAX = 0.3;

// Sunset purple haze state (blend factor = 0.2-0.8)
const float SUNSET_BLEND_MIN = 0.2;
const float SUNSET_BLEND_MAX = 0.8;

// Playable midnight state (blend factor = 0.1 + cyan tint)
const float MIDNIGHT_BLEND = 0.1;
const vec3 MIDNIGHT_CYAN_TINT = vec3(0.0, 0.6, 0.8);

// Storm state (blend factor = 0.0 + grey-purple shivering)
const float STORM_BLEND = 0.0;
const vec3 STORM_GREY_PURPLE = vec3(0.5, 0.4, 0.6);

// ============================================================================
// EXPONENTIAL FOG PARAMETERS
// ============================================================================

// Enable exponential fog
#define EXPONENTIAL_FOG

// Fog density for BSL (clear, vibrant)
const float FOG_DENSITY_BSL = 0.02;

// Fog density for Spooklementary (heavy, atmospheric)
const float FOG_DENSITY_SPOOKLEMENTARY = 0.15;

// Minimum visibility distance (blocks)
const float FOG_MIN_VISIBILITY = 32.0;

// Storm fog intensity reduction (40-50% of Spooklementary)
const float STORM_FOG_REDUCTION = 0.45;

// ============================================================================
// PURPLE AMBIENT FLOOR PARAMETERS
// ============================================================================

// Enable purple ambient floor (additive blending)
#define PURPLE_AMBIENT_FLOOR

// Purple ambient floor color (RGB)
const vec3 PURPLE_FLOOR_COLOR = vec3(0.4, 0.2, 0.6);

// Purple floor intensity at blend factor 0.0 (maximum)
const float PURPLE_FLOOR_INTENSITY_MAX = 1.0;

// Purple floor intensity at blend factor 1.0 (invisible)
const float PURPLE_FLOOR_INTENSITY_MIN = 0.0;

// Creeping shadows purple floor intensity range
const float PURPLE_FLOOR_CREEPING_MIN = 0.3;
const float PURPLE_FLOOR_CREEPING_MAX = 0.6;

// Sunset purple floor intensity range
const float PURPLE_FLOOR_SUNSET_MIN = 0.2;
const float PURPLE_FLOOR_SUNSET_MAX = 0.5;

// Midnight purple floor intensity range
const float PURPLE_FLOOR_MIDNIGHT_MIN = 0.7;
const float PURPLE_FLOOR_MIDNIGHT_MAX = 0.9;

// Storm purple floor intensity range
const float PURPLE_FLOOR_STORM_MIN = 0.8;
const float PURPLE_FLOOR_STORM_MAX = 1.0;

// ============================================================================
// COOK-TORRANCE PBR LIGHTING PARAMETERS
// ============================================================================

// Enable Cook-Torrance PBR lighting model
#define COOK_TORRANCE_PBR

// Enable Fresnel-Schlick approximation
#define FRESNEL_SCHLICK

// Enable GGX/Trowbridge-Reitz distribution
#define GGX_DISTRIBUTION

// Enable Smith's geometry function with Schlick-Beckmann
#define SMITH_GEOMETRY

// Enable energy conservation check
#define ENERGY_CONSERVATION

// Default F0 for dielectric materials (most non-metals)
const float F0_DIELECTRIC = 0.04;

// Minimum roughness to prevent division by zero
const float MIN_ROUGHNESS = 0.04;

// ============================================================================
// ACES TONEMAPPING PARAMETERS
// ============================================================================

// Enable ACES tonemapping pipeline
#define ACES_TONEMAPPING

// Enable ACES RRT (Reference Rendering Transform)
#define ACES_RRT

// Enable ACES ODT (Output Device Transform) for sRGB
#define ACES_ODT

// Shadow crush power at blend factor 0.0 (maximum crush)
const float SHADOW_CRUSH_POWER_MAX = 1.3;

// Shadow crush power at blend factor 1.0 (no crush)
const float SHADOW_CRUSH_POWER_MIN = 1.0;

// Saturation at blend factor 0.0 (desaturated)
const float SATURATION_MIN = 0.6;

// Saturation at blend factor 1.0 (saturated)
const float SATURATION_MAX = 1.0;

// Vibrance boost at blend factor 0.0 (maximum vibrance)
const float VIBRANCE_MAX = 1.3;

// Vibrance boost at blend factor 1.0 (no vibrance)
const float VIBRANCE_MIN = 1.0;

// ============================================================================
// GERSTNER WAVE WATER PARAMETERS
// ============================================================================

// Enable Gerstner wave water displacement
#define GERSTNER_WAVES

// Number of wave frequency components (4-8 recommended)
const int WAVE_COMPONENT_COUNT = 8;

// Wave displacement amplitude (world-space Y-axis only)
const float WAVE_AMPLITUDE = 0.5;

// Wave frequency base
const float WAVE_FREQUENCY_BASE = 0.1;

// Enable caustic patterns
#define WATER_CAUSTICS

// Caustic animation speed
const float CAUSTIC_SPEED = 0.1;

// ============================================================================
// BLOOM EFFECT PARAMETERS
// ============================================================================

// Enable bloom effect
#define BLOOM_ENABLED

// Bloom radius (1-3, higher = more blur)
const int BLOOM_RADIUS = 3;

// Bloom intensity at blend factor 0.0 (Spooklementary)
const float BLOOM_INTENSITY_MIN = 0.3;

// Bloom intensity at blend factor 1.0 (BSL)
const float BLOOM_INTENSITY_MAX = 0.8;

// Bloom sample count
const int BLOOM_SAMPLE_COUNT = 9;

// ============================================================================
// VIGNETTE PARAMETERS
// ============================================================================

// Enable vignette effect
#define VIGNETTE_ENABLED

// Vignette intensity at blend factor 0.0 (Spooklementary)
const float VIGNETTE_INTENSITY_MIN = 0.3;

// Vignette intensity at blend factor 1.0 (BSL)
const float VIGNETTE_INTENSITY_MAX = 0.1;

// Vignette falloff (higher = sharper edge)
const float VIGNETTE_FALLOFF = 2.0;

// ============================================================================
// PERFORMANCE OPTIMIZATION SETTINGS
// ============================================================================

// Enable screen-space rendering only (no texture3D, raymarching, volumetric)
#define SCREEN_SPACE_ONLY

// VRAM budget (MB)
const float VRAM_BUDGET = 150.0;

// Target compilation time (seconds)
const float COMPILATION_TIME_TARGET = 2.0;

// Target frame time for 60 FPS (milliseconds)
const float FRAME_TIME_60FPS = 16.67;

// Target frame time for 90 FPS (milliseconds)
const float FRAME_TIME_90FPS = 11.11;

// Target frame time for 100+ FPS (milliseconds)
const float FRAME_TIME_100FPS = 10.0;

// ============================================================================
// GBUFFER LAYOUT CONFIGURATION
// ============================================================================

// G-Buffer layout (optimized for 150MB VRAM):
// colortex0: Scene albedo (RGB) + material ID (A) - 8-bit per channel
// colortex1: Normal map (RG) + AO (B) + height (A) - LabPBR format
// colortex2: Lightmap (RG) + material flags (BA) - block/sky light separation
// colortex3: Specular data (RGBA) - smoothness, F0, porosity, emission (LabPBR 1.3)
// colortex4: Velocity buffer (RG) - for TAA reprojection
// depthtex0: Linear depth (24-bit)
// depthtex1: Previous frame depth (for TAA)
// shadowtex0/1: Cascaded shadow maps (2K resolution, 16-bit)

// Enable G-buffer optimization
#define GBUFFER_OPTIMIZED

// ============================================================================
// SHADER PASS PIPELINE CONFIGURATION
// ============================================================================

// Deferred rendering pass (PBR lighting calculations)
#define DEFERRED_PASS

// Composite pass (blend factor application)
#define COMPOSITE_PASS

// TAA resolve pass
#define TAA_RESOLVE_PASS

// Bloom horizontal blur pass
#define BLOOM_HORIZONTAL_PASS

// Bloom vertical blur pass
#define BLOOM_VERTICAL_PASS

// Bloom merge and tone mapping pass
#define BLOOM_MERGE_PASS

// Final pass (vignette and gamma correction)
#define FINAL_PASS

// ============================================================================
// INCLUDE FILE ARCHITECTURE
// ============================================================================

// Modern include file structure:
// - settings.glsl (this file) - centralized configuration
// - uniforms.glsl - shader uniforms (time, camera, weather, blend factor)
// - utils.glsl - utility functions (lightmap normalization, color space, Hermite, blue noise)
// - pbr.glsl - Cook-Torrance PBR implementation
// - lighting.glsl - PBR lighting calculations
// - tonemapping.glsl - ACES tonemapping pipeline
// - atmosphere.glsl - exponential fog, sky color grading
// - shadow.glsl - cascaded shadow system
// - water.glsl - Gerstner wave displacement
// - taa.glsl - temporal anti-aliasing

#endif // SETTINGS_GLSL
