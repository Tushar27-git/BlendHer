/*
 * BlendHer Shader - Modern Atmospheric Effects Library
 * 
 * This library provides the complete atmospheric effects system:
 * - Exponential fog with blend factor modulation
 * - Fog density blending between BSL and Spooklementary
 * - Sky color grading with blend factor adjustment
 * - Cloud rendering with modern curves and blend factor control
 * 
 * The atmospheric system creates a cohesive visual experience by smoothly
 * transitioning between clear, vibrant daylight (BSL) and atmospheric,
 * desaturated darkness (Spooklementary) based on the blend factor.
 * 
 * Reference: Requirement 10 (Exponential Fog)
 * Compatible with: GLSL 460 core, Iris 1.8.5+, OptiFine
 */

#ifndef ATMOSPHERE_GLSL
#define ATMOSPHERE_GLSL

// ============================================================================
// EXPONENTIAL FOG CALCULATION
// ============================================================================
// Exponential fog provides smooth, realistic fog that increases with distance.
// The formula exp(-density * distance²) creates a natural-looking fog effect
// that is commonly used in modern game engines.
//
// Reference: Requirement 10 (Exponential Fog)

/**
 * Calculate exponential fog factor
 * 
 * Computes fog factor using exponential formula: fogFactor = exp(-density * distance²)
 * This creates smooth, realistic fog that increases with distance.
 * 
 * Input: distance - distance from camera to fragment (in blocks)
 *        density - fog density parameter (controls fog intensity)
 * Output: fog factor in [0.0, 1.0]
 *         0.0 = fully fogged (opaque fog)
 *         1.0 = no fog (fully visible)
 * 
 * Validates: Requirement 10 (Exponential Fog)
 */
float exponentialFog(float distance, float density) {
    // Clamp distance to prevent negative values
    distance = max(distance, 0.0);
    
    // Clamp density to valid range
    density = max(density, 0.0);
    
    // Calculate exponential fog: exp(-density * distance²)
    // The squared distance creates a smooth curve that increases fog intensity
    float fogExponent = -density * distance * distance;
    
    // Clamp exponent to prevent numerical issues
    fogExponent = clamp(fogExponent, -100.0, 0.0);
    
    // Calculate fog factor
    float fogFactor = exp(fogExponent);
    
    // Clamp to [0.0, 1.0] range
    return clamp(fogFactor, 0.0, 1.0);
}

/**
 * Calculate exponential fog factor with linear distance
 * 
 * Alternative exponential fog using linear distance instead of squared.
 * Creates a different fog curve that may be more suitable for some scenes.
 * Formula: fogFactor = exp(-density * distance)
 * 
 * Input: distance - distance from camera to fragment (in blocks)
 *        density - fog density parameter (controls fog intensity)
 * Output: fog factor in [0.0, 1.0]
 * 
 * Validates: Requirement 10 (Exponential Fog)
 */
float exponentialFogLinear(float distance, float density) {
    // Clamp distance to prevent negative values
    distance = max(distance, 0.0);
    
    // Clamp density to valid range
    density = max(density, 0.0);
    
    // Calculate exponential fog with linear distance: exp(-density * distance)
    float fogExponent = -density * distance;
    
    // Clamp exponent to prevent numerical issues
    fogExponent = clamp(fogExponent, -100.0, 0.0);
    
    // Calculate fog factor
    float fogFactor = exp(fogExponent);
    
    // Clamp to [0.0, 1.0] range
    return clamp(fogFactor, 0.0, 1.0);
}

// ============================================================================
// FOG DENSITY BLENDING
// ============================================================================
// Fog density is blended between BSL (light fog, 0.02) and Spooklementary
// (heavy fog, 0.15) based on the blend factor. This creates smooth transitions
// between clear daylight and atmospheric darkness.
//
// Reference: Requirement 10 (Exponential Fog)

/**
 * Calculate adaptive fog density based on blend factor
 * 
 * Blends fog density between BSL (light, 0.02) and Spooklementary (heavy, 0.15)
 * based on the blend factor. Higher blend factor = lighter fog (BSL).
 * Lower blend factor = heavier fog (Spooklementary).
 * 
 * Input: blendFactor - blend factor in [0.0, 1.0]
 *                      1.0 = BSL (vibrant, light fog)
 *                      0.0 = Spooklementary (dark, heavy fog)
 * Output: fog density in [0.02, 0.15]
 * 
 * Validates: Requirement 10 (Exponential Fog)
 */
float adaptiveFogDensity(float blendFactor) {
    // Clamp blend factor to valid range
    blendFactor = clamp(blendFactor, 0.0, 1.0);
    
    // Blend between BSL fog (0.02) and Spooklementary fog (0.15)
    // At blend factor 1.0 (BSL): density = 0.02 (light fog)
    // At blend factor 0.0 (Spooklementary): density = 0.15 (heavy fog)
    float fogDensity = mix(0.15, 0.02, blendFactor);
    
    return fogDensity;
}

/**
 * Calculate adaptive fog density with weather modulation
 * 
 * Adjusts fog density based on blend factor and weather conditions.
 * Rain/storms reduce Spooklementary fog intensity by 40-50%.
 * 
 * Input: blendFactor - blend factor in [0.0, 1.0]
 *        rainStrength - rain intensity in [0.0, 1.0]
 * Output: fog density in [0.02, 0.15]
 * 
 * Validates: Requirement 10 (Exponential Fog)
 */
float adaptiveFogDensityWithWeather(float blendFactor, float rainStrength) {
    // Get base fog density from blend factor
    float fogDensity = adaptiveFogDensity(blendFactor);
    
    // Clamp rain strength to valid range
    rainStrength = clamp(rainStrength, 0.0, 1.0);
    
    // In rain/storms, reduce Spooklementary fog intensity by 40-50%
    // This prevents the fog from becoming too oppressive during storms
    // Only affects Spooklementary (low blend factor)
    float rainModifier = mix(0.5, 1.0, blendFactor);
    fogDensity *= mix(rainModifier, 1.0, rainStrength);
    
    return fogDensity;
}

// ============================================================================
// SKY COLOR GRADING
// ============================================================================
// Sky color is graded based on the blend factor to create smooth transitions
// between BSL's vibrant golden daylight and Spooklementary's atmospheric darkness.
//
// Reference: Requirement 10 (Exponential Fog)

/**
 * Apply sky color grading based on blend factor
 * 
 * Adjusts sky color saturation and brightness based on blend factor.
 * Higher blend factor (BSL) = vibrant, saturated sky
 * Lower blend factor (Spooklementary) = desaturated, darker sky
 * 
 * Input: skyColor - original sky color (RGB)
 *        blendFactor - blend factor in [0.0, 1.0]
 * Output: color-graded sky color
 * 
 * Validates: Requirement 10 (Exponential Fog)
 */
vec3 applySkyColorGrading(vec3 skyColor, float blendFactor) {
    // Clamp blend factor to valid range
    blendFactor = clamp(blendFactor, 0.0, 1.0);
    
    // Clamp sky color to valid range
    skyColor = clamp(skyColor, vec3(0.0), vec3(1.0));
    
    // Calculate saturation multiplier based on blend factor
    // At blend factor 1.0 (BSL): saturation = 1.0 (no change)
    // At blend factor 0.0 (Spooklementary): saturation = 0.6 (reduced)
    float saturation = mix(0.6, 1.0, blendFactor);
    
    // Calculate brightness multiplier based on blend factor
    // At blend factor 1.0 (BSL): brightness = 1.0 (no change)
    // At blend factor 0.0 (Spooklementary): brightness = 0.7 (darker)
    float brightness = mix(0.7, 1.0, blendFactor);
    
    // Apply brightness adjustment
    vec3 gradedColor = skyColor * brightness;
    
    // Apply saturation adjustment using desaturation technique
    // Calculate luminance
    float luminance = dot(gradedColor, vec3(0.299, 0.587, 0.114));
    
    // Interpolate between desaturated (luminance) and saturated (original)
    gradedColor = mix(vec3(luminance), gradedColor, saturation);
    
    // Clamp to ensure output is in valid range
    gradedColor = clamp(gradedColor, vec3(0.0), vec3(1.0));
    
    return gradedColor;
}

/**
 * Apply sky color grading with purple tint for Spooklementary
 * 
 * Adds a subtle purple tint to the sky when blend factor is low (Spooklementary).
 * This reinforces the horror aesthetic without making the sky unnatural.
 * 
 * Input: skyColor - original sky color (RGB)
 *        blendFactor - blend factor in [0.0, 1.0]
 * Output: color-graded sky color with optional purple tint
 * 
 * Validates: Requirement 10 (Exponential Fog)
 */
vec3 applySkyColorGradingWithPurpleTint(vec3 skyColor, float blendFactor) {
    // Clamp blend factor to valid range
    blendFactor = clamp(blendFactor, 0.0, 1.0);
    
    // Apply base color grading
    vec3 gradedColor = applySkyColorGrading(skyColor, blendFactor);
    
    // Add purple tint for Spooklementary (low blend factor)
    // Purple tint: RGB(0.4, 0.2, 0.6)
    vec3 purpleTint = vec3(0.4, 0.2, 0.6);
    
    // Calculate purple tint intensity based on blend factor
    // At blend factor 1.0 (BSL): tint intensity = 0.0 (no tint)
    // At blend factor 0.0 (Spooklementary): tint intensity = 0.15 (subtle tint)
    float tintIntensity = mix(0.15, 0.0, blendFactor);
    
    // Apply purple tint using additive blending
    gradedColor = mix(gradedColor, gradedColor + purpleTint * tintIntensity, tintIntensity);
    
    // Clamp to ensure output is in valid range
    gradedColor = clamp(gradedColor, vec3(0.0), vec3(1.0));
    
    return gradedColor;
}

// ============================================================================
// CLOUD RENDERING WITH MODERN CURVES
// ============================================================================
// Cloud rendering uses modern curves and blend factor control to create
// atmospheric clouds that transition between BSL's bright, fluffy clouds
// and Spooklementary's dark, ominous clouds.
//
// Reference: Requirement 10 (Exponential Fog)

/**
 * Calculate cloud density using modern curve
 * 
 * Applies a smooth curve to cloud noise to create natural-looking cloud density.
 * Uses a power curve that emphasizes mid-tones while suppressing extremes.
 * 
 * Input: cloudNoise - raw cloud noise in [0.0, 1.0]
 *        blendFactor - blend factor in [0.0, 1.0]
 * Output: cloud density in [0.0, 1.0]
 * 
 * Validates: Requirement 10 (Exponential Fog)
 */
float calculateCloudDensity(float cloudNoise, float blendFactor) {
    // Clamp inputs to valid range
    cloudNoise = clamp(cloudNoise, 0.0, 1.0);
    blendFactor = clamp(blendFactor, 0.0, 1.0);
    
    // Apply modern curve to cloud noise
    // Use power function to emphasize mid-tones
    // At blend factor 1.0 (BSL): power = 1.5 (softer clouds)
    // At blend factor 0.0 (Spooklementary): power = 1.0 (sharper clouds)
    float curvePower = mix(1.0, 1.5, blendFactor);
    
    // Apply power curve
    float cloudDensity = pow(cloudNoise, curvePower);
    
    // Apply threshold to create more defined cloud shapes
    // At blend factor 1.0 (BSL): threshold = 0.3 (more clouds)
    // At blend factor 0.0 (Spooklementary): threshold = 0.4 (fewer, darker clouds)
    float threshold = mix(0.4, 0.3, blendFactor);
    
    // Apply threshold using smoothstep for smooth transition
    cloudDensity = smoothstep(threshold - 0.1, threshold + 0.1, cloudDensity);
    
    // Clamp to ensure output is in valid range
    return clamp(cloudDensity, 0.0, 1.0);
}

/**
 * Calculate cloud brightness based on blend factor
 * 
 * Adjusts cloud brightness to match the visual state.
 * BSL clouds are bright and fluffy, Spooklementary clouds are dark and ominous.
 * 
 * Input: blendFactor - blend factor in [0.0, 1.0]
 * Output: cloud brightness multiplier
 * 
 * Validates: Requirement 10 (Exponential Fog)
 */
float calculateCloudBrightness(float blendFactor) {
    // Clamp blend factor to valid range
    blendFactor = clamp(blendFactor, 0.0, 1.0);
    
    // Calculate brightness multiplier based on blend factor
    // At blend factor 1.0 (BSL): brightness = 1.0 (bright clouds)
    // At blend factor 0.0 (Spooklementary): brightness = 0.4 (dark clouds)
    float brightness = mix(0.4, 1.0, blendFactor);
    
    return brightness;
}

/**
 * Apply cloud color grading based on blend factor
 * 
 * Adjusts cloud color to match the visual state.
 * BSL clouds are white/golden, Spooklementary clouds are grey/purple.
 * 
 * Input: cloudColor - original cloud color (RGB)
 *        blendFactor - blend factor in [0.0, 1.0]
 * Output: color-graded cloud color
 * 
 * Validates: Requirement 10 (Exponential Fog)
 */
vec3 applyCloudColorGrading(vec3 cloudColor, float blendFactor) {
    // Clamp inputs to valid range
    cloudColor = clamp(cloudColor, vec3(0.0), vec3(1.0));
    blendFactor = clamp(blendFactor, 0.0, 1.0);
    
    // Calculate brightness multiplier
    float brightness = calculateCloudBrightness(blendFactor);
    
    // Apply brightness
    vec3 gradedColor = cloudColor * brightness;
    
    // Add purple tint for Spooklementary (low blend factor)
    // Purple tint: RGB(0.4, 0.2, 0.6)
    vec3 purpleTint = vec3(0.4, 0.2, 0.6);
    
    // Calculate purple tint intensity based on blend factor
    // At blend factor 1.0 (BSL): tint intensity = 0.0 (no tint)
    // At blend factor 0.0 (Spooklementary): tint intensity = 0.2 (noticeable tint)
    float tintIntensity = mix(0.2, 0.0, blendFactor);
    
    // Apply purple tint using additive blending
    gradedColor = mix(gradedColor, gradedColor + purpleTint * tintIntensity, tintIntensity);
    
    // Clamp to ensure output is in valid range
    gradedColor = clamp(gradedColor, vec3(0.0), vec3(1.0));
    
    return gradedColor;
}

/**
 * Calculate cloud coverage based on blend factor
 * 
 * Adjusts cloud coverage to match the visual state.
 * BSL has moderate cloud coverage, Spooklementary has denser clouds.
 * 
 * Input: blendFactor - blend factor in [0.0, 1.0]
 * Output: cloud coverage multiplier in [0.0, 1.0]
 * 
 * Validates: Requirement 10 (Exponential Fog)
 */
float calculateCloudCoverage(float blendFactor) {
    // Clamp blend factor to valid range
    blendFactor = clamp(blendFactor, 0.0, 1.0);
    
    // Calculate coverage multiplier based on blend factor
    // At blend factor 1.0 (BSL): coverage = 0.6 (moderate coverage)
    // At blend factor 0.0 (Spooklementary): coverage = 0.8 (dense coverage)
    float coverage = mix(0.8, 0.6, blendFactor);
    
    return coverage;
}

// ============================================================================
// COMPLETE ATMOSPHERIC EFFECTS
// ============================================================================
// Combines all atmospheric effects in a cohesive system.

/**
 * Apply complete atmospheric effects to scene color
 * 
 * Applies exponential fog with blend factor modulation to create smooth
 * transitions between clear daylight and atmospheric darkness.
 * 
 * Input: sceneColor - original scene color (RGB)
 *        fogColor - fog color (RGB)
 *        distance - distance from camera to fragment (in blocks)
 *        blendFactor - blend factor in [0.0, 1.0]
 * Output: scene color with fog applied
 * 
 * Validates: Requirement 10 (Exponential Fog)
 */
vec3 applyAtmosphericFog(vec3 sceneColor, vec3 fogColor, float distance, float blendFactor) {
    // Clamp inputs to valid range
    sceneColor = clamp(sceneColor, vec3(0.0), vec3(1.0));
    fogColor = clamp(fogColor, vec3(0.0), vec3(1.0));
    distance = max(distance, 0.0);
    blendFactor = clamp(blendFactor, 0.0, 1.0);
    
    // Calculate adaptive fog density based on blend factor
    float fogDensity = adaptiveFogDensity(blendFactor);
    
    // Calculate exponential fog factor
    float fogFactor = exponentialFog(distance, fogDensity);
    
    // Blend scene color with fog color
    vec3 foggedColor = mix(fogColor, sceneColor, fogFactor);
    
    // Ensure minimum visibility (32+ blocks)
    // At distance = 32 blocks, fog factor should be at least 0.5
    float minVisibilityDistance = 32.0;
    float minFogFactor = exponentialFog(minVisibilityDistance, fogDensity);
    
    // If fog is too dense, reduce density to maintain visibility
    if (minFogFactor < 0.5) {
        fogDensity *= 0.5 / minFogFactor;
        fogFactor = exponentialFog(distance, fogDensity);
        foggedColor = mix(fogColor, sceneColor, fogFactor);
    }
    
    // Clamp to ensure output is in valid range
    foggedColor = clamp(foggedColor, vec3(0.0), vec3(1.0));
    
    return foggedColor;
}

/**
 * Apply atmospheric fog with weather modulation
 * 
 * Applies exponential fog with blend factor and weather modulation.
 * Rain/storms reduce Spooklementary fog intensity by 40-50%.
 * 
 * Input: sceneColor - original scene color (RGB)
 *        fogColor - fog color (RGB)
 *        distance - distance from camera to fragment (in blocks)
 *        blendFactor - blend factor in [0.0, 1.0]
 *        rainStrength - rain intensity in [0.0, 1.0]
 * Output: scene color with fog applied
 * 
 * Validates: Requirement 10 (Exponential Fog)
 */
vec3 applyAtmosphericFogWithWeather(vec3 sceneColor, vec3 fogColor, float distance, 
                                     float blendFactor, float rainStrength) {
    // Clamp inputs to valid range
    sceneColor = clamp(sceneColor, vec3(0.0), vec3(1.0));
    fogColor = clamp(fogColor, vec3(0.0), vec3(1.0));
    distance = max(distance, 0.0);
    blendFactor = clamp(blendFactor, 0.0, 1.0);
    rainStrength = clamp(rainStrength, 0.0, 1.0);
    
    // Calculate adaptive fog density with weather modulation
    float fogDensity = adaptiveFogDensityWithWeather(blendFactor, rainStrength);
    
    // Calculate exponential fog factor
    float fogFactor = exponentialFog(distance, fogDensity);
    
    // Blend scene color with fog color
    vec3 foggedColor = mix(fogColor, sceneColor, fogFactor);
    
    // Ensure minimum visibility (32+ blocks)
    float minVisibilityDistance = 32.0;
    float minFogFactor = exponentialFog(minVisibilityDistance, fogDensity);
    
    // If fog is too dense, reduce density to maintain visibility
    if (minFogFactor < 0.5) {
        fogDensity *= 0.5 / minFogFactor;
        fogFactor = exponentialFog(distance, fogDensity);
        foggedColor = mix(fogColor, sceneColor, fogFactor);
    }
    
    // Clamp to ensure output is in valid range
    foggedColor = clamp(foggedColor, vec3(0.0), vec3(1.0));
    
    return foggedColor;
}

/**
 * Calculate visibility distance based on fog density
 * 
 * Calculates the distance at which fog factor reaches a threshold (e.g., 0.5).
 * Useful for determining render distance and LOD calculations.
 * 
 * Input: fogDensity - fog density parameter
 *        threshold - fog factor threshold (default 0.5)
 * Output: visibility distance in blocks
 * 
 * Validates: Requirement 10 (Exponential Fog)
 */
float calculateVisibilityDistance(float fogDensity, float threshold) {
    // Clamp inputs to valid range
    fogDensity = max(fogDensity, 0.001);
    threshold = clamp(threshold, 0.001, 0.999);
    
    // Solve for distance: exp(-density * distance²) = threshold
    // -density * distance² = ln(threshold)
    // distance² = -ln(threshold) / density
    // distance = sqrt(-ln(threshold) / density)
    
    float logThreshold = log(threshold);
    float distanceSquared = -logThreshold / fogDensity;
    
    // Clamp to prevent negative values
    distanceSquared = max(distanceSquared, 0.0);
    
    float distance = sqrt(distanceSquared);
    
    return distance;
}

// ============================================================================
// UTILITY FUNCTIONS
// ============================================================================

/**
 * Check if fog is valid (not NaN or Inf)
 * 
 * Detects invalid floating-point values in fog calculations.
 * 
 * Input: fogFactor - fog factor to check
 * Output: true if fog factor is valid, false otherwise
 */
bool isValidFog(float fogFactor) {
    // Check for NaN: NaN != NaN
    if (fogFactor != fogFactor) {
        return false;
    }
    
    // Check for Inf: Inf > 1e10
    if (abs(fogFactor) > 1e10) {
        return false;
    }
    
    // Check for valid range
    if (fogFactor < 0.0 || fogFactor > 1.0) {
        return false;
    }
    
    return true;
}

/**
 * Safely apply atmospheric fog with validation
 * 
 * Applies atmospheric fog with fallback to scene color if invalid values detected.
 * 
 * Input: sceneColor - original scene color (RGB)
 *        fogColor - fog color (RGB)
 *        distance - distance from camera to fragment (in blocks)
 *        blendFactor - blend factor in [0.0, 1.0]
 * Output: scene color with fog applied, or original scene color if invalid
 */
vec3 safeApplyAtmosphericFog(vec3 sceneColor, vec3 fogColor, float distance, float blendFactor) {
    // Apply atmospheric fog
    vec3 result = applyAtmosphericFog(sceneColor, fogColor, distance, blendFactor);
    
    // Check if result is valid
    if (!isValidFog(result.r) || !isValidFog(result.g) || !isValidFog(result.b)) {
        return sceneColor; // Return original scene color if invalid
    }
    
    return result;
}

#endif // ATMOSPHERE_GLSL
