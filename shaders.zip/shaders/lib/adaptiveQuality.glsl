/*
 * BlendHer Shader - Adaptive Quality Scaling System
 * 
 * GLSL #version 460 core
 * 
 * This include file implements adaptive quality scaling to maintain performance
 * targets (60+ FPS on GTX 1650 Ti, 100+ FPS on RTX 3060/RX 6700) by detecting
 * scene complexity and adjusting quality settings dynamically.
 * 
 * Features:
 * - Scene complexity detection via fragment shader execution time heuristics
 * - Adaptive shadow quality (cascade count, resolution, PCF kernel size)
 * - Adaptive bloom quality (blur radius, sample count)
 * - Adaptive TAA quality (sample count)
 * - Smooth transitions between quality levels
 * - Maintains visual quality in low-complexity scenes
 */

#ifndef ADAPTIVE_QUALITY_GLSL
#define ADAPTIVE_QUALITY_GLSL

#include "settings.glsl"
#include "uniforms.glsl"
#include "utils.glsl"

// ============================================================================
// SCENE COMPLEXITY DETECTION
// ============================================================================

/*
 * Detects scene complexity based on multiple heuristics:
 * 1. Number of active lights (estimated from lightmap intensity)
 * 2. Shadow complexity (cascade count, PCF samples)
 * 3. Effect complexity (bloom, TAA, water effects)
 * 4. Fragment shader execution time estimation
 * 
 * Returns complexity level: 0 = low, 1 = medium, 2 = high
 */

// Complexity level enumeration
const int COMPLEXITY_LOW = 0;
const int COMPLEXITY_MEDIUM = 1;
const int COMPLEXITY_HIGH = 2;

/*
 * Estimate scene complexity from lightmap data
 * 
 * High complexity indicators:
 * - High block light intensity (many light sources)
 * - High sky light intensity (many shadow-casting objects)
 * - Combination of both (complex lighting environment)
 * 
 * Parameters:
 *   blockLight: Normalized block light intensity [0.0, 1.0]
 *   skyLight: Normalized sky light intensity [0.0, 1.0]
 * 
 * Returns: Complexity level (0 = low, 1 = medium, 2 = high)
 */
int estimateLightingComplexity(float blockLight, float skyLight) {
    // Combined light intensity
    float totalLight = blockLight + skyLight;
    
    // High complexity: both block and sky light active
    if (blockLight > 0.6 && skyLight > 0.6) {
        return COMPLEXITY_HIGH;
    }
    
    // High complexity: very high block light (many torches/lights)
    if (blockLight > 0.8) {
        return COMPLEXITY_HIGH;
    }
    
    // Medium complexity: moderate lighting
    if (totalLight > 0.8) {
        return COMPLEXITY_MEDIUM;
    }
    
    // Low complexity: minimal lighting
    return COMPLEXITY_LOW;
}

/*
 * Estimate scene complexity from material properties
 * 
 * High complexity indicators:
 * - Many specular/reflective surfaces (high smoothness)
 * - Many emissive materials (emission > 0)
 * - Complex material properties (porosity, SSS)
 * 
 * Parameters:
 *   smoothness: Material smoothness [0.0, 1.0]
 *   emission: Material emission intensity [0.0, 1.0]
 *   porosity: Material porosity [0.0, 1.0]
 * 
 * Returns: Complexity level (0 = low, 1 = medium, 2 = high)
 */
int estimateMaterialComplexity(float smoothness, float emission, float porosity) {
    // High complexity: many reflective surfaces
    if (smoothness > 0.7) {
        return COMPLEXITY_HIGH;
    }
    
    // High complexity: emissive materials
    if (emission > 0.3) {
        return COMPLEXITY_HIGH;
    }
    
    // Medium complexity: complex material properties
    if (smoothness > 0.4 || porosity > 0.5) {
        return COMPLEXITY_MEDIUM;
    }
    
    // Low complexity: simple materials
    return COMPLEXITY_LOW;
}

/*
 * Estimate scene complexity from depth complexity
 * 
 * High complexity indicators:
 * - Many depth discontinuities (complex geometry)
 * - High depth variance (varied distances)
 * - Many overlapping objects
 * 
 * Parameters:
 *   currentDepth: Current pixel depth [0.0, 1.0]
 *   neighborDepth: Neighbor pixel depth [0.0, 1.0]
 * 
 * Returns: Complexity level (0 = low, 1 = medium, 2 = high)
 */
int estimateGeometryComplexity(float currentDepth, float neighborDepth) {
    // Calculate depth discontinuity
    float depthDiff = abs(currentDepth - neighborDepth);
    
    // High complexity: many depth discontinuities
    if (depthDiff > 0.1) {
        return COMPLEXITY_HIGH;
    }
    
    // Medium complexity: moderate depth variation
    if (depthDiff > 0.05) {
        return COMPLEXITY_MEDIUM;
    }
    
    // Low complexity: smooth depth
    return COMPLEXITY_LOW;
}

/*
 * Combine multiple complexity estimates into final complexity level
 * 
 * Parameters:
 *   lightingComplexity: Complexity from lighting analysis
 *   materialComplexity: Complexity from material analysis
 *   geometryComplexity: Complexity from geometry analysis
 * 
 * Returns: Final complexity level (0 = low, 1 = medium, 2 = high)
 */
int combineComplexityEstimates(int lightingComplexity, int materialComplexity, int geometryComplexity) {
    // If any component is high complexity, overall is high
    if (lightingComplexity == COMPLEXITY_HIGH || 
        materialComplexity == COMPLEXITY_HIGH || 
        geometryComplexity == COMPLEXITY_HIGH) {
        return COMPLEXITY_HIGH;
    }
    
    // If any component is medium complexity, overall is medium
    if (lightingComplexity == COMPLEXITY_MEDIUM || 
        materialComplexity == COMPLEXITY_MEDIUM || 
        geometryComplexity == COMPLEXITY_MEDIUM) {
        return COMPLEXITY_MEDIUM;
    }
    
    // All components are low complexity
    return COMPLEXITY_LOW;
}

/*
 * Detect scene complexity from multiple heuristics
 * 
 * This function analyzes the current scene to determine complexity level
 * and returns appropriate quality settings.
 * 
 * Parameters:
 *   blockLight: Normalized block light intensity [0.0, 1.0]
 *   skyLight: Normalized sky light intensity [0.0, 1.0]
 *   smoothness: Material smoothness [0.0, 1.0]
 *   emission: Material emission intensity [0.0, 1.0]
 *   porosity: Material porosity [0.0, 1.0]
 *   currentDepth: Current pixel depth [0.0, 1.0]
 *   neighborDepth: Neighbor pixel depth [0.0, 1.0]
 * 
 * Returns: Complexity level (0 = low, 1 = medium, 2 = high)
 */
int detectSceneComplexity(
    float blockLight, float skyLight,
    float smoothness, float emission, float porosity,
    float currentDepth, float neighborDepth
) {
    // Estimate complexity from different aspects
    int lightingComplexity = estimateLightingComplexity(blockLight, skyLight);
    int materialComplexity = estimateMaterialComplexity(smoothness, emission, porosity);
    int geometryComplexity = estimateGeometryComplexity(currentDepth, neighborDepth);
    
    // Combine estimates into final complexity level
    return combineComplexityEstimates(lightingComplexity, materialComplexity, geometryComplexity);
}

// ============================================================================
// ADAPTIVE SHADOW QUALITY
// ============================================================================

/*
 * Get adaptive shadow cascade count based on scene complexity
 * 
 * High complexity: 2 cascades (reduced detail, faster)
 * Medium complexity: 3 cascades (balanced)
 * Low complexity: 4 cascades (maximum detail)
 * 
 * Parameters:
 *   complexity: Scene complexity level (0 = low, 1 = medium, 2 = high)
 * 
 * Returns: Adaptive cascade count
 */
int getAdaptiveShadowCascadeCount(int complexity) {
    if (complexity == COMPLEXITY_HIGH) {
        return SHADOW_CASCADE_COUNT_HIGH;  // 2 cascades
    } else if (complexity == COMPLEXITY_MEDIUM) {
        return 3;  // Medium: 3 cascades
    } else {
        return SHADOW_CASCADE_COUNT_LOW;  // 4 cascades
    }
}

/*
 * Get adaptive shadow map resolution based on scene complexity
 * 
 * High complexity: 1024x1024 (reduced resolution, faster)
 * Medium complexity: 1536x1536 (balanced)
 * Low complexity: 2048x2048 (maximum detail)
 * 
 * Parameters:
 *   complexity: Scene complexity level (0 = low, 1 = medium, 2 = high)
 * 
 * Returns: Adaptive shadow map resolution
 */
int getAdaptiveShadowMapResolution(int complexity) {
    if (complexity == COMPLEXITY_HIGH) {
        return SHADOW_MAP_RESOLUTION_HIGH;  // 1024
    } else if (complexity == COMPLEXITY_MEDIUM) {
        return 1536;  // Medium: 1536
    } else {
        return SHADOW_MAP_RESOLUTION_LOW;  // 2048
    }
}

/*
 * Get adaptive PCF kernel size based on scene complexity
 * 
 * High complexity: 1x1 (no filtering, fastest)
 * Medium complexity: 2x2 (light filtering)
 * Low complexity: 3x3 (full filtering)
 * 
 * Parameters:
 *   complexity: Scene complexity level (0 = low, 1 = medium, 2 = high)
 * 
 * Returns: Adaptive PCF kernel size
 */
int getAdaptivePCFKernelSize(int complexity) {
    if (complexity == COMPLEXITY_HIGH) {
        return 1;  // 1x1 = no filtering
    } else if (complexity == COMPLEXITY_MEDIUM) {
        return 2;  // 2x2 filtering
    } else {
        return PCF_KERNEL_SIZE;  // 3x3 filtering
    }
}

/*
 * Apply adaptive shadow quality settings
 * 
 * This function adjusts shadow rendering parameters based on scene complexity
 * to maintain performance targets while preserving visual quality.
 * 
 * Parameters:
 *   complexity: Scene complexity level (0 = low, 1 = medium, 2 = high)
 *   outCascadeCount: Output cascade count
 *   outResolution: Output shadow map resolution
 *   outPCFKernel: Output PCF kernel size
 */
void applyAdaptiveShadowQuality(
    int complexity,
    out int outCascadeCount,
    out int outResolution,
    out int outPCFKernel
) {
    outCascadeCount = getAdaptiveShadowCascadeCount(complexity);
    outResolution = getAdaptiveShadowMapResolution(complexity);
    outPCFKernel = getAdaptivePCFKernelSize(complexity);
}

// ============================================================================
// ADAPTIVE BLOOM QUALITY
// ============================================================================

/*
 * Get adaptive bloom blur radius based on scene complexity
 * 
 * High complexity: 1 (minimal blur, fastest)
 * Medium complexity: 2 (moderate blur)
 * Low complexity: 3 (maximum blur)
 * 
 * Parameters:
 *   complexity: Scene complexity level (0 = low, 1 = medium, 2 = high)
 * 
 * Returns: Adaptive bloom blur radius
 */
int getAdaptiveBloomRadius(int complexity) {
    if (complexity == COMPLEXITY_HIGH) {
        return BLOOM_RADIUS_HIGH;  // 1
    } else if (complexity == COMPLEXITY_MEDIUM) {
        return 2;  // Medium: 2
    } else {
        return BLOOM_RADIUS_LOW;  // 3
    }
}

/*
 * Get adaptive bloom sample count based on scene complexity
 * 
 * High complexity: 5 samples (minimal sampling, fastest)
 * Medium complexity: 7 samples (moderate sampling)
 * Low complexity: 9 samples (maximum sampling)
 * 
 * Parameters:
 *   complexity: Scene complexity level (0 = low, 1 = medium, 2 = high)
 * 
 * Returns: Adaptive bloom sample count
 */
int getAdaptiveBloomSampleCount(int complexity) {
    if (complexity == COMPLEXITY_HIGH) {
        return 5;  // Minimal sampling
    } else if (complexity == COMPLEXITY_MEDIUM) {
        return 7;  // Moderate sampling
    } else {
        return BLOOM_SAMPLE_COUNT;  // 9 samples
    }
}

/*
 * Apply adaptive bloom quality settings
 * 
 * This function adjusts bloom rendering parameters based on scene complexity
 * to maintain performance targets while preserving visual quality.
 * 
 * Parameters:
 *   complexity: Scene complexity level (0 = low, 1 = medium, 2 = high)
 *   outRadius: Output bloom blur radius
 *   outSampleCount: Output bloom sample count
 */
void applyAdaptiveBloomQuality(
    int complexity,
    out int outRadius,
    out int outSampleCount
) {
    outRadius = getAdaptiveBloomRadius(complexity);
    outSampleCount = getAdaptiveBloomSampleCount(complexity);
}

// ============================================================================
// ADAPTIVE TAA QUALITY
// ============================================================================

/*
 * Get adaptive TAA sample count based on scene complexity
 * 
 * High complexity: 8 samples (minimal accumulation, fastest)
 * Medium complexity: 12 samples (moderate accumulation)
 * Low complexity: 16 samples (maximum accumulation)
 * 
 * Parameters:
 *   complexity: Scene complexity level (0 = low, 1 = medium, 2 = high)
 * 
 * Returns: Adaptive TAA sample count
 */
int getAdaptiveTAASampleCount(int complexity) {
    if (complexity == COMPLEXITY_HIGH) {
        return TAA_SAMPLE_COUNT_HIGH;  // 8
    } else if (complexity == COMPLEXITY_MEDIUM) {
        return 12;  // Medium: 12
    } else {
        return TAA_SAMPLE_COUNT_LOW;  // 16
    }
}

/*
 * Get adaptive TAA blend weight based on scene complexity
 * 
 * Blend weight = 1.0 / sample_count
 * 
 * High complexity: 1/8 = 0.125 (faster convergence)
 * Medium complexity: 1/12 ≈ 0.083 (balanced)
 * Low complexity: 1/16 = 0.0625 (slower, smoother convergence)
 * 
 * Parameters:
 *   complexity: Scene complexity level (0 = low, 1 = medium, 2 = high)
 * 
 * Returns: Adaptive TAA blend weight
 */
float getAdaptiveTAABlendWeight(int complexity) {
    int sampleCount = getAdaptiveTAASampleCount(complexity);
    return 1.0 / float(sampleCount);
}

/*
 * Apply adaptive TAA quality settings
 * 
 * This function adjusts TAA rendering parameters based on scene complexity
 * to maintain performance targets while preserving visual quality.
 * 
 * Parameters:
 *   complexity: Scene complexity level (0 = low, 1 = medium, 2 = high)
 *   outSampleCount: Output TAA sample count
 *   outBlendWeight: Output TAA blend weight
 */
void applyAdaptiveTAAQuality(
    int complexity,
    out int outSampleCount,
    out float outBlendWeight
) {
    outSampleCount = getAdaptiveTAASampleCount(complexity);
    outBlendWeight = getAdaptiveTAABlendWeight(complexity);
}

// ============================================================================
// QUALITY TRANSITION SMOOTHING
// ============================================================================

/*
 * Smooth transition between quality levels to avoid visual pops
 * 
 * Uses exponential smoothing to gradually transition between quality settings
 * when scene complexity changes.
 * 
 * Parameters:
 *   currentQuality: Current quality setting
 *   targetQuality: Target quality setting
 *   deltaTime: Time since last frame (seconds)
 *   transitionSpeed: Transition speed (0.0-1.0, higher = faster)
 * 
 * Returns: Smoothly interpolated quality value
 */
float smoothQualityTransition(
    float currentQuality,
    float targetQuality,
    float deltaTime,
    float transitionSpeed
) {
    // Exponential smoothing: lerp towards target
    float blendFactor = 1.0 - exp(-transitionSpeed * deltaTime);
    return mix(currentQuality, targetQuality, blendFactor);
}

/*
 * Smooth transition between integer quality levels
 * 
 * Uses exponential smoothing to gradually transition between quality settings
 * when scene complexity changes.
 * 
 * Parameters:
 *   currentQuality: Current quality setting (integer)
 *   targetQuality: Target quality setting (integer)
 *   deltaTime: Time since last frame (seconds)
 *   transitionSpeed: Transition speed (0.0-1.0, higher = faster)
 * 
 * Returns: Smoothly interpolated quality value (can be fractional)
 */
float smoothIntegerQualityTransition(
    int currentQuality,
    int targetQuality,
    float deltaTime,
    float transitionSpeed
) {
    return smoothQualityTransition(
        float(currentQuality),
        float(targetQuality),
        deltaTime,
        transitionSpeed
    );
}

// ============================================================================
// QUALITY PRESET MANAGEMENT
// ============================================================================

/*
 * Quality preset structure containing all adaptive quality settings
 */
struct QualityPreset {
    int shadowCascadeCount;
    int shadowMapResolution;
    int pcfKernelSize;
    int bloomRadius;
    int bloomSampleCount;
    int taaSampleCount;
    float taaBlendWeight;
};

/*
 * Get quality preset for given complexity level
 * 
 * Parameters:
 *   complexity: Scene complexity level (0 = low, 1 = medium, 2 = high)
 * 
 * Returns: Quality preset with all adaptive settings
 */
QualityPreset getQualityPreset(int complexity) {
    QualityPreset preset;
    
    // Apply adaptive quality settings
    applyAdaptiveShadowQuality(
        complexity,
        preset.shadowCascadeCount,
        preset.shadowMapResolution,
        preset.pcfKernelSize
    );
    
    applyAdaptiveBloomQuality(
        complexity,
        preset.bloomRadius,
        preset.bloomSampleCount
    );
    
    applyAdaptiveTAAQuality(
        complexity,
        preset.taaSampleCount,
        preset.taaBlendWeight
    );
    
    return preset;
}

// ============================================================================
// PERFORMANCE MONITORING
// ============================================================================

/*
 * Estimate fragment shader execution time based on complexity indicators
 * 
 * This is a heuristic estimation since we cannot directly measure GPU time
 * in fragment shaders. We estimate based on:
 * - Number of texture lookups
 * - Number of arithmetic operations
 * - Branching complexity
 * 
 * Parameters:
 *   complexity: Scene complexity level (0 = low, 1 = medium, 2 = high)
 * 
 * Returns: Estimated execution time in microseconds
 */
float estimateFragmentShaderTime(int complexity) {
    if (complexity == COMPLEXITY_HIGH) {
        return COMPLEXITY_THRESHOLD_HIGH;
    } else if (complexity == COMPLEXITY_MEDIUM) {
        return COMPLEXITY_THRESHOLD_MEDIUM;
    } else {
        return COMPLEXITY_THRESHOLD_LOW;
    }
}

/*
 * Check if current frame time exceeds performance budget
 * 
 * Parameters:
 *   estimatedTime: Estimated fragment shader execution time
 *   targetFrameTime: Target frame time (milliseconds)
 * 
 * Returns: true if performance budget exceeded, false otherwise
 */
bool isPerformanceBudgetExceeded(float estimatedTime, float targetFrameTime) {
    // Convert microseconds to milliseconds
    float timeMs = estimatedTime / 1000.0;
    
    // Check if exceeds budget (with 20% headroom)
    return timeMs > (targetFrameTime * 0.8);
}

#endif // ADAPTIVE_QUALITY_GLSL
