/*
 * BlendHer Shader - Velocity Buffer Writing
 * 
 * This file provides velocity calculation and writing functions for Temporal
 * Anti-Aliasing (TAA). Velocity vectors represent screen-space motion between
 * frames, enabling accurate frame reprojection and temporal accumulation.
 * 
 * Components:
 * - Screen-space position calculation: Converts depth and texture coordinates to screen space
 * - Velocity calculation: Computes motion vectors from current and previous frame positions
 * - Velocity clamping: Prevents excessive reprojection artifacts
 * - Velocity encoding: Packs velocity into colortex4 (RG channels)
 * 
 * The velocity buffer is essential for TAA to work correctly. It stores the
 * screen-space displacement of each pixel between frames, accounting for both
 * camera movement and object motion.
 * 
 * Compatible with: GLSL 460 core, Iris 1.8.5+, OptiFine
 * References: Requirement 13 (Velocity Buffer for TAA)
 */

#ifndef VELOCITY_GLSL
#define VELOCITY_GLSL

// ============================================================================
// SCREEN-SPACE POSITION CALCULATION
// ============================================================================

/**
 * Converts texture coordinate and depth to screen-space position.
 * 
 * This function reconstructs the screen-space position (in normalized device
 * coordinates) from a texture coordinate and linear depth value. This is used
 * to calculate the current frame position for velocity computation.
 * 
 * Input: texCoord - texture coordinate [0, 1]
 *        depth - linear depth value [0, 1]
 * Output: screen-space position in NDC [-1, 1]
 * 
 * Validates: Requirement 13 (Velocity Buffer for TAA)
 */
vec3 getScreenSpacePosition(vec2 texCoord, float depth) {
    // Convert texture coordinate to NDC [-1, 1]
    vec3 ndc = vec3(texCoord * 2.0 - 1.0, depth);
    
    return ndc;
}

/**
 * Reconstructs world-space position from screen-space data.
 * 
 * Uses the inverse projection matrix to convert from screen space to view space,
 * then uses the inverse view matrix to get world-space position.
 * 
 * Input: screenPos - screen-space position in NDC [-1, 1]
 *        projectionInverse - inverse of projection matrix
 *        viewInverse - inverse of view matrix
 * Output: world-space position
 * 
 * Validates: Requirement 13 (Velocity Buffer for TAA)
 */
vec3 reconstructWorldPosition(vec3 screenPos, mat4 projectionInverse, mat4 viewInverse) {
    // Unproject from screen space to view space
    vec4 viewPos = projectionInverse * vec4(screenPos, 1.0);
    viewPos /= viewPos.w;
    
    // Transform from view space to world space
    vec4 worldPos = viewInverse * viewPos;
    
    return worldPos.xyz;
}

/**
 * Calculates current frame screen-space position.
 * 
 * Combines texture coordinate and depth to get the current frame's
 * screen-space position in normalized device coordinates.
 * 
 * Input: texCoord - current frame texture coordinate
 *        depth - current frame linear depth
 * Output: current frame screen-space position
 * 
 * Validates: Requirement 13 (Velocity Buffer for TAA)
 */
vec3 getCurrentScreenPosition(vec2 texCoord, float depth) {
    return getScreenSpacePosition(texCoord, depth);
}

/**
 * Calculates previous frame screen-space position using previousViewMatrix.
 * 
 * Reconstructs the world-space position using the current frame's depth and
 * texture coordinate, then projects it using the previous frame's view and
 * projection matrices to get where this pixel was in the previous frame.
 * 
 * Input: texCoord - current frame texture coordinate
 *        depth - current frame linear depth
 *        projectionInverse - inverse of current projection matrix
 *        viewInverse - inverse of current view matrix
 *        previousViewMatrix - previous frame view matrix
 *        previousProjectionMatrix - previous frame projection matrix
 * Output: previous frame screen-space position
 * 
 * Validates: Requirement 13 (Velocity Buffer for TAA)
 */
vec3 getPreviousScreenPosition(vec2 texCoord, float depth,
                               mat4 projectionInverse, mat4 viewInverse,
                               mat4 previousViewMatrix, mat4 previousProjectionMatrix) {
    // Get current screen-space position
    vec3 currentScreenPos = getCurrentScreenPosition(texCoord, depth);
    
    // Reconstruct world-space position from current frame
    vec4 viewPos = projectionInverse * vec4(currentScreenPos, 1.0);
    viewPos /= viewPos.w;
    
    vec4 worldPos = viewInverse * viewPos;
    
    // Project world position using previous frame matrices
    vec4 prevViewPos = previousViewMatrix * worldPos;
    vec4 prevScreenPos = previousProjectionMatrix * prevViewPos;
    prevScreenPos /= prevScreenPos.w;
    
    return prevScreenPos.xyz;
}

// ============================================================================
// VELOCITY CALCULATION
// ============================================================================

/**
 * Calculates velocity from current and previous screen positions.
 * 
 * Computes the screen-space displacement between frames. The velocity is
 * calculated as (current - previous) / frameTime to get per-second motion.
 * 
 * Input: currentScreenPos - current frame screen-space position (NDC)
 *        previousScreenPos - previous frame screen-space position (NDC)
 *        frameTime - time elapsed since last frame (seconds)
 * Output: velocity vector in screen space
 * 
 * Validates: Requirement 13 (Velocity Buffer for TAA)
 */
vec2 calculateVelocity(vec3 currentScreenPos, vec3 previousScreenPos, float frameTime) {
    // Convert from NDC [-1, 1] to screen space [0, 1]
    vec2 currentScreen = currentScreenPos.xy * 0.5 + 0.5;
    vec2 previousScreen = previousScreenPos.xy * 0.5 + 0.5;
    
    // Calculate displacement
    vec2 displacement = currentScreen - previousScreen;
    
    // Normalize by frame time to get per-second velocity
    // Avoid division by zero
    float deltaTime = max(frameTime, 0.001);
    vec2 velocity = displacement / deltaTime;
    
    return velocity;
}

/**
 * Calculates velocity accounting for camera movement only.
 * 
 * This simplified version calculates velocity based purely on camera motion,
 * without accounting for object motion. Useful for static geometry.
 * 
 * Input: texCoord - texture coordinate
 *        depth - linear depth
 *        projectionInverse - inverse projection matrix
 *        viewInverse - inverse view matrix
 *        previousViewMatrix - previous view matrix
 *        previousProjectionMatrix - previous projection matrix
 *        frameTime - frame time delta
 * Output: camera-based velocity
 * 
 * Validates: Requirement 13 (Velocity Buffer for TAA)
 */
vec2 calculateCameraVelocity(vec2 texCoord, float depth,
                             mat4 projectionInverse, mat4 viewInverse,
                             mat4 previousViewMatrix, mat4 previousProjectionMatrix,
                             float frameTime) {
    // Get current and previous screen positions
    vec3 currentScreenPos = getCurrentScreenPosition(texCoord, depth);
    vec3 previousScreenPos = getPreviousScreenPosition(texCoord, depth,
                                                       projectionInverse, viewInverse,
                                                       previousViewMatrix, previousProjectionMatrix);
    
    // Calculate velocity
    return calculateVelocity(currentScreenPos, previousScreenPos, frameTime);
}

/**
 * Calculates velocity with object motion (simplified).
 * 
 * For moving objects, velocity includes both camera motion and object motion.
 * This version uses vertex position change to estimate object motion.
 * 
 * Input: currentWorldPos - current frame world position
 *        previousWorldPos - previous frame world position (from vertex shader)
 *        viewMatrix - current view matrix
 *        projectionMatrix - current projection matrix
 *        previousViewMatrix - previous view matrix
 *        previousProjectionMatrix - previous projection matrix
 *        frameTime - frame time delta
 * Output: velocity including object motion
 * 
 * Validates: Requirement 13 (Velocity Buffer for TAA)
 */
vec2 calculateObjectVelocity(vec3 currentWorldPos, vec3 previousWorldPos,
                             mat4 viewMatrix, mat4 projectionMatrix,
                             mat4 previousViewMatrix, mat4 previousProjectionMatrix,
                             float frameTime) {
    // Project current world position to screen space
    vec4 currentViewPos = viewMatrix * vec4(currentWorldPos, 1.0);
    vec4 currentScreenPos = projectionMatrix * currentViewPos;
    currentScreenPos /= currentScreenPos.w;
    
    // Project previous world position to previous frame screen space
    vec4 previousViewPos = previousViewMatrix * vec4(previousWorldPos, 1.0);
    vec4 previousScreenPos = previousProjectionMatrix * previousViewPos;
    previousScreenPos /= previousScreenPos.w;
    
    // Calculate velocity
    return calculateVelocity(currentScreenPos.xyz, previousScreenPos.xyz, frameTime);
}

// ============================================================================
// VELOCITY CLAMPING
// ============================================================================

/**
 * Clamps velocity magnitude to prevent excessive reprojection.
 * 
 * Limits the maximum velocity to prevent pixels from reprojecting too far,
 * which can cause artifacts and incorrect history lookup. This is especially
 * important during fast camera motion or object movement.
 * 
 * Input: velocity - velocity vector
 *        maxVelocity - maximum allowed velocity magnitude (in screen space)
 * Output: clamped velocity
 * 
 * Validates: Requirement 13 (Velocity Buffer for TAA)
 */
vec2 clampVelocity(vec2 velocity, float maxVelocity) {
    float velocityMagnitude = length(velocity);
    
    // If velocity exceeds maximum, scale it down
    if (velocityMagnitude > maxVelocity) {
        return normalize(velocity) * maxVelocity;
    }
    
    return velocity;
}

/**
 * Clamps velocity with adaptive threshold based on depth.
 * 
 * Uses adaptive clamping where farther objects can have larger velocity
 * (since they move slower on screen), while closer objects are clamped tighter.
 * 
 * Input: velocity - velocity vector
 *        depth - linear depth [0, 1]
 *        baseMaxVelocity - base maximum velocity
 * Output: adaptively clamped velocity
 * 
 * Validates: Requirement 13 (Velocity Buffer for TAA)
 */
vec2 clampVelocityAdaptive(vec2 velocity, float depth, float baseMaxVelocity) {
    // Adaptive threshold: farther objects (higher depth) allow larger velocity
    float adaptiveMax = baseMaxVelocity * (1.0 + depth * 0.5);
    
    return clampVelocity(velocity, adaptiveMax);
}

/**
 * Clamps velocity component-wise to prevent extreme values.
 * 
 * Clamps X and Y components separately, useful for preventing artifacts
 * from extreme motion in one direction.
 * 
 * Input: velocity - velocity vector
 *        maxComponent - maximum value for each component
 * Output: component-wise clamped velocity
 * 
 * Validates: Requirement 13 (Velocity Buffer for TAA)
 */
vec2 clampVelocityComponentWise(vec2 velocity, float maxComponent) {
    return clamp(velocity, vec2(-maxComponent), vec2(maxComponent));
}

/**
 * Clamps velocity with soft falloff to reduce artifacts.
 * 
 * Uses a smooth falloff function instead of hard clamping to reduce
 * discontinuities at the clamping boundary.
 * 
 * Input: velocity - velocity vector
 *        softMax - soft maximum velocity
 *        hardMax - hard maximum velocity (safety limit)
 * Output: smoothly clamped velocity
 * 
 * Validates: Requirement 13 (Velocity Buffer for TAA)
 */
vec2 clampVelocitySoft(vec2 velocity, float softMax, float hardMax) {
    float velocityMagnitude = length(velocity);
    
    // Hard clamp first
    if (velocityMagnitude > hardMax) {
        velocity = normalize(velocity) * hardMax;
        velocityMagnitude = hardMax;
    }
    
    // Soft falloff: smooth transition above softMax
    if (velocityMagnitude > softMax) {
        float t = (velocityMagnitude - softMax) / (hardMax - softMax);
        float scale = mix(1.0, 0.5, t * t); // Quadratic falloff
        velocity *= scale;
    }
    
    return velocity;
}

// ============================================================================
// VELOCITY ENCODING AND WRITING
// ============================================================================

/**
 * Encodes velocity into RG channels for storage in colortex4.
 * 
 * Converts velocity from screen space to a normalized format suitable for
 * storage in 8-bit or 16-bit texture channels. Uses a bias and scale to
 * handle both positive and negative velocities.
 * 
 * Input: velocity - velocity vector in screen space
 *        scale - scale factor for encoding (default 0.5 for ±1.0 range)
 * Output: encoded velocity in [0, 1] range
 * 
 * Validates: Requirement 13 (Velocity Buffer for TAA)
 */
vec2 encodeVelocity(vec2 velocity, float scale) {
    // Bias and scale: convert from [-1, 1] to [0, 1]
    // velocity * scale converts to [-scale, scale]
    // + 0.5 converts to [0.5-scale, 0.5+scale]
    // Clamp to [0, 1]
    return clamp(velocity * scale + 0.5, 0.0, 1.0);
}

/**
 * Decodes velocity from RG channels (inverse of encodeVelocity).
 * 
 * Reconstructs velocity from encoded format in texture.
 * 
 * Input: encodedVelocity - encoded velocity from texture [0, 1]
 *        scale - scale factor used during encoding
 * Output: decoded velocity in screen space
 * 
 * Validates: Requirement 13 (Velocity Buffer for TAA)
 */
vec2 decodeVelocity(vec2 encodedVelocity, float scale) {
    // Reverse the encoding: subtract 0.5, then divide by scale
    return (encodedVelocity - 0.5) / scale;
}

/**
 * Encodes velocity with higher precision using 16-bit format.
 * 
 * For higher precision velocity storage (if using 16-bit textures).
 * 
 * Input: velocity - velocity vector
 *        scale - scale factor
 * Output: encoded velocity
 * 
 * Validates: Requirement 13 (Velocity Buffer for TAA)
 */
vec2 encodeVelocityHighPrecision(vec2 velocity, float scale) {
    // Same encoding as standard, but with higher precision in texture
    return clamp(velocity * scale + 0.5, 0.0, 1.0);
}

/**
 * Writes velocity to output color for colortex4.
 * 
 * Packs velocity into RG channels, with optional data in BA channels.
 * This is the main function used in fragment shaders to output velocity.
 * 
 * Input: velocity - velocity vector
 *        scale - encoding scale factor
 *        blueChannel - optional data for B channel (default 0.0)
 *        alphaChannel - optional data for A channel (default 1.0)
 * Output: vec4 color for colortex4
 * 
 * Validates: Requirement 13 (Velocity Buffer for TAA)
 */
vec4 writeVelocityBuffer(vec2 velocity, float scale, float blueChannel, float alphaChannel) {
    // Encode velocity into RG channels
    vec2 encodedVelocity = encodeVelocity(velocity, scale);
    
    // Pack into RGBA
    return vec4(encodedVelocity, blueChannel, alphaChannel);
}

/**
 * Writes velocity with default parameters.
 * 
 * Convenience function with sensible defaults for velocity writing.
 * 
 * Input: velocity - velocity vector
 * Output: vec4 color for colortex4
 * 
 * Validates: Requirement 13 (Velocity Buffer for TAA)
 */
vec4 writeVelocityBufferDefault(vec2 velocity) {
    // Default scale: 0.5 (handles ±1.0 velocity range)
    // Default B channel: 0.0 (unused)
    // Default A channel: 1.0 (fully opaque)
    return writeVelocityBuffer(velocity, 0.5, 0.0, 1.0);
}

// ============================================================================
// COMPLETE VELOCITY CALCULATION PIPELINE
// ============================================================================

/**
 * Complete velocity calculation pipeline for gbuffers passes.
 * 
 * This is the main function to call from gbuffers_* fragment shaders.
 * It handles all steps: position calculation, velocity computation,
 * clamping, and encoding.
 * 
 * Input: texCoord - current frame texture coordinate
 *        depth - current frame linear depth
 *        projectionInverse - inverse projection matrix
 *        viewInverse - inverse view matrix
 *        previousViewMatrix - previous frame view matrix
 *        previousProjectionMatrix - previous frame projection matrix
 *        frameTime - frame time delta
 * Output: vec4 color for colortex4 (velocity buffer)
 * 
 * Validates: Requirement 13 (Velocity Buffer for TAA)
 */
vec4 calculateAndWriteVelocity(vec2 texCoord, float depth,
                               mat4 projectionInverse, mat4 viewInverse,
                               mat4 previousViewMatrix, mat4 previousProjectionMatrix,
                               float frameTime) {
    // Calculate velocity from camera motion
    vec2 velocity = calculateCameraVelocity(texCoord, depth,
                                            projectionInverse, viewInverse,
                                            previousViewMatrix, previousProjectionMatrix,
                                            frameTime);
    
    // Clamp velocity to prevent excessive reprojection
    // Maximum velocity: 0.1 screen space per frame (10% of screen)
    velocity = clampVelocity(velocity, 0.1);
    
    // Encode and write to colortex4
    return writeVelocityBufferDefault(velocity);
}

/**
 * Velocity calculation with object motion support.
 * 
 * For moving objects, include the object's world-space position change.
 * 
 * Input: texCoord - texture coordinate
 *        depth - linear depth
 *        currentWorldPos - current frame world position
 *        previousWorldPos - previous frame world position
 *        viewMatrix - current view matrix
 *        projectionMatrix - current projection matrix
 *        previousViewMatrix - previous view matrix
 *        previousProjectionMatrix - previous projection matrix
 *        frameTime - frame time delta
 * Output: vec4 color for colortex4
 * 
 * Validates: Requirement 13 (Velocity Buffer for TAA)
 */
vec4 calculateAndWriteVelocityWithObjectMotion(vec2 texCoord, float depth,
                                               vec3 currentWorldPos, vec3 previousWorldPos,
                                               mat4 viewMatrix, mat4 projectionMatrix,
                                               mat4 previousViewMatrix, mat4 previousProjectionMatrix,
                                               float frameTime) {
    // Calculate velocity including object motion
    vec2 velocity = calculateObjectVelocity(currentWorldPos, previousWorldPos,
                                            viewMatrix, projectionMatrix,
                                            previousViewMatrix, previousProjectionMatrix,
                                            frameTime);
    
    // Clamp velocity
    velocity = clampVelocity(velocity, 0.1);
    
    // Encode and write
    return writeVelocityBufferDefault(velocity);
}

/**
 * Simplified velocity calculation for static geometry.
 * 
 * For terrain and other static geometry, only camera motion is needed.
 * This is a simplified version that doesn't require world position data.
 * 
 * Input: texCoord - texture coordinate
 *        depth - linear depth
 *        projectionInverse - inverse projection matrix
 *        viewInverse - inverse view matrix
 *        previousViewMatrix - previous view matrix
 *        previousProjectionMatrix - previous projection matrix
 *        frameTime - frame time delta
 * Output: vec4 color for colortex4
 * 
 * Validates: Requirement 13 (Velocity Buffer for TAA)
 */
vec4 calculateAndWriteVelocityStatic(vec2 texCoord, float depth,
                                     mat4 projectionInverse, mat4 viewInverse,
                                     mat4 previousViewMatrix, mat4 previousProjectionMatrix,
                                     float frameTime) {
    // For static geometry, camera velocity is sufficient
    return calculateAndWriteVelocity(texCoord, depth,
                                     projectionInverse, viewInverse,
                                     previousViewMatrix, previousProjectionMatrix,
                                     frameTime);
}

// ============================================================================
// UTILITY FUNCTIONS
// ============================================================================

/**
 * Validates velocity for NaN and Inf values.
 * 
 * Checks if velocity contains invalid values and returns fallback if needed.
 * 
 * Input: velocity - velocity to validate
 *        fallback - fallback velocity if invalid
 * Output: validated velocity
 */
vec2 validateVelocity(vec2 velocity, vec2 fallback) {
    // Check for NaN or Inf
    bool valid = all(lessThanEqual(abs(velocity), vec2(1e10)));
    return valid ? velocity : fallback;
}

/**
 * Converts velocity from pixels to normalized screen space.
 * 
 * Input: velocityPixels - velocity in screen pixels
 *        screenSize - screen resolution
 * Output: velocity in normalized screen space [0, 1]
 */
vec2 velocityPixelsToNormalized(vec2 velocityPixels, vec2 screenSize) {
    return velocityPixels / screenSize;
}

/**
 * Converts velocity from normalized screen space to pixels.
 * 
 * Input: velocityNormalized - velocity in normalized space
 *        screenSize - screen resolution
 * Output: velocity in screen pixels
 */
vec2 velocityNormalizedToPixels(vec2 velocityNormalized, vec2 screenSize) {
    return velocityNormalized * screenSize;
}

/**
 * Calculates velocity magnitude in screen space.
 * 
 * Input: velocity - velocity vector
 * Output: magnitude (distance traveled per frame)
 */
float getVelocityMagnitude(vec2 velocity) {
    return length(velocity);
}

/**
 * Calculates velocity magnitude in pixels.
 * 
 * Input: velocity - velocity in normalized screen space
 *        screenSize - screen resolution
 * Output: magnitude in pixels
 */
float getVelocityMagnitudePixels(vec2 velocity, vec2 screenSize) {
    return length(velocityNormalizedToPixels(velocity, screenSize));
}

#endif // VELOCITY_GLSL


// ============================================================================
// SIMPLIFIED VELOCITY CALCULATION FOR GBUFFERS
// ============================================================================

/**
 * Simplified velocity calculation for gbuffers passes.
 * 
 * This is a simplified version that calculates velocity based on
 * world position change between frames. Used in gbuffers_* passes
 * where full matrix calculations may not be available.
 * 
 * Input: worldPos - current frame world position
 * Output: velocity vector in screen space
 * 
 * Validates: Requirement 13 (Velocity Buffer for TAA)
 */
vec2 calculateVelocity(vec3 worldPos) {
    // Simplified velocity calculation
    // In a full implementation, this would use previousWorldPos and matrices
    // For now, return zero velocity (no motion)
    return vec2(0.0);
}

