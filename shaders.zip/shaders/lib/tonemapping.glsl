/*
 * BlendHer Shader - Advanced Tonemapping Library
 * 
 * This library provides the complete tonemapping pipeline used in the composite pass:
 * - ACES RRT (Reference Rendering Transform) - industry standard tone mapping
 * - ACES ODT (Output Device Transform) for sRGB display mapping
 * - Adaptive shadow crush based on blend factor
 * - HSV-based saturation adjustment for perceptually-accurate color grading
 * - Vibrance enhancement that affects less-saturated colors more
 * 
 * The tonemapping pipeline ensures that HDR colors are properly mapped to the
 * [0.0, 1.0] display range while maintaining visual quality and artistic control
 * through blend factor modulation.
 * 
 * Reference: Requirement 8 (Advanced Tonemapping)
 * Compatible with: GLSL 460 core, Iris 1.8.5+, OptiFine
 */

#ifndef TONEMAPPING_GLSL
#define TONEMAPPING_GLSL

// ============================================================================
// ACES RRT (Reference Rendering Transform)
// ============================================================================
// The ACES RRT is the first step in the ACES tonemapping pipeline.
// It applies a tone curve that compresses the dynamic range of HDR colors
// while preserving color relationships and visual quality.
//
// Reference: Academy Color Encoding System (ACES) 1.0
// Formula: rrt = color * (color + 0.0245786) - 0.000090537

/**
 * Apply ACES RRT (Reference Rendering Transform)
 * 
 * Converts HDR linear color to ACES color space using the Reference Rendering
 * Transform. This is the first step in the ACES tonemapping pipeline and
 * compresses the dynamic range while maintaining color accuracy.
 * 
 * Input: color - HDR linear color (can be > 1.0)
 * Output: ACES RRT transformed color
 * 
 * Validates: Requirement 8 (Advanced Tonemapping)
 */
vec3 acesRRT(vec3 color) {
    // ACES RRT formula: rrt = color * (color + 0.0245786) - 0.000090537
    // This applies a tone curve that compresses highlights while preserving shadows
    
    // Clamp to prevent negative values which would cause issues
    color = max(color, vec3(0.0));
    
    // Apply RRT tone curve
    vec3 rrt = color * (color + vec3(0.0245786)) - vec3(0.000090537);
    
    return rrt;
}

// ============================================================================
// ACES ODT (Output Device Transform)
// ============================================================================
// The ACES ODT is the second step in the ACES tonemapping pipeline.
// It converts from ACES color space to the target display color space (sRGB).
// This ensures proper color reproduction on standard displays.
//
// Reference: Academy Color Encoding System (ACES) 1.0
// Formula: odt = rrt / (rrt + 0.4329030)

/**
 * Apply ACES ODT (Output Device Transform) for sRGB
 * 
 * Converts ACES RRT color to sRGB display color space using the Output Device
 * Transform. This is the second step in the ACES tonemapping pipeline and
 * ensures proper color reproduction on standard sRGB displays.
 * 
 * Input: rrt - ACES RRT transformed color (from acesRRT)
 * Output: sRGB display color in [0.0, 1.0] range
 * 
 * Validates: Requirement 8 (Advanced Tonemapping)
 */
vec3 acesODT(vec3 rrt) {
    // ACES ODT formula: odt = rrt / (rrt + 0.4329030)
    // This maps ACES color space to sRGB display range
    
    // Clamp to prevent negative values
    rrt = max(rrt, vec3(0.0));
    
    // Apply ODT tone curve
    // The denominator ensures proper mapping to [0.0, 1.0] range
    vec3 odt = rrt / (rrt + vec3(0.4329030));
    
    // Clamp to display range to ensure no overbright values
    odt = clamp(odt, vec3(0.0), vec3(1.0));
    
    return odt;
}

/**
 * Complete ACES tonemapping pipeline (RRT + ODT)
 * 
 * Applies both ACES RRT and ODT in sequence for complete tonemapping.
 * This is a convenience function that combines both steps.
 * 
 * Input: color - HDR linear color (can be > 1.0)
 * Output: sRGB display color in [0.0, 1.0] range
 * 
 * Validates: Requirement 8 (Advanced Tonemapping)
 */
vec3 acesTonemapping(vec3 color) {
    // Apply RRT first
    vec3 rrt = acesRRT(color);
    
    // Apply ODT second
    vec3 odt = acesODT(rrt);
    
    return odt;
}

// ============================================================================
// ADAPTIVE SHADOW CRUSH
// ============================================================================
// Shadow crush darkens the shadows based on the blend factor.
// In BSL (blend factor 1.0), shadows are lighter and more visible.
// In Spooklementary (blend factor 0.0), shadows are darker and more dramatic.
//
// This is applied after ACES tonemapping to adjust the shadow intensity
// based on the visual state.

/**
 * Apply adaptive shadow crush based on blend factor
 * 
 * Darkens shadows using a power curve that adapts based on the blend factor.
 * Higher blend factor (BSL) = lighter shadows (crushPower ≈ 1.0)
 * Lower blend factor (Spooklementary) = darker shadows (crushPower ≈ 1.3)
 * 
 * Input: color - tonemapped color (from ACES pipeline)
 *        blendFactor - blend factor in [0.0, 1.0]
 *                      1.0 = BSL (vibrant), 0.0 = Spooklementary (dark)
 * Output: color with adaptive shadow crush applied
 * 
 * Validates: Requirement 8 (Advanced Tonemapping)
 */
vec3 adaptiveShadowCrush(vec3 color, float blendFactor) {
    // Clamp blend factor to valid range
    blendFactor = clamp(blendFactor, 0.0, 1.0);
    
    // Calculate crush power based on blend factor
    // At blend factor 1.0 (BSL): crushPower = 1.0 (no shadow crush)
    // At blend factor 0.0 (Spooklementary): crushPower = 1.3 (strong shadow crush)
    float crushPower = mix(1.3, 1.0, blendFactor);
    
    // Apply shadow crush using power function
    // This darkens shadows while preserving highlights
    vec3 crushed = pow(color, vec3(crushPower));
    
    // Clamp to ensure output stays in [0.0, 1.0]
    crushed = clamp(crushed, vec3(0.0), vec3(1.0));
    
    return crushed;
}

// ============================================================================
// HSV-BASED SATURATION ADJUSTMENT
// ============================================================================
// Saturation adjustment using HSV color space for perceptually-accurate results.
// In BSL (blend factor 1.0), saturation is high (1.0).
// In Spooklementary (blend factor 0.0), saturation is reduced (0.6).
//
// HSV-based adjustment is more perceptually accurate than simple RGB scaling
// because it operates in a color space that matches human perception.

/**
 * Adjust saturation using HSV color space
 * 
 * Converts RGB to HSV, adjusts saturation, and converts back to RGB.
 * This provides perceptually-accurate saturation adjustment.
 * 
 * Input: color - RGB color in [0.0, 1.0]
 *        saturation - saturation multiplier (0.0 = grayscale, 1.0 = no change, 2.0 = double saturation)
 * Output: RGB color with adjusted saturation
 * 
 * Validates: Requirement 8 (Advanced Tonemapping)
 */
vec3 adjustSaturation(vec3 color, float saturation) {
    // Convert RGB to HSV
    float maxC = max(color.r, max(color.g, color.b));
    float minC = min(color.r, min(color.g, color.b));
    float delta = maxC - minC;
    
    // Value (brightness)
    float v = maxC;
    
    // Saturation
    float s = (maxC > 0.0) ? (delta / maxC) : 0.0;
    
    // Hue
    float h = 0.0;
    if (delta > 0.0) {
        if (maxC == color.r) {
            h = mod((color.g - color.b) / delta, 6.0) / 6.0;
        } else if (maxC == color.g) {
            h = ((color.b - color.r) / delta + 2.0) / 6.0;
        } else {
            h = ((color.r - color.g) / delta + 4.0) / 6.0;
        }
    }
    
    // Adjust saturation
    s = clamp(s * saturation, 0.0, 1.0);
    
    // Convert back to RGB
    float c = v * s;
    float x = c * (1.0 - abs(mod(h * 6.0, 2.0) - 1.0));
    float m = v - c;
    
    vec3 rgb;
    float hh = h * 6.0;
    if (hh < 1.0) {
        rgb = vec3(c, x, 0.0);
    } else if (hh < 2.0) {
        rgb = vec3(x, c, 0.0);
    } else if (hh < 3.0) {
        rgb = vec3(0.0, c, x);
    } else if (hh < 4.0) {
        rgb = vec3(0.0, x, c);
    } else if (hh < 5.0) {
        rgb = vec3(x, 0.0, c);
    } else {
        rgb = vec3(c, 0.0, x);
    }
    
    return rgb + m;
}

/**
 * Apply adaptive saturation based on blend factor
 * 
 * Adjusts saturation based on the blend factor using HSV color space.
 * Higher blend factor (BSL) = higher saturation (1.0)
 * Lower blend factor (Spooklementary) = lower saturation (0.6)
 * 
 * Input: color - RGB color in [0.0, 1.0]
 *        blendFactor - blend factor in [0.0, 1.0]
 *                      1.0 = BSL (vibrant), 0.0 = Spooklementary (desaturated)
 * Output: RGB color with adaptive saturation applied
 * 
 * Validates: Requirement 8 (Advanced Tonemapping)
 */
vec3 adaptiveSaturation(vec3 color, float blendFactor) {
    // Clamp blend factor to valid range
    blendFactor = clamp(blendFactor, 0.0, 1.0);
    
    // Calculate saturation multiplier based on blend factor
    // At blend factor 1.0 (BSL): saturation = 1.0 (no change)
    // At blend factor 0.0 (Spooklementary): saturation = 0.6 (reduced)
    float saturation = mix(0.6, 1.0, blendFactor);
    
    // Apply saturation adjustment using HSV
    vec3 saturated = adjustSaturation(color, saturation);
    
    // Clamp to ensure output stays in [0.0, 1.0]
    saturated = clamp(saturated, vec3(0.0), vec3(1.0));
    
    return saturated;
}

// ============================================================================
// VIBRANCE ENHANCEMENT
// ============================================================================
// Vibrance is a selective saturation adjustment that affects less-saturated
// colors more than already-saturated colors. This creates a more natural
// color enhancement compared to uniform saturation adjustment.
//
// In BSL (blend factor 1.0), vibrance is high (1.3).
// In Spooklementary (blend factor 0.0), vibrance is low (1.0).

/**
 * Apply vibrance enhancement
 * 
 * Selectively enhances saturation of less-saturated colors while leaving
 * highly saturated colors relatively unchanged. This creates a more natural
 * color enhancement compared to uniform saturation adjustment.
 * 
 * Input: color - RGB color in [0.0, 1.0]
 *        vibrance - vibrance strength (1.0 = no change, 1.3 = 30% enhancement)
 * Output: RGB color with vibrance applied
 * 
 * Validates: Requirement 8 (Advanced Tonemapping)
 */
vec3 applyVibrance(vec3 color, float vibrance) {
    // Convert RGB to HSV to get saturation
    float maxC = max(color.r, max(color.g, color.b));
    float minC = min(color.r, min(color.g, color.b));
    float delta = maxC - minC;
    
    // Calculate saturation
    float s = (maxC > 0.0) ? (delta / maxC) : 0.0;
    
    // Vibrance affects less-saturated colors more
    // Use inverse saturation as the vibrance mask
    // Highly saturated colors (s ≈ 1.0) get less vibrance
    // Desaturated colors (s ≈ 0.0) get more vibrance
    float vibrance_mask = 1.0 - s;
    
    // Interpolate vibrance strength based on saturation
    // Less saturated colors get more vibrance boost
    float vibrance_strength = mix(1.0, vibrance, vibrance_mask);
    
    // Apply vibrance by adjusting saturation
    vec3 vibrant = adjustSaturation(color, vibrance_strength);
    
    // Clamp to ensure output stays in [0.0, 1.0]
    vibrant = clamp(vibrant, vec3(0.0), vec3(1.0));
    
    return vibrant;
}

/**
 * Apply adaptive vibrance based on blend factor
 * 
 * Adjusts vibrance based on the blend factor.
 * Higher blend factor (BSL) = higher vibrance (1.3)
 * Lower blend factor (Spooklementary) = lower vibrance (1.0)
 * 
 * Input: color - RGB color in [0.0, 1.0]
 *        blendFactor - blend factor in [0.0, 1.0]
 *                      1.0 = BSL (vibrant), 0.0 = Spooklementary (muted)
 * Output: RGB color with adaptive vibrance applied
 * 
 * Validates: Requirement 8 (Advanced Tonemapping)
 */
vec3 adaptiveVibrance(vec3 color, float blendFactor) {
    // Clamp blend factor to valid range
    blendFactor = clamp(blendFactor, 0.0, 1.0);
    
    // Calculate vibrance strength based on blend factor
    // At blend factor 1.0 (BSL): vibrance = 1.3 (enhanced)
    // At blend factor 0.0 (Spooklementary): vibrance = 1.0 (no change)
    float vibrance = mix(1.0, 1.3, blendFactor);
    
    // Apply vibrance enhancement
    vec3 vibrant = applyVibrance(color, vibrance);
    
    // Clamp to ensure output stays in [0.0, 1.0]
    vibrant = clamp(vibrant, vec3(0.0), vec3(1.0));
    
    return vibrant;
}

// ============================================================================
// COMPLETE TONEMAPPING PIPELINE
// ============================================================================
// Combines all tonemapping steps in the correct order:
// 1. ACES RRT (Reference Rendering Transform)
// 2. ACES ODT (Output Device Transform)
// 3. Adaptive Shadow Crush
// 4. Adaptive Saturation
// 5. Adaptive Vibrance
//
// This pipeline ensures that HDR colors are properly mapped to the [0.0, 1.0]
// display range while maintaining visual quality and artistic control through
// blend factor modulation.

/**
 * Apply complete tonemapping pipeline
 * 
 * Applies all tonemapping steps in sequence:
 * 1. ACES RRT (Reference Rendering Transform)
 * 2. ACES ODT (Output Device Transform) for sRGB
 * 3. Adaptive shadow crush based on blend factor
 * 4. Adaptive saturation adjustment (HSV-based)
 * 5. Adaptive vibrance enhancement
 * 
 * Input: color - HDR linear color (can be > 1.0)
 *        blendFactor - blend factor in [0.0, 1.0]
 *                      1.0 = BSL (vibrant), 0.0 = Spooklementary (dark)
 * Output: tonemapped sRGB display color in [0.0, 1.0] range
 * 
 * Validates: Requirement 8 (Advanced Tonemapping)
 */
vec3 completeTonemappingPipeline(vec3 color, float blendFactor) {
    // Clamp blend factor to valid range
    blendFactor = clamp(blendFactor, 0.0, 1.0);
    
    // Step 1: Apply ACES RRT (Reference Rendering Transform)
    vec3 rrt = acesRRT(color);
    
    // Step 2: Apply ACES ODT (Output Device Transform) for sRGB
    vec3 odt = acesODT(rrt);
    
    // Step 3: Apply adaptive shadow crush
    vec3 crushed = adaptiveShadowCrush(odt, blendFactor);
    
    // Step 4: Apply adaptive saturation (HSV-based)
    vec3 saturated = adaptiveSaturation(crushed, blendFactor);
    
    // Step 5: Apply adaptive vibrance enhancement
    vec3 vibrant = adaptiveVibrance(saturated, blendFactor);
    
    // Final clamp to ensure output is in [0.0, 1.0]
    vec3 final = clamp(vibrant, vec3(0.0), vec3(1.0));
    
    return final;
}

/**
 * Apply tonemapping without blend factor modulation
 * 
 * Applies ACES tonemapping pipeline without adaptive adjustments.
 * Useful for cases where blend factor is not available or not needed.
 * 
 * Input: color - HDR linear color (can be > 1.0)
 * Output: tonemapped sRGB display color in [0.0, 1.0] range
 * 
 * Validates: Requirement 8 (Advanced Tonemapping)
 */
vec3 simpleTonemapping(vec3 color) {
    // Apply ACES RRT
    vec3 rrt = acesRRT(color);
    
    // Apply ACES ODT
    vec3 odt = acesODT(rrt);
    
    // Final clamp to ensure output is in [0.0, 1.0]
    return clamp(odt, vec3(0.0), vec3(1.0));
}

// ============================================================================
// UTILITY FUNCTIONS
// ============================================================================

/**
 * Clamp color to valid display range
 * 
 * Ensures color values are within [0.0, 1.0] range for display.
 * 
 * Input: color - color to clamp
 * Output: clamped color in [0.0, 1.0]
 */
vec3 clampToDisplayRange(vec3 color) {
    return clamp(color, vec3(0.0), vec3(1.0));
}

/**
 * Check if color contains NaN or Inf values
 * 
 * Detects invalid floating-point values that could cause rendering issues.
 * 
 * Input: color - color to check
 * Output: true if color contains NaN or Inf, false otherwise
 */
bool isValidColor(vec3 color) {
    // Check for NaN: NaN != NaN
    if (color.r != color.r || color.g != color.g || color.b != color.b) {
        return false;
    }
    
    // Check for Inf: Inf > 1e10
    if (abs(color.r) > 1e10 || abs(color.g) > 1e10 || abs(color.b) > 1e10) {
        return false;
    }
    
    return true;
}

/**
 * Safely apply tonemapping with NaN/Inf protection
 * 
 * Applies complete tonemapping pipeline with fallback to black if invalid values detected.
 * 
 * Input: color - HDR linear color
 *        blendFactor - blend factor in [0.0, 1.0]
 * Output: tonemapped color, or black if invalid values detected
 */
vec3 safeTonemapping(vec3 color, float blendFactor) {
    // Check if input color is valid
    if (!isValidColor(color)) {
        return vec3(0.0); // Return black for invalid input
    }
    
    // Apply tonemapping pipeline
    vec3 result = completeTonemappingPipeline(color, blendFactor);
    
    // Check if result is valid
    if (!isValidColor(result)) {
        return vec3(0.0); // Return black for invalid output
    }
    
    return result;
}

#endif // TONEMAPPING_GLSL
