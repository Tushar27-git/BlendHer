/*
 * BlendHer Shader - Modern Uniforms
 * 
 * This file declares all uniform variables passed from the Minecraft shader system.
 * These uniforms are used across all shader passes for time, camera, weather, and
 * rendering parameters.
 * 
 * Compatible with: GLSL 460 core, Iris 1.8.5+, OptiFine
 * References: Requirement 3 (Deferred Rendering), Requirement 5 (Cascaded Shadows)
 */

#ifndef UNIFORMS_GLSL
#define UNIFORMS_GLSL

// ============================================================================
// TIME UNIFORMS
// ============================================================================

// World time in ticks (0-24000 per day cycle)
// Used for time-based calculations, blend factor interpolation, and animation
uniform int worldTime;

// Frame time in seconds (delta time since last frame)
// Used for smooth animation and temporal calculations
uniform float frameTime;

// Day time in ticks (0-24000, wraps around)
// Alias for worldTime, provided for compatibility
uniform int dayTime;

// ============================================================================
// CAMERA UNIFORMS
// ============================================================================

// Camera position in world space (XYZ)
// Used for distance calculations, fog, and lighting
uniform vec3 cameraPosition;

// Current frame view matrix (4x4)
// Transforms from world space to view space
uniform mat4 viewMatrix;

// Current frame projection matrix (4x4)
// Transforms from view space to clip space
uniform mat4 projectionMatrix;

// Previous frame view matrix (4x4)
// Used for TAA reprojection and velocity calculation
uniform mat4 previousViewMatrix;

// ============================================================================
// WEATHER UNIFORMS
// ============================================================================

// Rain strength (0.0 = no rain, 1.0 = heavy rain)
// Used for blend factor modulation and weather effects
uniform float rainStrength;

// Thunder strength (0.0 = no thunder, 1.0 = intense thunder)
// Used for visual effects and blend factor modulation during storms
uniform float thunderStrength;

// ============================================================================
// BLEND FACTOR UNIFORM
// ============================================================================

// Dynamic blend factor between BSL (1.0) and Spooklementary (0.0)
// Range: [0.0, 1.0]
// 1.0 = Noon Vibrancy (full BSL golden daylight)
// 0.5 = Sunset Purple Haze (transitional state)
// 0.0 = Playable Midnight (full Spooklementary horror)
// Used for interpolating colors, lighting, fog, and all visual effects
uniform float blendFactor;

// ============================================================================
// SHADOW MAPPING UNIFORMS
// ============================================================================

// Cascade split distances for shadow mapping (in blocks from camera)
// Cascade 0: 0 to cascadeSplits[0] blocks (high detail)
// Cascade 1: cascadeSplits[0] to cascadeSplits[1] blocks (medium detail)
// Cascade 2: cascadeSplits[1] to cascadeSplits[2] blocks (low detail)
// Cascade 3: cascadeSplits[2] to cascadeSplits[3] blocks (fade out)
// Default: [64.0, 128.0, 256.0, 512.0]
uniform vec4 cascadeSplits;

// Shadow map resolution (typically 2048.0 for 2K shadow maps)
// Used for PCF sampling and depth bias calculations
uniform float shadowMapResolution;

// Depth bias for shadow sampling (platform-dependent)
// NVIDIA: 0.03, AMD: 0.05
// Used to prevent shadow acne and peter-panning
uniform float shadowDepthBias;

// ============================================================================
// ADDITIONAL RENDERING UNIFORMS
// ============================================================================

// Screen dimensions (width, height)
// Used for screen-space calculations and texture coordinate normalization
uniform vec2 screenSize;

// Inverse screen dimensions (1.0/width, 1.0/height)
// Used for efficient screen-space calculations
uniform vec2 invScreenSize;

// Near and far plane distances for depth linearization
// Used for depth calculations and TAA
uniform vec2 nearFar;

// ============================================================================
// FRAME COUNTER UNIFORM
// ============================================================================

// Frame counter (increments each frame)
// Used for TAA jitter patterns and temporal effects
// Provides deterministic frame-to-frame variation
uniform int frameCounter;

#endif // UNIFORMS_GLSL
