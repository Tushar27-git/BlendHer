/*
 * BlendHer Shader - Cascaded Shadow System
 * 
 * This file implements the cascaded shadow mapping system with:
 * - Cascaded shadow map sampling (3-4 cascades)
 * - PCF (Percentage-Closer Filtering) 3x3 kernel for smooth shadows
 * - Adaptive depth bias (0.03 NVIDIA, 0.05 AMD)
 * - Cascade blending to avoid visible transitions
 * - Shadow fade at distance boundary
 * 
 * The shadow system uses multiple shadow maps at different distances to provide
 * crisp shadows near the player and smooth shadows far away, while maintaining
 * performance within the budget.
 * 
 * Compatible with: GLSL 460 core, Iris 1.8.5+, OptiFine
 * References: Requirement 5 (Cascaded Shadow Mapping)
 */

#ifndef SHADOW_GLSL
#define SHADOW_GLSL

#include "settings.glsl"
#include "uniforms.glsl"

// ============================================================================
// SHADOW MAP TEXTURE SAMPLERS
// ============================================================================

// Cascaded shadow map textures (2K resolution, 16-bit depth)
// shadowtex0: Cascade 0 and 1 (packed)
// shadowtex1: Cascade 2 and 3 (packed)
uniform sampler2D shadowtex0;
uniform sampler2D shadowtex1;

// Shadow map comparison sampler (for hardware PCF)
uniform sampler2DShadow shadowtex0_compare;
uniform sampler2DShadow shadowtex1_compare;

// ============================================================================
// SHADOW SPACE TRANSFORMATION MATRICES
// ============================================================================

// Shadow view-projection matrices for each cascade
// These transform from world space to shadow map space
uniform mat4 shadowModelView;
uniform mat4 shadowProjection;

// ============================================================================
// CASCADE SELECTION AND DISTANCE CALCULATION
// ============================================================================

/**
 * Selects the appropriate shadow cascade based on distance from camera.
 * 
 * The cascade selection is based on the distance from the camera to the fragment.
 * Closer fragments use higher-detail cascades, while distant fragments use
 * lower-detail cascades.
 * 
 * Cascade splits (from settings.glsl):
 * - Cascade 0: 0-64 blocks (high detail)
 * - Cascade 1: 64-128 blocks (medium detail)
 * - Cascade 2: 128-256 blocks (low detail)
 * - Cascade 3: 256+ blocks (fade out)
 * 
 * Input: distance - distance from camera to fragment (in blocks)
 * Output: cascade index (0, 1, 2, or 3)
 * 
 * Validates: Requirement 5 (Cascaded Shadow Mapping)
 */
int selectShadowCascade(float distance) {
    // Compare distance against cascade split distances
    if (distance < CASCADE_SPLITS.x) {
        return 0;  // Cascade 0: 0-64 blocks
    } else if (distance < CASCADE_SPLITS.y) {
        return 1;  // Cascade 1: 64-128 blocks
    } else if (distance < CASCADE_SPLITS.z) {
        return 2;  // Cascade 2: 128-256 blocks
    } else {
        return 3;  // Cascade 3: 256+ blocks (fade out)
    }
}

/**
 * Calculates the blend factor for cascade blending.
 * 
 * Creates a smooth transition between cascades to avoid visible boundaries.
 * The blend factor is 0.0 at the cascade boundary and 1.0 at the next boundary.
 * 
 * Input: distance - distance from camera to fragment
 *        cascadeIndex - current cascade index
 * Output: blend factor in [0.0, 1.0] for smooth cascade transition
 * 
 * Validates: Requirement 5 (Cascaded Shadow Mapping)
 */
float calculateCascadeBlendFactor(float distance, int cascadeIndex) {
    // Get the current cascade boundary and next cascade boundary
    float currentBoundary = (cascadeIndex == 0) ? 0.0 : CASCADE_SPLITS[cascadeIndex - 1];
    float nextBoundary = CASCADE_SPLITS[cascadeIndex];
    
    // Calculate blend factor within the cascade
    // Blend starts at (nextBoundary - CASCADE_BLEND_WIDTH) and completes at nextBoundary
    float blendStart = nextBoundary - CASCADE_BLEND_WIDTH;
    float blendFactor = smoothstep(blendStart, nextBoundary, distance);
    
    return blendFactor;
}

/**
 * Calculates shadow fade factor at distance boundary.
 * 
 * Shadows fade out beyond SHADOW_FADE_DISTANCE to avoid hard cutoffs
 * and improve performance at extreme distances.
 * 
 * Input: distance - distance from camera to fragment
 * Output: fade factor in [0.0, 1.0] (1.0 = full shadow, 0.0 = no shadow)
 * 
 * Validates: Requirement 5 (Cascaded Shadow Mapping)
 */
float calculateShadowFade(float distance) {
    // Fade shadows beyond SHADOW_FADE_DISTANCE
    // Use smoothstep for smooth fade transition
    float fadeStart = SHADOW_FADE_DISTANCE - CASCADE_BLEND_WIDTH;
    float fadeFactor = smoothstep(fadeStart, SHADOW_FADE_DISTANCE, distance);
    
    // Return 1.0 (full shadow) when distance < fadeStart
    // Return 0.0 (no shadow) when distance > SHADOW_FADE_DISTANCE
    return 1.0 - fadeFactor;
}

// ============================================================================
// DEPTH BIAS CALCULATION
// ============================================================================

/**
 * Calculates adaptive depth bias based on surface normal and light direction.
 * 
 * Depth bias prevents shadow acne (self-shadowing artifacts) and peter-panning
 * (shadows detaching from objects). The bias is adaptive based on the angle
 * between the surface normal and light direction.
 * 
 * Steeper angles (grazing light) require larger bias to prevent artifacts.
 * 
 * Input: normal - surface normal (world space)
 *        lightDirection - direction to light source (world space)
 * Output: adaptive depth bias value
 * 
 * Validates: Requirement 5 (Cascaded Shadow Mapping)
 */
float calculateAdaptiveDepthBias(vec3 normal, vec3 lightDirection) {
    // Calculate the angle between normal and light direction
    float cosAngle = max(dot(normal, lightDirection), 0.0);
    
    // Adaptive bias: larger bias for grazing angles
    // Use SHADOW_BIAS as base, scale by (1 - cosAngle) for angle-dependent adjustment
    float baseBias = SHADOW_BIAS;
    float adaptiveBias = baseBias * (1.0 - cosAngle);
    
    // Clamp bias to reasonable range to prevent over-correction
    return clamp(adaptiveBias, baseBias * 0.5, baseBias * 2.0);
}

// ============================================================================
// PCF (PERCENTAGE-CLOSER FILTERING) SAMPLING
// ============================================================================

/**
 * Performs PCF 3x3 kernel shadow sampling.
 * 
 * PCF (Percentage-Closer Filtering) samples the shadow map at multiple
 * nearby locations and averages the results. This creates soft shadow edges
 * and reduces aliasing artifacts.
 * 
 * The 3x3 kernel samples 9 locations around the shadow coordinate:
 * 
 *   [-1,-1]  [0,-1]  [+1,-1]
 *   [-1, 0]  [0, 0]  [+1, 0]
 *   [-1,+1]  [0,+1]  [+1,+1]
 * 
 * Input: shadowCoord - shadow map coordinate (in shadow space)
 *        shadowMap - shadow map texture sampler
 *        texelSize - size of one texel in shadow map space
 *        depth - fragment depth in shadow space
 *        bias - depth bias to prevent shadow acne
 * Output: shadow factor in [0.0, 1.0] (0.0 = fully shadowed, 1.0 = fully lit)
 * 
 * Validates: Requirement 5 (Cascaded Shadow Mapping)
 */
float sampleShadowPCF3x3(vec2 shadowCoord, sampler2D shadowMap, 
                         vec2 texelSize, float depth, float bias) {
    // Initialize shadow accumulator
    float shadow = 0.0;
    
    // 3x3 PCF kernel
    // Sample 9 locations around the shadow coordinate
    for (int x = -1; x <= 1; x++) {
        for (int y = -1; y <= 1; y++) {
            // Calculate offset in shadow map space
            vec2 offset = vec2(float(x), float(y)) * texelSize;
            
            // Sample shadow map at offset location
            vec2 sampleCoord = shadowCoord + offset;
            float shadowDepth = texture(shadowMap, sampleCoord).r;
            
            // Compare depths: if fragment depth > shadow depth, fragment is in shadow
            // Add bias to prevent shadow acne
            if (depth - bias <= shadowDepth) {
                shadow += 1.0;  // Fragment is lit
            }
        }
    }
    
    // Average the 9 samples
    shadow /= 9.0;
    
    return shadow;
}

/**
 * Performs PCF 3x3 kernel shadow sampling using hardware comparison.
 * 
 * Alternative implementation using hardware shadow comparison (sampler2DShadow).
 * This is more efficient on modern GPUs as the comparison is done in hardware.
 * 
 * Input: shadowCoord - shadow map coordinate (in shadow space, XY for position, Z for depth)
 *        shadowMapCompare - shadow map comparison sampler
 *        texelSize - size of one texel in shadow map space
 * Output: shadow factor in [0.0, 1.0]
 * 
 * Validates: Requirement 5 (Cascaded Shadow Mapping)
 */
float sampleShadowPCF3x3Hardware(vec3 shadowCoord, sampler2DShadow shadowMapCompare, 
                                 vec2 texelSize) {
    // Initialize shadow accumulator
    float shadow = 0.0;
    
    // 3x3 PCF kernel using hardware comparison
    for (int x = -1; x <= 1; x++) {
        for (int y = -1; y <= 1; y++) {
            // Calculate offset in shadow map space
            vec2 offset = vec2(float(x), float(y)) * texelSize;
            
            // Sample shadow map with hardware comparison
            // texture() with sampler2DShadow automatically performs depth comparison
            vec3 sampleCoord = vec3(shadowCoord.xy + offset, shadowCoord.z);
            shadow += texture(shadowMapCompare, sampleCoord);
        }
    }
    
    // Average the 9 samples
    shadow /= 9.0;
    
    return shadow;
}

// ============================================================================
// SHADOW COORDINATE TRANSFORMATION
// ============================================================================

/**
 * Transforms a world-space position to shadow map space.
 * 
 * Converts world-space coordinates to shadow map coordinates using the
 * shadow view-projection matrices. The result is in normalized device
 * coordinates (NDC) space, which needs to be converted to texture coordinates.
 * 
 * Input: worldPos - position in world space
 * Output: shadow map coordinate in texture space [0.0, 1.0]
 * 
 * Validates: Requirement 5 (Cascaded Shadow Mapping)
 */
vec3 transformToShadowSpace(vec3 worldPos) {
    // Transform to shadow view space
    vec4 shadowViewPos = shadowModelView * vec4(worldPos, 1.0);
    
    // Transform to shadow clip space
    vec4 shadowClipPos = shadowProjection * shadowViewPos;
    
    // Perspective divide to get NDC coordinates
    vec3 shadowNDC = shadowClipPos.xyz / shadowClipPos.w;
    
    // Convert from NDC [-1, 1] to texture coordinates [0, 1]
    vec3 shadowTexCoord = shadowNDC * 0.5 + 0.5;
    
    return shadowTexCoord;
}

/**
 * Checks if a shadow coordinate is within valid shadow map bounds.
 * 
 * Shadow coordinates outside [0.0, 1.0] are outside the shadow map and
 * should not be sampled. This function checks if a coordinate is valid.
 * 
 * Input: shadowCoord - shadow map coordinate
 * Output: true if coordinate is within valid bounds, false otherwise
 * 
 * Validates: Requirement 5 (Cascaded Shadow Mapping)
 */
bool isValidShadowCoord(vec3 shadowCoord) {
    // Check if all coordinates are within [0.0, 1.0]
    return all(greaterThanEqual(shadowCoord, vec3(0.0))) &&
           all(lessThanEqual(shadowCoord, vec3(1.0)));
}

// ============================================================================
// MAIN SHADOW SAMPLING FUNCTION
// ============================================================================

/**
 * Samples cascaded shadow maps with PCF filtering and cascade blending.
 * 
 * This is the main function for shadow sampling. It:
 * 1. Selects the appropriate cascade based on distance
 * 2. Transforms the fragment position to shadow space
 * 3. Samples the shadow map with PCF filtering
 * 4. Blends between cascades for smooth transitions
 * 5. Applies shadow fade at distance boundary
 * 
 * Input: worldPos - fragment position in world space
 *        normal - surface normal (world space)
 *        lightDirection - direction to light source (world space)
 *        distance - distance from camera to fragment
 * Output: shadow factor in [0.0, 1.0] (0.0 = fully shadowed, 1.0 = fully lit)
 * 
 * Validates: Requirement 5 (Cascaded Shadow Mapping)
 */
float sampleCascadedShadow(vec3 worldPos, vec3 normal, vec3 lightDirection, float distance) {
    // Select primary cascade based on distance
    int cascadeIndex = selectShadowCascade(distance);
    
    // Calculate adaptive depth bias
    float depthBias = calculateAdaptiveDepthBias(normal, lightDirection);
    
    // Transform to shadow space
    vec3 shadowCoord = transformToShadowSpace(worldPos);
    
    // Check if shadow coordinate is valid
    if (!isValidShadowCoord(shadowCoord)) {
        return 1.0;  // Outside shadow map, fully lit
    }
    
    // Calculate texel size for PCF sampling
    // Texel size = 1.0 / shadow map resolution
    vec2 texelSize = 1.0 / vec2(SHADOW_MAP_RESOLUTION);
    
    // Sample shadow map with PCF filtering
    float shadow = sampleShadowPCF3x3(shadowCoord.xy, shadowtex0, texelSize, 
                                      shadowCoord.z, depthBias);
    
    // Apply cascade blending for smooth transitions
    #ifdef SHADOW_CASCADE_BLEND
    if (cascadeIndex < 3) {
        // Calculate blend factor for next cascade
        float blendFactor = calculateCascadeBlendFactor(distance, cascadeIndex);
        
        if (blendFactor > 0.0) {
            // Sample next cascade
            int nextCascadeIndex = cascadeIndex + 1;
            vec3 nextShadowCoord = transformToShadowSpace(worldPos);
            
            if (isValidShadowCoord(nextShadowCoord)) {
                float nextShadow = sampleShadowPCF3x3(nextShadowCoord.xy, shadowtex1, 
                                                      texelSize, nextShadowCoord.z, depthBias);
                
                // Blend between cascades
                shadow = mix(shadow, nextShadow, blendFactor);
            }
        }
    }
    #endif
    
    // Apply shadow fade at distance boundary
    float shadowFade = calculateShadowFade(distance);
    shadow = mix(1.0, shadow, shadowFade);
    
    return shadow;
}

/**
 * Simplified shadow sampling without cascade blending.
 * 
 * Faster version that samples only the primary cascade without blending.
 * Useful for performance-critical scenarios or when cascade blending is disabled.
 * 
 * Input: worldPos - fragment position in world space
 *        normal - surface normal (world space)
 *        lightDirection - direction to light source (world space)
 *        distance - distance from camera to fragment
 * Output: shadow factor in [0.0, 1.0]
 * 
 * Validates: Requirement 5 (Cascaded Shadow Mapping)
 */
float sampleCascadedShadowSimple(vec3 worldPos, vec3 normal, vec3 lightDirection, float distance) {
    // Select cascade based on distance
    int cascadeIndex = selectShadowCascade(distance);
    
    // Calculate adaptive depth bias
    float depthBias = calculateAdaptiveDepthBias(normal, lightDirection);
    
    // Transform to shadow space
    vec3 shadowCoord = transformToShadowSpace(worldPos);
    
    // Check if shadow coordinate is valid
    if (!isValidShadowCoord(shadowCoord)) {
        return 1.0;  // Outside shadow map, fully lit
    }
    
    // Calculate texel size for PCF sampling
    vec2 texelSize = 1.0 / vec2(SHADOW_MAP_RESOLUTION);
    
    // Sample shadow map with PCF filtering (no cascade blending)
    float shadow = sampleShadowPCF3x3(shadowCoord.xy, shadowtex0, texelSize, 
                                      shadowCoord.z, depthBias);
    
    // Apply shadow fade at distance boundary
    float shadowFade = calculateShadowFade(distance);
    shadow = mix(1.0, shadow, shadowFade);
    
    return shadow;
}

/**
 * Samples shadow with optional cascade blending based on settings.
 * 
 * Wrapper function that selects between cascade blending and simple sampling
 * based on the SHADOW_CASCADE_BLEND setting.
 * 
 * Input: worldPos - fragment position in world space
 *        normal - surface normal (world space)
 *        lightDirection - direction to light source (world space)
 *        distance - distance from camera to fragment
 * Output: shadow factor in [0.0, 1.0]
 * 
 * Validates: Requirement 5 (Cascaded Shadow Mapping)
 */
float sampleShadow(vec3 worldPos, vec3 normal, vec3 lightDirection, float distance) {
    #ifdef SHADOW_CASCADE_BLEND
    return sampleCascadedShadow(worldPos, normal, lightDirection, distance);
    #else
    return sampleCascadedShadowSimple(worldPos, normal, lightDirection, distance);
    #endif
}

// ============================================================================
// SHADOW DEBUGGING FUNCTIONS
// ============================================================================

/**
 * Visualizes cascade selection for debugging.
 * 
 * Returns a color representing which cascade is being used:
 * - Red: Cascade 0 (0-64 blocks)
 * - Green: Cascade 1 (64-128 blocks)
 * - Blue: Cascade 2 (128-256 blocks)
 * - Yellow: Cascade 3 (256+ blocks)
 * 
 * Input: distance - distance from camera to fragment
 * Output: debug color
 * 
 * Note: For debugging only, remove in production.
 */
vec3 debugCascadeVisualization(float distance) {
    int cascadeIndex = selectShadowCascade(distance);
    
    switch (cascadeIndex) {
        case 0: return vec3(1.0, 0.0, 0.0);  // Red
        case 1: return vec3(0.0, 1.0, 0.0);  // Green
        case 2: return vec3(0.0, 0.0, 1.0);  // Blue
        case 3: return vec3(1.0, 1.0, 0.0);  // Yellow
        default: return vec3(1.0);            // White
    }
}

/**
 * Visualizes cascade blend factor for debugging.
 * 
 * Returns a grayscale value representing the blend factor between cascades.
 * 0.0 (black) = fully in current cascade
 * 1.0 (white) = fully in next cascade
 * 
 * Input: distance - distance from camera to fragment
 * Output: debug grayscale value
 * 
 * Note: For debugging only, remove in production.
 */
float debugCascadeBlendVisualization(float distance) {
    int cascadeIndex = selectShadowCascade(distance);
    return calculateCascadeBlendFactor(distance, cascadeIndex);
}

/**
 * Visualizes shadow fade for debugging.
 * 
 * Returns a grayscale value representing the shadow fade factor.
 * 1.0 (white) = full shadow
 * 0.0 (black) = no shadow (faded out)
 * 
 * Input: distance - distance from camera to fragment
 * Output: debug grayscale value
 * 
 * Note: For debugging only, remove in production.
 */
float debugShadowFadeVisualization(float distance) {
    return calculateShadowFade(distance);
}

#endif // SHADOW_GLSL
