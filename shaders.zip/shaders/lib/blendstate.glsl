/*
 * BlendHer Shader - Visual State System (Modern Curves)
 * 
 * This file implements the core visual state system that dynamically blends
 * between BSL's vibrant golden daylight and Spooklementary's horror desaturation.
 * 
 * The system uses Hermite smoothstep curves for smooth transitions between five
 * distinct visual states:
 * 1. Noon Vibrancy (blend factor 1.0) - Full BSL saturation and golden colors
 * 2. Sunset Purple Haze (blend factor 0.2-0.8) - Transitional state with purple tint
 * 3. Playable Midnight (blend factor 0.1) - Desaturated with cyan tint
 * 4. Creeping Shadows (blend factor 0.0-0.3) - Reduced saturation, darker tones
 * 5. Storm (blend factor 0.0) - Full Spooklementary with grey-purple shivering
 * 
 * The blend factor is calculated from world time and modified by:
 * - Weather conditions (rain/thunder = 0.0 blend)
 * - Canopy detection (dense trees = Creeping Shadows)
 * - Smooth Hermite interpolation over 1200 ticks
 * 
 * Compatible with: GLSL 460 core, Iris 1.8.5+, OptiFine
 * References: Requirement 7 (Visual State System)
 */

#ifndef BLENDSTATE_GLSL
#define BLENDSTATE_GLSL

#include "uniforms.glsl"
#include "utils.glsl"

// ============================================================================
// VISUAL STATE SYSTEM CONSTANTS
// ============================================================================

// Minecraft day cycle: 24000 ticks per day
// Sunrise: 0 ticks (6:00 AM)
// Noon: 6000 ticks (12:00 PM)
// Sunset: 12000 ticks (6:00 PM)
// Midnight: 18000 ticks (12:00 AM)
const float DAY_CYCLE_TICKS = 24000.0;

// Transition duration for smooth blend factor interpolation (in ticks)
// Transitions complete over 1200 ticks (1 minute of game time)
const float TRANSITION_DURATION = 1200.0;

// Time boundaries for visual states (in ticks)
// These define when each state begins and ends
const float SUNRISE_START = 0.0;           // 6:00 AM
const float SUNRISE_END = 2400.0;          // 8:00 AM
const float NOON_START = 4800.0;           // 10:00 AM
const float NOON_PEAK = 6000.0;            // 12:00 PM (peak vibrancy)
const float NOON_END = 7200.0;             // 2:00 PM
const float SUNSET_START = 10800.0;        // 6:00 PM
const float SUNSET_PEAK = 12000.0;         // 6:00 PM (peak purple haze)
const float SUNSET_END = 13200.0;          // 8:00 PM
const float NIGHT_START = 13200.0;         // 8:00 PM
const float MIDNIGHT_PEAK = 18000.0;       // 12:00 AM (peak darkness)
const float NIGHT_END = 22800.0;           // 4:00 AM

// Canopy detection threshold
// If sky light is below this value, we're under dense canopy
const float CANOPY_THRESHOLD = 0.3;

// ============================================================================
// VISUAL STATE DEFINITIONS
// ============================================================================

/**
 * Noon Vibrancy State
 * 
 * Characteristics:
 * - Blend factor: 1.0 (full BSL)
 * - Saturation: 1.0 (vibrant colors)
 * - Fog density: 0.02 (minimal fog)
 * - Purple ambient floor: invisible (alpha 0.0)
 * - Color grading: Golden, warm tones
 * 
 * This state represents the peak of daylight with full BSL saturation
 * and golden color grading. The world feels bright, vibrant, and alive.
 * 
 * Validates: Requirement 7 (Visual State System)
 */
struct NoonVibrancyState {
    float blendFactor;           // 1.0
    float saturation;            // 1.0
    float fogDensity;            // 0.02
    float purpleFloorAlpha;      // 0.0
    vec3 colorGrading;           // Golden (1.0, 0.9, 0.7)
};

/**
 * Sunset Purple Haze State
 * 
 * Characteristics:
 * - Blend factor: 0.2-0.8 (transitional)
 * - Saturation: 0.7-0.9 (slightly reduced)
 * - Fog density: 0.05-0.10 (moderate fog)
 * - Purple ambient floor: growing (alpha 0.2-0.5)
 * - Color grading: Purple-tinted, transitional
 * 
 * This state represents the transition from day to night with growing
 * purple tints and increasing fog. The world feels atmospheric and mysterious.
 * 
 * Validates: Requirement 7 (Visual State System)
 */
struct SunsetPurpleHazeState {
    float blendFactor;           // 0.2-0.8
    float saturation;            // 0.7-0.9
    float fogDensity;            // 0.05-0.10
    float purpleFloorAlpha;      // 0.2-0.5
    vec3 colorGrading;           // Purple-tinted (0.8, 0.6, 0.9)
};

/**
 * Playable Midnight State
 * 
 * Characteristics:
 * - Blend factor: 0.1 (mostly Spooklementary)
 * - Saturation: 0.5 (desaturated)
 * - Fog density: 0.12 (heavy fog)
 * - Purple ambient floor: dominant (alpha 0.7-0.9)
 * - Color grading: Cyan tint (RGB: 0.0, 0.6, 0.8)
 * - Visibility: 32+ blocks maintained
 * 
 * This state represents the dead of night with desaturated colors,
 * cyan tinting, and heavy purple ambient floor. The world feels dark,
 * ominous, and atmospheric while remaining playable.
 * 
 * Validates: Requirement 7 (Visual State System)
 */
struct PlayableMidnightState {
    float blendFactor;           // 0.1
    float saturation;            // 0.5
    float fogDensity;            // 0.12
    float purpleFloorAlpha;      // 0.7-0.9
    vec3 colorGrading;           // Cyan tint (0.0, 0.6, 0.8)
};

/**
 * Creeping Shadows State
 * 
 * Characteristics:
 * - Blend factor: 0.0-0.3 (mostly Spooklementary)
 * - Saturation: 0.4-0.6 (reduced)
 * - Fog density: 0.08-0.12 (moderate to heavy)
 * - Purple ambient floor: active (alpha 0.3-0.6)
 * - Color grading: Dark, desaturated tones
 * - Trigger: Dense canopy (sky light < 0.3)
 * 
 * This state is triggered when the player is under dense canopy,
 * regardless of time of day. The world feels shadowy, mysterious,
 * and slightly ominous.
 * 
 * Validates: Requirement 7 (Visual State System)
 */
struct CreepingShadowsState {
    float blendFactor;           // 0.0-0.3
    float saturation;            // 0.4-0.6
    float fogDensity;            // 0.08-0.12
    float purpleFloorAlpha;      // 0.3-0.6
    vec3 colorGrading;           // Dark, desaturated (0.5, 0.5, 0.6)
};

/**
 * Storm State
 * 
 * Characteristics:
 * - Blend factor: 0.0 (full Spooklementary)
 * - Saturation: 0.3 (heavily desaturated)
 * - Fog density: 0.08 (reduced from Spooklementary 0.15)
 * - Purple ambient floor: dominant (alpha 0.8-1.0)
 * - Color grading: Grey-purple with shivering effect
 * - Shivering: Time-based noise for flickering effect
 * - Trigger: Rain or thunder weather
 * 
 * This state is triggered during rain or thunder weather. The world
 * feels dark, ominous, and chaotic with a shivering grey-purple effect.
 * 
 * Validates: Requirement 7 (Visual State System)
 */
struct StormState {
    float blendFactor;           // 0.0
    float saturation;            // 0.3
    float fogDensity;            // 0.08
    float purpleFloorAlpha;      // 0.8-1.0
    vec3 colorGrading;           // Grey-purple (0.6, 0.4, 0.7)
    float shiveringIntensity;    // 0.1-0.3 (flickering effect)
};

// ============================================================================
// BLEND FACTOR CALCULATION (CORE FUNCTION)
// ============================================================================

/**
 * Calculates blend factor from world time using Hermite smoothstep curves.
 * 
 * This is the core function for the Visual State System. It calculates
 * a smooth blend factor that transitions between visual states based on
 * the current time of day.
 * 
 * The blend factor ranges from 0.0 (Spooklementary - full horror) to 1.0
 * (BSL - full vibrancy). Transitions use Hermite smoothstep curves to
 * ensure smooth, continuous interpolation without discontinuities.
 * 
 * Time-based transitions:
 * - Sunrise (0-2400 ticks): 0.0 → 1.0 (darkness to vibrancy)
 * - Noon (4800-7200 ticks): 1.0 (peak vibrancy)
 * - Sunset (10800-13200 ticks): 1.0 → 0.0 (vibrancy to darkness)
 * - Night (13200-22800 ticks): 0.0 (peak darkness)
 * 
 * Input: worldTime - current world time in ticks (0-24000)
 * Output: blend factor in [0.0, 1.0]
 * 
 * Validates: Requirement 7 (Visual State System)
 */
float calculateBlendFactorFromTime(float worldTime) {
    // Normalize world time to [0.0, 1.0] range
    float normalizedTime = mod(worldTime, DAY_CYCLE_TICKS) / DAY_CYCLE_TICKS;
    
    // Calculate blend factor based on time of day
    float blendFactor = 0.0;
    
    // Sunrise transition (0-2400 ticks): darkness to vibrancy
    if (worldTime < SUNRISE_END) {
        // Smooth transition from 0.0 to 1.0 over sunrise duration
        float sunriseProgress = worldTime / (SUNRISE_END - SUNRISE_START);
        blendFactor = hermiteSmootstep(sunriseProgress, 0.0, 1.0);
    }
    // Morning to noon (2400-7200 ticks): maintain vibrancy
    else if (worldTime < NOON_END) {
        blendFactor = 1.0;
    }
    // Noon to afternoon (7200-10800 ticks): maintain vibrancy
    else if (worldTime < SUNSET_START) {
        blendFactor = 1.0;
    }
    // Sunset transition (10800-13200 ticks): vibrancy to darkness
    else if (worldTime < SUNSET_END) {
        // Smooth transition from 1.0 to 0.0 over sunset duration
        float sunsetProgress = (worldTime - SUNSET_START) / (SUNSET_END - SUNSET_START);
        blendFactor = hermiteSmootstep(1.0 - sunsetProgress, 0.0, 1.0);
    }
    // Night (13200-22800 ticks): maintain darkness
    else if (worldTime < NIGHT_END) {
        blendFactor = 0.0;
    }
    // Late night to sunrise (22800-24000 ticks): maintain darkness
    else {
        blendFactor = 0.0;
    }
    
    // Ensure blend factor is always in valid range
    return clamp(blendFactor, 0.0, 1.0);
}

/**
 * Applies weather modifiers to blend factor.
 * 
 * Weather conditions can override the time-based blend factor:
 * - Rain: reduces blend factor (darker, more atmospheric)
 * - Thunder: forces blend factor to 0.0 (full storm state)
 * 
 * Input: blendFactor - base blend factor from time calculation
 *        rainStrength - rain intensity (0.0-1.0)
 *        thunderStrength - thunder intensity (0.0-1.0)
 * Output: weather-modified blend factor in [0.0, 1.0]
 * 
 * Validates: Requirement 7 (Visual State System)
 */
float applyWeatherModifiers(float blendFactor, float rainStrength, float thunderStrength) {
    // Clamp inputs to valid ranges
    blendFactor = clamp(blendFactor, 0.0, 1.0);
    rainStrength = clamp(rainStrength, 0.0, 1.0);
    thunderStrength = clamp(thunderStrength, 0.0, 1.0);
    
    // Thunder forces full storm state (blend factor 0.0)
    if (thunderStrength > 0.1) {
        // Smooth transition to storm state
        blendFactor = mix(blendFactor, 0.0, thunderStrength);
    }
    
    // Rain reduces blend factor (makes world darker and more atmospheric)
    if (rainStrength > 0.1) {
        // Reduce blend factor by up to 50% based on rain strength
        float rainModifier = mix(1.0, 0.5, rainStrength);
        blendFactor *= rainModifier;
    }
    
    // Ensure blend factor remains in valid range
    return clamp(blendFactor, 0.0, 1.0);
}

/**
 * Detects if player is under dense canopy.
 * 
 * Canopy detection is based on sky light level. If sky light is below
 * the canopy threshold, the player is considered to be under dense trees
 * and should use the Creeping Shadows state.
 * 
 * Input: skyLight - normalized sky light level (0.0-1.0)
 * Output: true if under dense canopy, false otherwise
 * 
 * Validates: Requirement 7 (Visual State System)
 */
bool isUnderCanopy(float skyLight) {
    // Clamp sky light to valid range
    skyLight = clamp(skyLight, 0.0, 1.0);
    
    // Check if sky light is below canopy threshold
    return skyLight < CANOPY_THRESHOLD;
}

/**
 * Applies canopy detection to blend factor.
 * 
 * If the player is under dense canopy, override the time-based blend factor
 * with the Creeping Shadows state (blend factor 0.0-0.3).
 * 
 * Input: blendFactor - base blend factor from time and weather
 *        skyLight - normalized sky light level (0.0-1.0)
 * Output: canopy-modified blend factor in [0.0, 1.0]
 * 
 * Validates: Requirement 7 (Visual State System)
 */
float applyCanopyDetection(float blendFactor, float skyLight) {
    // Clamp inputs to valid ranges
    blendFactor = clamp(blendFactor, 0.0, 1.0);
    skyLight = clamp(skyLight, 0.0, 1.0);
    
    // Check if under canopy
    if (isUnderCanopy(skyLight)) {
        // Apply Creeping Shadows state: blend factor 0.0-0.3
        // Darker canopy = lower blend factor
        float canopyDarkness = 1.0 - (skyLight / CANOPY_THRESHOLD);
        float creepingShadowsBlend = mix(0.3, 0.0, canopyDarkness);
        
        // Smoothly transition to Creeping Shadows state
        blendFactor = mix(blendFactor, creepingShadowsBlend, 0.8);
    }
    
    // Ensure blend factor remains in valid range
    return clamp(blendFactor, 0.0, 1.0);
}

/**
 * Calculates final blend factor with all modifiers applied.
 * 
 * This is the main entry point for blend factor calculation. It combines:
 * 1. Time-based blend factor (Hermite smoothstep curves)
 * 2. Weather modifiers (rain/thunder)
 * 3. Canopy detection (dense trees)
 * 
 * The result is a smooth, continuous blend factor that transitions between
 * visual states based on time, weather, and environment.
 * 
 * Input: worldTime - current world time in ticks (0-24000)
 *        rainStrength - rain intensity (0.0-1.0)
 *        thunderStrength - thunder intensity (0.0-1.0)
 *        skyLight - normalized sky light level (0.0-1.0)
 * Output: final blend factor in [0.0, 1.0]
 * 
 * Validates: Requirement 7 (Visual State System)
 */
float calculateFinalBlendFactor(float worldTime, float rainStrength, 
                                float thunderStrength, float skyLight) {
    // Step 1: Calculate base blend factor from time
    float blendFactor = calculateBlendFactorFromTime(worldTime);
    
    // Step 2: Apply weather modifiers
    blendFactor = applyWeatherModifiers(blendFactor, rainStrength, thunderStrength);
    
    // Step 3: Apply canopy detection
    blendFactor = applyCanopyDetection(blendFactor, skyLight);
    
    // Ensure final blend factor is in valid range
    return clamp(blendFactor, 0.0, 1.0);
}

// ============================================================================
// VISUAL STATE HELPER FUNCTIONS
// ============================================================================

/**
 * Gets Noon Vibrancy state characteristics.
 * 
 * Returns the visual characteristics for the Noon Vibrancy state
 * (blend factor 1.0).
 * 
 * Output: NoonVibrancyState struct with all characteristics
 * 
 * Validates: Requirement 7 (Visual State System)
 */
NoonVibrancyState getNoonVibrancyState() {
    NoonVibrancyState state;
    state.blendFactor = 1.0;
    state.saturation = 1.0;
    state.fogDensity = 0.02;
    state.purpleFloorAlpha = 0.0;
    state.colorGrading = vec3(1.0, 0.9, 0.7);  // Golden
    return state;
}

/**
 * Gets Sunset Purple Haze state characteristics.
 * 
 * Returns the visual characteristics for the Sunset Purple Haze state
 * (blend factor 0.2-0.8).
 * 
 * Input: blendFactor - current blend factor (0.2-0.8)
 * Output: SunsetPurpleHazeState struct with interpolated characteristics
 * 
 * Validates: Requirement 7 (Visual State System)
 */
SunsetPurpleHazeState getSunsetPurpleHazeState(float blendFactor) {
    // Normalize blend factor to [0.0, 1.0] for this state
    float normalizedBlend = clamp((blendFactor - 0.2) / 0.6, 0.0, 1.0);
    
    SunsetPurpleHazeState state;
    state.blendFactor = blendFactor;
    state.saturation = mix(0.7, 0.9, normalizedBlend);
    state.fogDensity = mix(0.05, 0.10, 1.0 - normalizedBlend);
    state.purpleFloorAlpha = mix(0.2, 0.5, 1.0 - normalizedBlend);
    state.colorGrading = vec3(0.8, 0.6, 0.9);  // Purple-tinted
    return state;
}

/**
 * Gets Playable Midnight state characteristics.
 * 
 * Returns the visual characteristics for the Playable Midnight state
 * (blend factor 0.1).
 * 
 * Output: PlayableMidnightState struct with all characteristics
 * 
 * Validates: Requirement 7 (Visual State System)
 */
PlayableMidnightState getPlayableMidnightState() {
    PlayableMidnightState state;
    state.blendFactor = 0.1;
    state.saturation = 0.5;
    state.fogDensity = 0.12;
    state.purpleFloorAlpha = mix(0.7, 0.9, 0.5);  // Mid-range
    state.colorGrading = vec3(0.0, 0.6, 0.8);    // Cyan tint
    return state;
}

/**
 * Gets Creeping Shadows state characteristics.
 * 
 * Returns the visual characteristics for the Creeping Shadows state
 * (blend factor 0.0-0.3, triggered by dense canopy).
 * 
 * Input: blendFactor - current blend factor (0.0-0.3)
 * Output: CreepingShadowsState struct with interpolated characteristics
 * 
 * Validates: Requirement 7 (Visual State System)
 */
CreepingShadowsState getCreepingShadowsState(float blendFactor) {
    // Normalize blend factor to [0.0, 1.0] for this state
    float normalizedBlend = clamp(blendFactor / 0.3, 0.0, 1.0);
    
    CreepingShadowsState state;
    state.blendFactor = blendFactor;
    state.saturation = mix(0.4, 0.6, normalizedBlend);
    state.fogDensity = mix(0.08, 0.12, 1.0 - normalizedBlend);
    state.purpleFloorAlpha = mix(0.3, 0.6, 1.0 - normalizedBlend);
    state.colorGrading = vec3(0.5, 0.5, 0.6);    // Dark, desaturated
    return state;
}

/**
 * Gets Storm state characteristics.
 * 
 * Returns the visual characteristics for the Storm state
 * (blend factor 0.0, triggered by rain/thunder).
 * 
 * Input: time - animation time for shivering effect
 * Output: StormState struct with all characteristics
 * 
 * Validates: Requirement 7 (Visual State System)
 */
StormState getStormState(float time) {
    StormState state;
    state.blendFactor = 0.0;
    state.saturation = 0.3;
    state.fogDensity = 0.08;  // Reduced from Spooklementary 0.15
    state.purpleFloorAlpha = mix(0.8, 1.0, 0.5);  // Mid-range
    state.colorGrading = vec3(0.6, 0.4, 0.7);     // Grey-purple
    
    // Calculate shivering effect using time-based noise
    // Shivering creates a flickering effect by modulating color intensity
    float shiveringNoise = sin(time * 10.0) * 0.5 + 0.5;  // Oscillate 0.0-1.0
    state.shiveringIntensity = mix(0.1, 0.3, shiveringNoise);
    
    return state;
}

/**
 * Applies shivering effect to color (for Storm state).
 * 
 * The shivering effect creates a flickering, unstable appearance
 * by modulating color intensity based on time-based noise.
 * 
 * Input: color - original color (RGB)
 *        shiveringIntensity - intensity of shivering effect (0.0-1.0)
 * Output: color with shivering effect applied
 * 
 * Validates: Requirement 7 (Visual State System)
 */
vec3 applyShiveringEffect(vec3 color, float shiveringIntensity) {
    // Clamp inputs to valid ranges
    color = clamp(color, vec3(0.0), vec3(1.0));
    shiveringIntensity = clamp(shiveringIntensity, 0.0, 1.0);
    
    // Apply shivering by modulating brightness
    // Shivering reduces brightness slightly, creating an unstable effect
    float shiveringModifier = mix(1.0, 0.7, shiveringIntensity);
    color *= shiveringModifier;
    
    // Add slight grey-purple tint to enhance storm effect
    vec3 stormTint = vec3(0.6, 0.4, 0.7);
    color = mix(color, stormTint, shiveringIntensity * 0.2);
    
    // Ensure output is in valid range
    return clamp(color, vec3(0.0), vec3(1.0));
}

// ============================================================================
// STATE INTERPOLATION HELPER FUNCTIONS
// ============================================================================

/**
 * Interpolates between two visual states.
 * 
 * Smoothly blends between two states based on a blend parameter.
 * Used for smooth transitions between visual states.
 * 
 * Input: state1 - first state (blend parameter 0.0)
 *        state2 - second state (blend parameter 1.0)
 *        blendParam - interpolation parameter (0.0-1.0)
 * Output: interpolated state characteristics
 * 
 * Validates: Requirement 7 (Visual State System)
 */
vec3 interpolateStateColor(vec3 color1, vec3 color2, float blendParam) {
    // Clamp blend parameter to valid range
    blendParam = clamp(blendParam, 0.0, 1.0);
    
    // Linear interpolation between colors
    return mix(color1, color2, blendParam);
}

/**
 * Interpolates fog density between two states.
 * 
 * Smoothly blends fog density based on a blend parameter.
 * 
 * Input: fogDensity1 - first state fog density
 *        fogDensity2 - second state fog density
 *        blendParam - interpolation parameter (0.0-1.0)
 * Output: interpolated fog density
 * 
 * Validates: Requirement 7 (Visual State System)
 */
float interpolateFogDensity(float fogDensity1, float fogDensity2, float blendParam) {
    // Clamp blend parameter to valid range
    blendParam = clamp(blendParam, 0.0, 1.0);
    
    // Linear interpolation between fog densities
    return mix(fogDensity1, fogDensity2, blendParam);
}

/**
 * Interpolates purple ambient floor intensity between two states.
 * 
 * Smoothly blends purple floor alpha based on a blend parameter.
 * 
 * Input: purpleAlpha1 - first state purple floor alpha
 *        purpleAlpha2 - second state purple floor alpha
 *        blendParam - interpolation parameter (0.0-1.0)
 * Output: interpolated purple floor alpha
 * 
 * Validates: Requirement 7 (Visual State System)
 */
float interpolatePurpleFloorAlpha(float purpleAlpha1, float purpleAlpha2, float blendParam) {
    // Clamp blend parameter to valid range
    blendParam = clamp(blendParam, 0.0, 1.0);
    
    // Linear interpolation between purple floor alphas
    return mix(purpleAlpha1, purpleAlpha2, blendParam);
}

#endif // BLENDSTATE_GLSL


// ============================================================================
// SIMPLE BLEND FACTOR GETTER
// ============================================================================

/**
 * Gets the current blend factor using shader uniforms.
 * 
 * This is a convenience function that retrieves the blend factor
 * from shader uniforms. In a full implementation, this would read
 * from a uniform that's updated by the shader pack.
 * 
 * Output: blend factor in [0.0, 1.0]
 * 
 * Validates: Requirement 7 (Visual State System)
 */
float getBlendFactor() {
    // In a full implementation, this would read from a uniform:
    // return blendFactorUniform;
    
    // For now, calculate from world time
    // This is a placeholder implementation
    float worldTimeValue = mod(float(worldTime), DAY_CYCLE_TICKS);
    float rainStrength = 0.0;  // Placeholder
    float thunderStrength = 0.0;  // Placeholder
    float skyLight = 1.0;  // Placeholder
    
    return calculateFinalBlendFactor(worldTimeValue, rainStrength, thunderStrength, skyLight);
}

/**
 * Gets the blend factor with explicit parameters.
 * 
 * Calculates blend factor using provided parameters instead of uniforms.
 * Useful for testing or when uniforms are not available.
 * 
 * Input: worldTime - current world time in ticks (0-24000)
 *        rainStrength - rain intensity (0.0-1.0)
 *        thunderStrength - thunder intensity (0.0-1.0)
 *        skyLight - normalized sky light level (0.0-1.0)
 * Output: blend factor in [0.0, 1.0]
 * 
 * Validates: Requirement 7 (Visual State System)
 */
float getBlendFactorWithParams(float worldTime, float rainStrength, 
                               float thunderStrength, float skyLight) {
    return calculateFinalBlendFactor(worldTime, rainStrength, thunderStrength, skyLight);
}

