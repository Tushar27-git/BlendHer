/**
 * BlendHer Shader - Purple Ambient Floor Property-Based Tests
 * 
 * This test suite validates the purple ambient floor system using property-based testing.
 * It ensures that:
 * - Final color never exceeds 1.0 (no overbright)
 * - Intensity correctly scales with blend factor
 * - Additive blending preserves visibility
 * - Purple floor invisible at blend factor 1.0
 * 
 * Validates: Requirement 20 (Correctness Properties), Requirement 11 (Purple Ambient Floor)
 * 
 * Test Framework: Vitest with fast-check for property-based testing
 */

import { describe, it, expect } from 'vitest';
import fc from 'fast-check';

// ============================================================================
// PURPLE FLOOR CONSTANTS (from settings.glsl)
// ============================================================================

const PURPLE_COLOR: [number, number, number] = [0.4, 0.2, 0.6];
const PURPLE_FLOOR_INTENSITY_MIN = 0.0;
const PURPLE_FLOOR_INTENSITY_MAX = 1.0;

// ============================================================================
// PURPLE FLOOR IMPLEMENTATIONS (TypeScript versions for testing)
// ============================================================================

/**
 * Calculate purple floor intensity based on blend factor
 * Intensity increases as blend factor decreases (more purple in darkness)
 */
function calculatePurpleFloorIntensity(blendFactor: number): number {
    // At blend 1.0 (noon): intensity = 0.0 (invisible)
    // At blend 0.0 (midnight): intensity = 1.0 (maximum)
    return 1.0 - blendFactor;
}

/**
 * Calculate purple floor color contribution
 */
function calculatePurpleFloorColor(blendFactor: number): [number, number, number] {
    const intensity = calculatePurpleFloorIntensity(blendFactor);
    
    return [
        PURPLE_COLOR[0] * intensity,
        PURPLE_COLOR[1] * intensity,
        PURPLE_COLOR[2] * intensity,
    ];
}

/**
 * Apply purple floor with additive blending
 */
function applyPurpleFloor(
    sceneColor: [number, number, number],
    blendFactor: number
): [number, number, number] {
    const purpleFloor = calculatePurpleFloorColor(blendFactor);
    
    // Additive blending
    return [
        sceneColor[0] + purpleFloor[0],
        sceneColor[1] + purpleFloor[1],
        sceneColor[2] + purpleFloor[2],
    ];
}

/**
 * Clamp color to [0.0, 1.0]
 */
function clampColor(color: [number, number, number]): [number, number, number] {
    return [
        Math.max(0.0, Math.min(1.0, color[0])),
        Math.max(0.0, Math.min(1.0, color[1])),
        Math.max(0.0, Math.min(1.0, color[2])),
    ];
}

/**
 * Apply purple floor with clamping
 */
function applyPurpleFloorClamped(
    sceneColor: [number, number, number],
    blendFactor: number
): [number, number, number] {
    const withPurple = applyPurpleFloor(sceneColor, blendFactor);
    return clampColor(withPurple);
}

/**
 * Check if color is valid (no NaN, no Inf)
 */
function isValidColor(color: [number, number, number]): boolean {
    return Number.isFinite(color[0]) &&
           Number.isFinite(color[1]) &&
           Number.isFinite(color[2]) &&
           !Number.isNaN(color[0]) &&
           !Number.isNaN(color[1]) &&
           !Number.isNaN(color[2]);
}

/**
 * Calculate luminance of a color
 */
function calculateLuminance(color: [number, number, number]): number {
    return 0.299 * color[0] + 0.587 * color[1] + 0.114 * color[2];
}

// ============================================================================
// PROPERTY-BASED TESTS
// ============================================================================

describe('Purple Ambient Floor - Clamping', () => {
    
    // ========================================================================
    // Property 4.1: Purple Floor Clamping
    // ========================================================================
    
    it('Property 4.1: Final color never exceeds 1.0 (no overbright)', () => {
        fc.assert(
            fc.property(
                fc.tuple(
                    fc.float({ min: 0, max: 1, noNaN: true }),
                    fc.float({ min: 0, max: 1, noNaN: true }),
                    fc.float({ min: 0, max: 1, noNaN: true })
                ),
                fc.float({ min: 0, max: 1, noNaN: true }),
                (sceneTuple, blendFactor) => {
                    const sceneColor = sceneTuple as [number, number, number];
                    const finalColor = applyPurpleFloorClamped(sceneColor, blendFactor);
                    
                    // All channels must be ≤ 1.0
                    expect(finalColor[0]).toBeLessThanOrEqual(1.0);
                    expect(finalColor[1]).toBeLessThanOrEqual(1.0);
                    expect(finalColor[2]).toBeLessThanOrEqual(1.0);
                    
                    // All channels must be ≥ 0.0
                    expect(finalColor[0]).toBeGreaterThanOrEqual(0.0);
                    expect(finalColor[1]).toBeGreaterThanOrEqual(0.0);
                    expect(finalColor[2]).toBeGreaterThanOrEqual(0.0);
                }
            ),
            { numRuns: 1000 }
        );
    });
    
    // ========================================================================
    // Property 4.2: No NaN or Inf in Output
    // ========================================================================
    
    it('Property 4.2: Output contains no NaN or Inf values', () => {
        fc.assert(
            fc.property(
                fc.tuple(
                    fc.float({ min: 0, max: 1, noNaN: true }),
                    fc.float({ min: 0, max: 1, noNaN: true }),
                    fc.float({ min: 0, max: 1, noNaN: true })
                ),
                fc.float({ min: 0, max: 1, noNaN: true }),
                (sceneTuple, blendFactor) => {
                    const sceneColor = sceneTuple as [number, number, number];
                    const finalColor = applyPurpleFloorClamped(sceneColor, blendFactor);
                    
                    expect(isValidColor(finalColor)).toBe(true);
                }
            ),
            { numRuns: 1000 }
        );
    });
});

describe('Purple Ambient Floor - Intensity Scaling', () => {
    
    // ========================================================================
    // Property 4.3: Purple Floor Intensity Scaling
    // ========================================================================
    
    it('Property 4.3: Intensity correctly scales with blend factor', () => {
        fc.assert(
            fc.property(
                fc.float({ min: 0, max: 1, noNaN: true }),
                fc.float({ min: 0, max: 1, noNaN: true }),
                (blendFactor1, blendFactor2) => {
                    if (blendFactor1 >= blendFactor2) return;  // Skip if not ordered
                    
                    const intensity1 = calculatePurpleFloorIntensity(blendFactor1);
                    const intensity2 = calculatePurpleFloorIntensity(blendFactor2);
                    
                    // Lower blend factor should have higher intensity
                    expect(intensity1).toBeGreaterThanOrEqual(intensity2);
                }
            ),
            { numRuns: 1000 }
        );
    });
    
    // ========================================================================
    // Property 4.4: Intensity Range
    // ========================================================================
    
    it('Property 4.4: Purple floor intensity in [0.0, 1.0]', () => {
        fc.assert(
            fc.property(
                fc.float({ min: 0, max: 1, noNaN: true }),
                (blendFactor) => {
                    const intensity = calculatePurpleFloorIntensity(blendFactor);
                    
                    expect(intensity).toBeGreaterThanOrEqual(0.0);
                    expect(intensity).toBeLessThanOrEqual(1.0);
                }
            ),
            { numRuns: 1000 }
        );
    });
    
    // ========================================================================
    // Property 4.5: Intensity at Blend 1.0
    // ========================================================================
    
    it('Property 4.5: Purple floor invisible at blend factor 1.0', () => {
        const intensity = calculatePurpleFloorIntensity(1.0);
        expect(intensity).toBe(0.0);
    });
    
    // ========================================================================
    // Property 4.6: Intensity at Blend 0.0
    // ========================================================================
    
    it('Property 4.6: Purple floor maximum at blend factor 0.0', () => {
        const intensity = calculatePurpleFloorIntensity(0.0);
        expect(intensity).toBe(1.0);
    });
    
    // ========================================================================
    // Property 4.7: Intensity Monotonicity
    // ========================================================================
    
    it('Property 4.7: Intensity decreases monotonically with blend factor', () => {
        let prevIntensity = 1.0;
        
        for (let blend = 0; blend <= 1.0; blend += 0.1) {
            const intensity = calculatePurpleFloorIntensity(blend);
            
            expect(intensity).toBeLessThanOrEqual(prevIntensity);
            prevIntensity = intensity;
        }
    });
});

describe('Purple Ambient Floor - Additive Blending', () => {
    
    // ========================================================================
    // Property 4.8: Additive Blending Preserves Visibility
    // ========================================================================
    
    it('Property 4.8: Additive blending never darkens scene', () => {
        fc.assert(
            fc.property(
                fc.tuple(
                    fc.float({ min: 0, max: 1, noNaN: true }),
                    fc.float({ min: 0, max: 1, noNaN: true }),
                    fc.float({ min: 0, max: 1, noNaN: true })
                ),
                fc.float({ min: 0, max: 1, noNaN: true }),
                (sceneTuple, blendFactor) => {
                    const sceneColor = sceneTuple as [number, number, number];
                    const withPurple = applyPurpleFloor(sceneColor, blendFactor);
                    
                    // Additive blending should never darken
                    expect(withPurple[0]).toBeGreaterThanOrEqual(sceneColor[0]);
                    expect(withPurple[1]).toBeGreaterThanOrEqual(sceneColor[1]);
                    expect(withPurple[2]).toBeGreaterThanOrEqual(sceneColor[2]);
                }
            ),
            { numRuns: 1000 }
        );
    });
    
    // ========================================================================
    // Property 4.9: Additive Blending Increases Luminance
    // ========================================================================
    
    it('Property 4.9: Purple floor increases luminance (except at blend 1.0)', () => {
        fc.assert(
            fc.property(
                fc.tuple(
                    fc.float({ min: 0, max: 1, noNaN: true }),
                    fc.float({ min: 0, max: 1, noNaN: true }),
                    fc.float({ min: 0, max: 1, noNaN: true })
                ),
                fc.float({ min: 0, max: Math.fround(0.99), noNaN: true }),  // Exclude blend 1.0
                (sceneTuple, blendFactor) => {
                    const sceneColor = sceneTuple as [number, number, number];
                    const withPurple = applyPurpleFloor(sceneColor, blendFactor);
                    
                    const lumBefore = calculateLuminance(sceneColor);
                    const lumAfter = calculateLuminance(withPurple);
                    
                    // Luminance should increase (or stay same if blend = 1.0)
                    expect(lumAfter).toBeGreaterThanOrEqual(lumBefore);
                }
            ),
            { numRuns: 1000 }
        );
    });
    
    // ========================================================================
    // Property 4.10: Purple Floor Color Contribution
    // ========================================================================
    
    it('Property 4.10: Purple floor color matches expected purple', () => {
        const purpleFloor = calculatePurpleFloorColor(0.5);
        
        // Should be purple-ish (high blue, moderate red, low green)
        expect(purpleFloor[2]).toBeGreaterThan(purpleFloor[0]);  // Blue > Red
        expect(purpleFloor[0]).toBeGreaterThan(purpleFloor[1]);  // Red > Green
    });
});

describe('Purple Ambient Floor - Blend Factor Dependency', () => {
    
    // ========================================================================
    // Property 4.11: Purple Floor Invisible at Noon
    // ========================================================================
    
    it('Property 4.11: Purple floor invisible at blend factor 1.0 (noon)', () => {
        const sceneColor: [number, number, number] = [0.5, 0.5, 0.5];
        const finalColor = applyPurpleFloorClamped(sceneColor, 1.0);
        
        // Should be unchanged
        expect(finalColor[0]).toBeCloseTo(sceneColor[0], 5);
        expect(finalColor[1]).toBeCloseTo(sceneColor[1], 5);
        expect(finalColor[2]).toBeCloseTo(sceneColor[2], 5);
    });
    
    // ========================================================================
    // Property 4.12: Purple Floor Maximum at Midnight
    // ========================================================================
    
    it('Property 4.12: Purple floor maximum at blend factor 0.0 (midnight)', () => {
        const sceneColor: [number, number, number] = [0.5, 0.5, 0.5];
        const finalColor = applyPurpleFloor(sceneColor, 0.0);
        
        // Should have maximum purple added
        const purpleFloor = calculatePurpleFloorColor(0.0);
        
        expect(finalColor[0]).toBeCloseTo(sceneColor[0] + purpleFloor[0], 5);
        expect(finalColor[1]).toBeCloseTo(sceneColor[1] + purpleFloor[1], 5);
        expect(finalColor[2]).toBeCloseTo(sceneColor[2] + purpleFloor[2], 5);
    });
    
    // ========================================================================
    // Property 4.13: Smooth Intensity Transitions
    // ========================================================================
    
    it('Property 4.13: Purple floor intensity transitions smoothly', () => {
        let prevIntensity = calculatePurpleFloorIntensity(0);
        
        for (let blend = 0.01; blend <= 1.0; blend += 0.01) {
            const intensity = calculatePurpleFloorIntensity(blend);
            
            // Should change smoothly (max 0.01 per 0.01 blend change)
            const intensityDiff = Math.abs(intensity - prevIntensity);
            expect(intensityDiff).toBeLessThanOrEqual(0.01 + 0.001);  // Allow small numerical error
            
            prevIntensity = intensity;
        }
    });
});

describe('Purple Ambient Floor - Clamping Behavior', () => {
    
    // ========================================================================
    // Property 4.14: Clamping Prevents Overbright
    // ========================================================================
    
    it('Property 4.14: Clamping prevents overbright pixels', () => {
        // Very bright scene color
        const brightScene: [number, number, number] = [1.0, 1.0, 1.0];
        
        // Even with maximum purple floor, should not exceed 1.0
        const finalColor = applyPurpleFloorClamped(brightScene, 0.0);
        
        expect(finalColor[0]).toBeLessThanOrEqual(1.0);
        expect(finalColor[1]).toBeLessThanOrEqual(1.0);
        expect(finalColor[2]).toBeLessThanOrEqual(1.0);
    });
    
    // ========================================================================
    // Property 4.15: Clamping Preserves Black
    // ========================================================================
    
    it('Property 4.15: Clamping preserves black pixels', () => {
        const blackScene: [number, number, number] = [0, 0, 0];
        
        // Black should remain black (no negative clamping)
        const finalColor = applyPurpleFloorClamped(blackScene, 0.0);
        
        expect(finalColor[0]).toBeGreaterThanOrEqual(0.0);
        expect(finalColor[1]).toBeGreaterThanOrEqual(0.0);
        expect(finalColor[2]).toBeGreaterThanOrEqual(0.0);
    });
});

describe('Purple Ambient Floor - Edge Cases', () => {
    
    it('Edge Case 1: Black scene with maximum purple', () => {
        const black: [number, number, number] = [0, 0, 0];
        const finalColor = applyPurpleFloorClamped(black, 0.0);
        
        // Should have purple color
        expect(finalColor[2]).toBeGreaterThan(finalColor[1]);  // Blue > Green
        expect(finalColor[0]).toBeGreaterThan(finalColor[1]);  // Red > Green
    });
    
    it('Edge Case 2: White scene with maximum purple', () => {
        const white: [number, number, number] = [1, 1, 1];
        const finalColor = applyPurpleFloorClamped(white, 0.0);
        
        // Should be clamped to white
        expect(finalColor[0]).toBe(1.0);
        expect(finalColor[1]).toBe(1.0);
        expect(finalColor[2]).toBe(1.0);
    });
    
    it('Edge Case 3: Gray scene with medium purple', () => {
        const gray: [number, number, number] = [0.5, 0.5, 0.5];
        const finalColor = applyPurpleFloorClamped(gray, 0.5);
        
        // Should be valid and slightly purple-tinted
        expect(isValidColor(finalColor)).toBe(true);
        expect(finalColor[2]).toBeGreaterThan(finalColor[1]);  // Blue > Green
    });
    
    it('Edge Case 4: Very dark scene with maximum purple', () => {
        const veryDark: [number, number, number] = [0.01, 0.01, 0.01];
        const finalColor = applyPurpleFloorClamped(veryDark, 0.0);
        
        // Should be valid and purple
        expect(isValidColor(finalColor)).toBe(true);
        expect(finalColor[2]).toBeGreaterThan(finalColor[1]);  // Blue > Green
    });
    
    it('Edge Case 5: Blend factor at boundaries', () => {
        const sceneColor: [number, number, number] = [0.5, 0.5, 0.5];
        
        const atZero = applyPurpleFloorClamped(sceneColor, 0.0);
        const atOne = applyPurpleFloorClamped(sceneColor, 1.0);
        
        expect(isValidColor(atZero)).toBe(true);
        expect(isValidColor(atOne)).toBe(true);
    });
});

describe('Purple Ambient Floor - Visibility Preservation', () => {
    
    it('Visibility Property 1: Dark areas remain visible', () => {
        const darkScene: [number, number, number] = [0.1, 0.1, 0.1];
        const finalColor = applyPurpleFloorClamped(darkScene, 0.0);
        
        // Should be brighter than original (purple added)
        const lumBefore = calculateLuminance(darkScene);
        const lumAfter = calculateLuminance(finalColor);
        
        expect(lumAfter).toBeGreaterThan(lumBefore);
    });
    
    it('Visibility Property 2: Bright areas remain bright', () => {
        const brightScene: [number, number, number] = [0.9, 0.9, 0.9];
        const finalColor = applyPurpleFloorClamped(brightScene, 0.0);
        
        // Should remain bright (clamped, not darkened)
        const lumBefore = calculateLuminance(brightScene);
        const lumAfter = calculateLuminance(finalColor);
        
        expect(lumAfter).toBeGreaterThanOrEqual(lumBefore * 0.9);  // Allow small loss from clamping
    });
});
