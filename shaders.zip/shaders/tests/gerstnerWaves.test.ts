/**
 * BlendHer Shader - Gerstner Waves Property-Based Tests
 * 
 * This test suite validates the Gerstner wave water displacement system using property-based testing.
 * It ensures that:
 * - Normal vectors always valid (normalized)
 * - Displacement produces smooth wave patterns
 * - Vertical displacement only (Y-axis)
 * - Wave patterns are physically plausible
 * 
 * Validates: Requirement 20 (Correctness Properties), Requirement 9 (Gerstner Wave Water)
 * 
 * Test Framework: Vitest with fast-check for property-based testing
 */

import { describe, it, expect } from 'vitest';
import fc from 'fast-check';

// ============================================================================
// GERSTNER WAVE CONSTANTS (from water.glsl)
// ============================================================================

const WAVE_COUNT = 4;
const WAVE_FREQUENCIES = [0.1, 0.2, 0.3, 0.4];
const WAVE_AMPLITUDES = [0.1, 0.08, 0.06, 0.04];
const WAVE_PHASES = [0.0, 1.57, 3.14, 4.71];  // 0, π/2, π, 3π/2

// ============================================================================
// GERSTNER WAVE IMPLEMENTATIONS (TypeScript versions for testing)
// ============================================================================

/**
 * Vector normalization
 */
function normalize(v: [number, number, number]): [number, number, number] {
    const len = Math.sqrt(v[0] * v[0] + v[1] * v[1] + v[2] * v[2]);
    if (len === 0) return [0, 0, 0];
    return [v[0] / len, v[1] / len, v[2] / len];
}

/**
 * Vector length
 */
function length(v: [number, number, number]): number {
    return Math.sqrt(v[0] * v[0] + v[1] * v[1] + v[2] * v[2]);
}

/**
 * Vector dot product
 */
function dot(a: [number, number, number], b: [number, number, number]): number {
    return a[0] * b[0] + a[1] * b[1] + a[2] * b[2];
}

/**
 * Vector cross product
 */
function cross(a: [number, number, number], b: [number, number, number]): [number, number, number] {
    return [
        a[1] * b[2] - a[2] * b[1],
        a[2] * b[0] - a[0] * b[2],
        a[0] * b[1] - a[1] * b[0],
    ];
}

/**
 * Calculate Gerstner wave displacement at a position
 * Displacement is vertical only (Y-axis)
 */
function calculateGerstnerDisplacement(
    worldPos: [number, number, number],
    time: number
): number {
    let displacement = 0.0;
    
    for (let i = 0; i < WAVE_COUNT; i++) {
        const freq = WAVE_FREQUENCIES[i];
        const amp = WAVE_AMPLITUDES[i];
        const phase = WAVE_PHASES[i];
        
        // Wave equation: y += amplitude * sin(frequency * (x + z) + phase + time)
        const waveInput = freq * (worldPos[0] + worldPos[2]) + phase + time;
        displacement += amp * Math.sin(waveInput);
    }
    
    return displacement;
}

/**
 * Calculate Gerstner wave normal at a position
 * Normal is reconstructed from displacement gradient
 */
function calculateGerstnerNormal(
    worldPos: [number, number, number],
    time: number,
    epsilon: number = 0.01
): [number, number, number] {
    // Sample displacement at nearby points
    const centerDisp = calculateGerstnerDisplacement(worldPos, time);
    
    const xPosDisp = calculateGerstnerDisplacement(
        [worldPos[0] + epsilon, worldPos[1], worldPos[2]],
        time
    );
    const zPosDisp = calculateGerstnerDisplacement(
        [worldPos[0], worldPos[1], worldPos[2] + epsilon],
        time
    );
    
    // Calculate gradients
    const dDispDx = (xPosDisp - centerDisp) / epsilon;
    const dDispDz = (zPosDisp - centerDisp) / epsilon;
    
    // Normal from gradient: N = normalize((-dDispDx, 1, -dDispDz))
    const normal = normalize([-dDispDx, 1.0, -dDispDz]);
    
    return normal;
}

/**
 * Check if normal vector is valid (normalized)
 */
function isNormalValid(normal: [number, number, number]): boolean {
    const len = length(normal);
    // Should be normalized (length ≈ 1.0)
    return Math.abs(len - 1.0) < 0.01 && Number.isFinite(len);
}

/**
 * Check if displacement is vertical only (no X/Z components)
 */
function isDisplacementVerticalOnly(
    worldPos: [number, number, number],
    time: number
): boolean {
    // Gerstner displacement should only affect Y
    // X and Z should remain unchanged
    const displacement = calculateGerstnerDisplacement(worldPos, time);
    
    // Displacement should be a scalar (Y-axis only)
    return Number.isFinite(displacement) && !Number.isNaN(displacement);
}

/**
 * Calculate wave smoothness (gradient magnitude)
 */
function calculateWaveSmoothness(
    worldPos: [number, number, number],
    time: number,
    epsilon: number = 0.01
): number {
    const centerDisp = calculateGerstnerDisplacement(worldPos, time);
    
    const xPosDisp = calculateGerstnerDisplacement(
        [worldPos[0] + epsilon, worldPos[1], worldPos[2]],
        time
    );
    const zPosDisp = calculateGerstnerDisplacement(
        [worldPos[0], worldPos[1], worldPos[2] + epsilon],
        time
    );
    
    const dDispDx = (xPosDisp - centerDisp) / epsilon;
    const dDispDz = (zPosDisp - centerDisp) / epsilon;
    
    // Gradient magnitude
    return Math.sqrt(dDispDx * dDispDx + dDispDz * dDispDz);
}

/**
 * Check if wave pattern is smooth (no discontinuities)
 */
function isWavePatternSmooth(
    worldPos: [number, number, number],
    time: number,
    maxGradient: number = 1.0
): boolean {
    const smoothness = calculateWaveSmoothness(worldPos, time);
    return smoothness <= maxGradient;
}

/**
 * Calculate caustic pattern (screen-space)
 */
function calculateCausticPattern(
    screenPos: [number, number],
    time: number
): number {
    // Simple caustic pattern using sine waves
    const caustic = Math.sin(screenPos[0] * 0.1 + time) *
                    Math.cos(screenPos[1] * 0.1 + time) * 0.5 + 0.5;
    
    return caustic;
}

// ============================================================================
// PROPERTY-BASED TESTS
// ============================================================================

describe('Gerstner Waves - Normal Vector Validity', () => {
    
    // ========================================================================
    // Property 6.1: Normal Vectors Always Valid (Normalized)
    // ========================================================================
    
    it('Property 6.1: Normal vectors always valid (normalized)', () => {
        fc.assert(
            fc.property(
                fc.tuple(
                    fc.float({ min: -100, max: 100, noNaN: true }),
                    fc.float({ min: -100, max: 100, noNaN: true }),
                    fc.float({ min: -100, max: 100, noNaN: true })
                ),
                fc.float({ min: 0, max: 24000, noNaN: true }),
                (posTuple, time) => {
                    const worldPos = posTuple as [number, number, number];
                    const normal = calculateGerstnerNormal(worldPos, time);
                    
                    // Normal should be valid
                    expect(isNormalValid(normal)).toBe(true);
                    
                    // Length should be close to 1.0
                    const len = length(normal);
                    expect(len).toBeCloseTo(1.0, 1);
                }
            ),
            { numRuns: 1000 }
        );
    });
    
    // ========================================================================
    // Property 6.2: Normal Vector Components Valid
    // ========================================================================
    
    it('Property 6.2: Normal vector components are finite', () => {
        fc.assert(
            fc.property(
                fc.tuple(
                    fc.float({ min: -100, max: 100, noNaN: true }),
                    fc.float({ min: -100, max: 100, noNaN: true }),
                    fc.float({ min: -100, max: 100, noNaN: true })
                ),
                fc.float({ min: 0, max: 24000, noNaN: true }),
                (posTuple, time) => {
                    const worldPos = posTuple as [number, number, number];
                    const normal = calculateGerstnerNormal(worldPos, time);
                    
                    // All components should be finite
                    expect(Number.isFinite(normal[0])).toBe(true);
                    expect(Number.isFinite(normal[1])).toBe(true);
                    expect(Number.isFinite(normal[2])).toBe(true);
                    
                    // All components should be in [-1, 1]
                    expect(normal[0]).toBeGreaterThanOrEqual(-1.0);
                    expect(normal[0]).toBeLessThanOrEqual(1.0);
                    expect(normal[1]).toBeGreaterThanOrEqual(-1.0);
                    expect(normal[1]).toBeLessThanOrEqual(1.0);
                    expect(normal[2]).toBeGreaterThanOrEqual(-1.0);
                    expect(normal[2]).toBeLessThanOrEqual(1.0);
                }
            ),
            { numRuns: 1000 }
        );
    });
});

describe('Gerstner Waves - Displacement Properties', () => {
    
    // ========================================================================
    // Property 6.3: Vertical Displacement Only (Y-Axis)
    // ========================================================================
    
    it('Property 6.3: Vertical displacement only (Y-axis)', () => {
        fc.assert(
            fc.property(
                fc.tuple(
                    fc.float({ min: -100, max: 100, noNaN: true }),
                    fc.float({ min: -100, max: 100, noNaN: true }),
                    fc.float({ min: -100, max: 100, noNaN: true })
                ),
                fc.float({ min: 0, max: 24000, noNaN: true }),
                (posTuple, time) => {
                    const worldPos = posTuple as [number, number, number];
                    
                    // Displacement should be vertical only
                    expect(isDisplacementVerticalOnly(worldPos, time)).toBe(true);
                }
            ),
            { numRuns: 1000 }
        );
    });
    
    // ========================================================================
    // Property 6.4: Displacement Range
    // ========================================================================
    
    it('Property 6.4: Displacement magnitude is reasonable', () => {
        fc.assert(
            fc.property(
                fc.tuple(
                    fc.float({ min: -100, max: 100, noNaN: true }),
                    fc.float({ min: -100, max: 100, noNaN: true }),
                    fc.float({ min: -100, max: 100, noNaN: true })
                ),
                fc.float({ min: 0, max: 24000, noNaN: true }),
                (posTuple, time) => {
                    const worldPos = posTuple as [number, number, number];
                    const displacement = calculateGerstnerDisplacement(worldPos, time);
                    
                    // Displacement should be bounded by sum of amplitudes
                    const maxDisplacement = WAVE_AMPLITUDES.reduce((a, b) => a + b, 0);
                    
                    expect(Math.abs(displacement)).toBeLessThanOrEqual(maxDisplacement + 0.01);
                }
            ),
            { numRuns: 1000 }
        );
    });
    
    // ========================================================================
    // Property 6.5: Displacement Continuity
    // ========================================================================
    
    it('Property 6.5: Displacement is continuous (no jumps)', () => {
        fc.assert(
            fc.property(
                fc.tuple(
                    fc.float({ min: -100, max: 100, noNaN: true }),
                    fc.float({ min: -100, max: 100, noNaN: true }),
                    fc.float({ min: -100, max: 100, noNaN: true })
                ),
                fc.float({ min: 0, max: 24000, noNaN: true }),
                (posTuple, time) => {
                    const worldPos = posTuple as [number, number, number];
                    
                    const disp1 = calculateGerstnerDisplacement(worldPos, time);
                    const disp2 = calculateGerstnerDisplacement(
                        [worldPos[0] + 0.1, worldPos[1], worldPos[2]],
                        time
                    );
                    
                    // Displacement should change smoothly
                    const dispDiff = Math.abs(disp1 - disp2);
                    expect(dispDiff).toBeLessThan(0.05);  // Max change per 0.1 units
                }
            ),
            { numRuns: 1000 }
        );
    });
});

describe('Gerstner Waves - Wave Pattern Smoothness', () => {
    
    // ========================================================================
    // Property 6.6: Wave Pattern Smoothness
    // ========================================================================
    
    it('Property 6.6: Wave patterns are smooth (no discontinuities)', () => {
        fc.assert(
            fc.property(
                fc.tuple(
                    fc.float({ min: -100, max: 100, noNaN: true }),
                    fc.float({ min: -100, max: 100, noNaN: true }),
                    fc.float({ min: -100, max: 100, noNaN: true })
                ),
                fc.float({ min: 0, max: 24000, noNaN: true }),
                (posTuple, time) => {
                    const worldPos = posTuple as [number, number, number];
                    
                    // Wave pattern should be smooth
                    expect(isWavePatternSmooth(worldPos, time, 2.0)).toBe(true);
                }
            ),
            { numRuns: 1000 }
        );
    });
    
    // ========================================================================
    // Property 6.7: Gradient Magnitude Bounded
    // ========================================================================
    
    it('Property 6.7: Wave gradient magnitude is bounded', () => {
        fc.assert(
            fc.property(
                fc.tuple(
                    fc.float({ min: -100, max: 100, noNaN: true }),
                    fc.float({ min: -100, max: 100, noNaN: true }),
                    fc.float({ min: -100, max: 100, noNaN: true })
                ),
                fc.float({ min: 0, max: 24000, noNaN: true }),
                (posTuple, time) => {
                    const worldPos = posTuple as [number, number, number];
                    const smoothness = calculateWaveSmoothness(worldPos, time);
                    
                    // Gradient should be bounded
                    expect(smoothness).toBeGreaterThanOrEqual(0.0);
                    expect(smoothness).toBeLessThan(2.0);
                }
            ),
            { numRuns: 1000 }
        );
    });
});

describe('Gerstner Waves - Temporal Properties', () => {
    
    // ========================================================================
    // Property 6.8: Wave Animation Over Time
    // ========================================================================
    
    it('Property 6.8: Waves animate smoothly over time', () => {
        const worldPos: [number, number, number] = [0, 0, 0];
        
        let prevDisp = calculateGerstnerDisplacement(worldPos, 0);
        
        for (let time = 1; time <= 100; time += 1) {
            const disp = calculateGerstnerDisplacement(worldPos, time);
            
            // Displacement should change smoothly
            const dispDiff = Math.abs(disp - prevDisp);
            expect(dispDiff).toBeLessThan(0.1);  // Max change per time unit
            
            prevDisp = disp;
        }
    });
    
    // ========================================================================
    // Property 6.9: Wave Periodicity
    // ========================================================================
    
    it('Property 6.9: Waves have periodic behavior', () => {
        const worldPos: [number, number, number] = [0, 0, 0];
        
        // Waves should repeat after sufficient time
        const disp0 = calculateGerstnerDisplacement(worldPos, 0);
        const disp2Pi = calculateGerstnerDisplacement(worldPos, 2 * Math.PI);
        
        // Should be similar (within numerical error)
        expect(Math.abs(disp0 - disp2Pi)).toBeLessThan(0.1);
    });
});

describe('Gerstner Waves - Caustic Patterns', () => {
    
    // ========================================================================
    // Property 6.10: Caustic Pattern Range
    // ========================================================================
    
    it('Property 6.10: Caustic patterns in [0.0, 1.0]', () => {
        fc.assert(
            fc.property(
                fc.tuple(
                    fc.float({ min: -1000, max: 1000, noNaN: true }),
                    fc.float({ min: -1000, max: 1000, noNaN: true })
                ),
                fc.float({ min: 0, max: 24000, noNaN: true }),
                (screenTuple, time) => {
                    const screenPos = screenTuple as [number, number];
                    const caustic = calculateCausticPattern(screenPos, time);
                    
                    expect(caustic).toBeGreaterThanOrEqual(0.0);
                    expect(caustic).toBeLessThanOrEqual(1.0);
                }
            ),
            { numRuns: 1000 }
        );
    });
    
    // ========================================================================
    // Property 6.11: Caustic Pattern Continuity
    // ========================================================================
    
    it('Property 6.11: Caustic patterns are continuous', () => {
        fc.assert(
            fc.property(
                fc.tuple(
                    fc.float({ min: -1000, max: 1000, noNaN: true }),
                    fc.float({ min: -1000, max: 1000, noNaN: true })
                ),
                fc.float({ min: 0, max: 24000, noNaN: true }),
                (screenTuple, time) => {
                    const screenPos = screenTuple as [number, number];
                    
                    const caustic1 = calculateCausticPattern(screenPos, time);
                    const caustic2 = calculateCausticPattern(
                        [screenPos[0] + 1, screenPos[1]],
                        time
                    );
                    
                    // Caustic should change smoothly
                    const causticDiff = Math.abs(caustic1 - caustic2);
                    expect(causticDiff).toBeLessThan(0.2);
                }
            ),
            { numRuns: 1000 }
        );
    });
});

describe('Gerstner Waves - Wave Configuration', () => {
    
    it('Wave Config 1: Wave frequencies are positive', () => {
        for (const freq of WAVE_FREQUENCIES) {
            expect(freq).toBeGreaterThan(0);
        }
    });
    
    it('Wave Config 2: Wave amplitudes are positive', () => {
        for (const amp of WAVE_AMPLITUDES) {
            expect(amp).toBeGreaterThan(0);
        }
    });
    
    it('Wave Config 3: Wave count matches array lengths', () => {
        expect(WAVE_FREQUENCIES.length).toBe(WAVE_COUNT);
        expect(WAVE_AMPLITUDES.length).toBe(WAVE_COUNT);
        expect(WAVE_PHASES.length).toBe(WAVE_COUNT);
    });
    
    it('Wave Config 4: Amplitudes decrease with frequency', () => {
        for (let i = 0; i < WAVE_COUNT - 1; i++) {
            expect(WAVE_AMPLITUDES[i]).toBeGreaterThanOrEqual(WAVE_AMPLITUDES[i + 1]);
        }
    });
});

describe('Gerstner Waves - Edge Cases', () => {
    
    it('Edge Case 1: Origin position', () => {
        const origin: [number, number, number] = [0, 0, 0];
        const normal = calculateGerstnerNormal(origin, 0);
        
        expect(isNormalValid(normal)).toBe(true);
    });
    
    it('Edge Case 2: Large position values', () => {
        const largePos: [number, number, number] = [1000, 0, 1000];
        const normal = calculateGerstnerNormal(largePos, 0);
        
        expect(isNormalValid(normal)).toBe(true);
    });
    
    it('Edge Case 3: Negative position values', () => {
        const negativePos: [number, number, number] = [-100, 0, -100];
        const normal = calculateGerstnerNormal(negativePos, 0);
        
        expect(isNormalValid(normal)).toBe(true);
    });
    
    it('Edge Case 4: Time zero', () => {
        const worldPos: [number, number, number] = [10, 0, 10];
        const displacement = calculateGerstnerDisplacement(worldPos, 0);
        
        expect(Number.isFinite(displacement)).toBe(true);
    });
    
    it('Edge Case 5: Large time values', () => {
        const worldPos: [number, number, number] = [10, 0, 10];
        const displacement = calculateGerstnerDisplacement(worldPos, 100000);
        
        expect(Number.isFinite(displacement)).toBe(true);
    });
});
