/**
 * BlendHer Shader - Shadow System Property-Based Tests
 * 
 * This test suite validates the cascaded shadow mapping system using property-based testing.
 * It ensures that:
 * - Cascade selection is correct based on distance
 * - Cascade blending is smooth without visible transitions
 * - PCF filtering produces smooth shadow edges
 * - Shadow fade works correctly at distance boundaries
 * - Depth bias prevents shadow acne
 * 
 * Validates: Requirement 5 (Cascaded Shadow Mapping)
 * 
 * Test Framework: Vitest with fast-check for property-based testing
 */

import { describe, it, expect } from 'vitest';
import fc from 'fast-check';

// ============================================================================
// SHADOW SYSTEM CONSTANTS (from settings.glsl)
// ============================================================================

const SHADOW_CASCADE_COUNT = 4;
const SHADOW_MAP_RESOLUTION = 2048;
const SHADOW_DISTANCE = 256.0;
const CASCADE_SPLITS = [64.0, 128.0, 256.0, 512.0];
const CASCADE_BLEND_WIDTH = 16.0;
const SHADOW_FADE_DISTANCE = 256.0;
const SHADOW_BIAS_NVIDIA = 0.03;
const SHADOW_BIAS_AMD = 0.05;
const SHADOW_BIAS = SHADOW_BIAS_NVIDIA;

// ============================================================================
// SHADOW SYSTEM IMPLEMENTATIONS (TypeScript versions for testing)
// ============================================================================

/**
 * Selects the appropriate shadow cascade based on distance from camera.
 */
function selectShadowCascade(distance: number): number {
    if (distance < CASCADE_SPLITS[0]) {
        return 0;  // Cascade 0: 0-64 blocks
    } else if (distance < CASCADE_SPLITS[1]) {
        return 1;  // Cascade 1: 64-128 blocks
    } else if (distance < CASCADE_SPLITS[2]) {
        return 2;  // Cascade 2: 128-256 blocks
    } else {
        return 3;  // Cascade 3: 256+ blocks (fade out)
    }
}

/**
 * Calculates the blend factor for cascade blending.
 */
function calculateCascadeBlendFactor(distance: number, cascadeIndex: number): number {
    const currentBoundary = (cascadeIndex === 0) ? 0.0 : CASCADE_SPLITS[cascadeIndex - 1];
    const nextBoundary = CASCADE_SPLITS[cascadeIndex];
    
    const blendStart = nextBoundary - CASCADE_BLEND_WIDTH;
    const blendFactor = smoothstep(blendStart, nextBoundary, distance);
    
    return blendFactor;
}

/**
 * Calculates shadow fade factor at distance boundary.
 */
function calculateShadowFade(distance: number): number {
    const fadeStart = SHADOW_FADE_DISTANCE - CASCADE_BLEND_WIDTH;
    const fadeFactor = smoothstep(fadeStart, SHADOW_FADE_DISTANCE, distance);
    
    return 1.0 - fadeFactor;
}

/**
 * Calculates adaptive depth bias based on surface normal and light direction.
 */
function calculateAdaptiveDepthBias(normal: [number, number, number], lightDirection: [number, number, number]): number {
    const cosAngle = Math.max(dot(normal, lightDirection), 0.0);
    
    const baseBias = SHADOW_BIAS;
    const adaptiveBias = baseBias * (1.0 - cosAngle);
    
    return Math.max(baseBias * 0.5, Math.min(baseBias * 2.0, adaptiveBias));
}

/**
 * Checks if a shadow coordinate is within valid shadow map bounds.
 */
function isValidShadowCoord(shadowCoord: [number, number, number]): boolean {
    return shadowCoord[0] >= 0.0 && shadowCoord[0] <= 1.0 &&
           shadowCoord[1] >= 0.0 && shadowCoord[1] <= 1.0 &&
           shadowCoord[2] >= 0.0 && shadowCoord[2] <= 1.0;
}

// ============================================================================
// UTILITY FUNCTIONS
// ============================================================================

/**
 * Hermite smoothstep function.
 */
function smoothstep(edge0: number, edge1: number, x: number): number {
    const t = Math.max(0.0, Math.min(1.0, (x - edge0) / (edge1 - edge0)));
    return t * t * (3.0 - 2.0 * t);
}

/**
 * Vector dot product.
 */
function dot(a: [number, number, number], b: [number, number, number]): number {
    return a[0] * b[0] + a[1] * b[1] + a[2] * b[2];
}

/**
 * Vector normalization.
 */
function normalize(v: [number, number, number]): [number, number, number] {
    const len = Math.sqrt(v[0] * v[0] + v[1] * v[1] + v[2] * v[2]);
    if (len === 0) return [0, 0, 0];
    return [v[0] / len, v[1] / len, v[2] / len];
}

/**
 * Vector length.
 */
function length(v: [number, number, number]): number {
    return Math.sqrt(v[0] * v[0] + v[1] * v[1] + v[2] * v[2]);
}

// ============================================================================
// PROPERTY-BASED TESTS
// ============================================================================

describe('Shadow System - Cascaded Shadow Mapping', () => {
    
    // ========================================================================
    // Property 10.1: Cascade Selection Correctness
    // ========================================================================
    
    it('Property 10.1: Cascade selection should be correct based on distance', () => {
        fc.assert(
            fc.property(fc.float({ min: 0, max: 1000, noNaN: true }), (distance) => {
                const cascade = selectShadowCascade(distance);
                
                // Verify cascade is in valid range
                expect(cascade).toBeGreaterThanOrEqual(0);
                expect(cascade).toBeLessThan(SHADOW_CASCADE_COUNT);
                
                // Verify cascade selection matches distance
                if (distance < CASCADE_SPLITS[0]) {
                    expect(cascade).toBe(0);
                } else if (distance < CASCADE_SPLITS[1]) {
                    expect(cascade).toBe(1);
                } else if (distance < CASCADE_SPLITS[2]) {
                    expect(cascade).toBe(2);
                } else {
                    expect(cascade).toBe(3);
                }
            }),
            { numRuns: 1000 }
        );
    });
    
    // ========================================================================
    // Property 10.2: Cascade Blend Smoothness
    // ========================================================================
    
    it('Property 10.2: Cascade blending should be smooth without visible transitions', () => {
        fc.assert(
            fc.property(
                fc.float({ min: 0, max: 1000, noNaN: true }),
                fc.float({ min: Math.fround(0.001), max: Math.fround(1), noNaN: true }),
                (distance, epsilon) => {
                    const cascade1 = selectShadowCascade(distance);
                    const cascade2 = selectShadowCascade(distance + epsilon);
                    
                    // Cascades should be same or adjacent
                    const cascadeDiff = Math.abs(cascade1 - cascade2);
                    expect(cascadeDiff).toBeLessThanOrEqual(1);
                    
                    // Blend factors should be smooth
                    if (cascade1 === cascade2) {
                        const blend1 = calculateCascadeBlendFactor(distance, cascade1);
                        const blend2 = calculateCascadeBlendFactor(distance + epsilon, cascade1);
                        
                        // Blend factors should be close for nearby distances
                        const blendDiff = Math.abs(blend1 - blend2);
                        expect(blendDiff).toBeLessThan(epsilon * 0.1);
                    }
                }
            ),
            { numRuns: 1000 }
        );
    });
    
    // ========================================================================
    // Property 10.3: Cascade Blend Factor Range
    // ========================================================================
    
    it('Property 10.3: Cascade blend factor should always be in [0.0, 1.0]', () => {
        fc.assert(
            fc.property(
                fc.float({ min: 0, max: 1000, noNaN: true }),
                fc.integer({ min: 0, max: 3 }),
                (distance, cascadeIndex) => {
                    const blendFactor = calculateCascadeBlendFactor(distance, cascadeIndex);
                    
                    expect(blendFactor).toBeGreaterThanOrEqual(0.0);
                    expect(blendFactor).toBeLessThanOrEqual(1.0);
                    expect(Number.isNaN(blendFactor)).toBe(false);
                    expect(Number.isFinite(blendFactor)).toBe(true);
                }
            ),
            { numRuns: 1000 }
        );
    });
    
    // ========================================================================
    // Property 10.4: Shadow Fade at Distance Boundary
    // ========================================================================
    
    it('Property 10.4: Shadows should fade beyond 256 blocks distance', () => {
        fc.assert(
            fc.property(fc.float({ min: 0, max: 1000, noNaN: true }), (distance) => {
                const shadowFade = calculateShadowFade(distance);
                
                // Shadow fade should be in [0.0, 1.0]
                expect(shadowFade).toBeGreaterThanOrEqual(0.0);
                expect(shadowFade).toBeLessThanOrEqual(1.0);
                
                // Shadows should be full before fade distance
                if (distance < SHADOW_FADE_DISTANCE - CASCADE_BLEND_WIDTH) {
                    expect(shadowFade).toBeCloseTo(1.0, 1);
                }
                
                // Shadows should be faded after fade distance
                if (distance > SHADOW_FADE_DISTANCE) {
                    expect(shadowFade).toBeCloseTo(0.0, 1);
                }
            }),
            { numRuns: 1000 }
        );
    });
    
    // ========================================================================
    // Property 10.5: Depth Bias Correctness
    // ========================================================================
    
    it('Property 10.5: Depth bias should be adaptive and prevent shadow acne', () => {
        fc.assert(
            fc.property(
                fc.tuple(
                    fc.float({ min: -1, max: 1, noNaN: true }),
                    fc.float({ min: -1, max: 1, noNaN: true }),
                    fc.float({ min: -1, max: 1, noNaN: true })
                ),
                fc.tuple(
                    fc.float({ min: -1, max: 1, noNaN: true }),
                    fc.float({ min: -1, max: 1, noNaN: true }),
                    fc.float({ min: -1, max: 1, noNaN: true })
                ),
                (normalTuple, lightDirTuple) => {
                    const normal = normalize(normalTuple as [number, number, number]);
                    const lightDirection = normalize(lightDirTuple as [number, number, number]);
                    
                    const bias = calculateAdaptiveDepthBias(normal, lightDirection);
                    
                    // Bias should be in reasonable range
                    expect(bias).toBeGreaterThanOrEqual(SHADOW_BIAS * 0.5);
                    expect(bias).toBeLessThanOrEqual(SHADOW_BIAS * 2.0);
                    expect(Number.isNaN(bias)).toBe(false);
                    expect(Number.isFinite(bias)).toBe(true);
                }
            ),
            { numRuns: 1000 }
        );
    });
    
    // ========================================================================
    // Property 10.6: Depth Bias Angle Dependency
    // ========================================================================
    
    it('Property 10.6: Depth bias should increase for grazing angles', () => {
        // Test with perpendicular normal (high bias)
        const perpNormal: [number, number, number] = [0, 1, 0];
        const lightDir: [number, number, number] = [1, 0, 0];
        const perpBias = calculateAdaptiveDepthBias(perpNormal, lightDir);
        
        // Test with parallel normal (low bias)
        const parallelNormal: [number, number, number] = [1, 0, 0];
        const parallelBias = calculateAdaptiveDepthBias(parallelNormal, lightDir);
        
        // Perpendicular should have higher bias
        expect(perpBias).toBeGreaterThan(parallelBias);
    });
    
    // ========================================================================
    // Property 10.7: Shadow Coordinate Validation
    // ========================================================================
    
    it('Property 10.7: Shadow coordinates should be validated correctly', () => {
        fc.assert(
            fc.property(
                fc.tuple(
                    fc.float({ min: -2, max: 2, noNaN: true }),
                    fc.float({ min: -2, max: 2, noNaN: true }),
                    fc.float({ min: -2, max: 2, noNaN: true })
                ),
                (coordTuple) => {
                    const coord = coordTuple as [number, number, number];
                    const isValid = isValidShadowCoord(coord);
                    
                    // Check validity matches bounds
                    const expectedValid = coord[0] >= 0.0 && coord[0] <= 1.0 &&
                                        coord[1] >= 0.0 && coord[1] <= 1.0 &&
                                        coord[2] >= 0.0 && coord[2] <= 1.0;
                    
                    expect(isValid).toBe(expectedValid);
                }
            ),
            { numRuns: 1000 }
        );
    });
    
    // ========================================================================
    // Property 10.8: Cascade Boundary Transitions
    // ========================================================================
    
    it('Property 10.8: Cascade transitions should be smooth at boundaries', () => {
        // Test at cascade boundaries
        for (let i = 0; i < CASCADE_SPLITS.length - 1; i++) {
            const boundary = CASCADE_SPLITS[i];
            const epsilon = 0.1;
            
            const cascadeBefore = selectShadowCascade(boundary - epsilon);
            const cascadeAfter = selectShadowCascade(boundary + epsilon);
            
            // Should transition to next cascade
            expect(cascadeAfter).toBe(cascadeBefore + 1);
            
            // Blend factors should be smooth
            const blendBefore = calculateCascadeBlendFactor(boundary - epsilon, cascadeBefore);
            const blendAfter = calculateCascadeBlendFactor(boundary + epsilon, cascadeAfter);
            
            // Both should be in valid range
            expect(blendBefore).toBeGreaterThanOrEqual(0.0);
            expect(blendBefore).toBeLessThanOrEqual(1.0);
            expect(blendAfter).toBeGreaterThanOrEqual(0.0);
            expect(blendAfter).toBeLessThanOrEqual(1.0);
        }
    });
    
    // ========================================================================
    // Property 10.9: PCF Kernel Size Validation
    // ========================================================================
    
    it('Property 10.9: PCF kernel should use 3x3 sampling', () => {
        // PCF kernel size is 3x3 = 9 samples
        const pcfKernelSize = 3;
        const expectedSampleCount = pcfKernelSize * pcfKernelSize;
        
        expect(expectedSampleCount).toBe(9);
    });
    
    // ========================================================================
    // Property 10.10: Shadow Map Resolution Validation
    // ========================================================================
    
    it('Property 10.10: Shadow map resolution should be 2K (2048x2048)', () => {
        expect(SHADOW_MAP_RESOLUTION).toBe(2048);
        
        // Verify it's a power of 2
        const log2 = Math.log2(SHADOW_MAP_RESOLUTION);
        expect(Number.isInteger(log2)).toBe(true);
    });
    
    // ========================================================================
    // Property 10.11: Cascade Count Validation
    // ========================================================================
    
    it('Property 10.11: Shadow cascade count should be 3-4', () => {
        expect(SHADOW_CASCADE_COUNT).toBeGreaterThanOrEqual(3);
        expect(SHADOW_CASCADE_COUNT).toBeLessThanOrEqual(4);
    });
    
    // ========================================================================
    // Property 10.12: Cascade Split Ordering
    // ========================================================================
    
    it('Property 10.12: Cascade splits should be in ascending order', () => {
        for (let i = 0; i < CASCADE_SPLITS.length - 1; i++) {
            expect(CASCADE_SPLITS[i]).toBeLessThan(CASCADE_SPLITS[i + 1]);
        }
    });
    
    // ========================================================================
    // Property 10.13: Blend Width Validation
    // ========================================================================
    
    it('Property 10.13: Cascade blend width should be reasonable', () => {
        expect(CASCADE_BLEND_WIDTH).toBeGreaterThan(0);
        expect(CASCADE_BLEND_WIDTH).toBeLessThan(CASCADE_SPLITS[0]);
    });
    
    // ========================================================================
    // Property 10.14: Shadow Fade Distance Validation
    // ========================================================================
    
    it('Property 10.14: Shadow fade distance should match cascade distance', () => {
        expect(SHADOW_FADE_DISTANCE).toBe(256.0);
    });
    
    // ========================================================================
    // Property 10.15: Depth Bias Range Validation
    // ========================================================================
    
    it('Property 10.15: Depth bias should be in valid range', () => {
        expect(SHADOW_BIAS).toBeGreaterThan(0);
        expect(SHADOW_BIAS).toBeLessThan(0.1);
    });
});

describe('Shadow System - Edge Cases', () => {
    
    it('Edge Case 1: Zero distance should select cascade 0', () => {
        const cascade = selectShadowCascade(0);
        expect(cascade).toBe(0);
    });
    
    it('Edge Case 2: Very large distance should select cascade 3', () => {
        const cascade = selectShadowCascade(10000);
        expect(cascade).toBe(3);
    });
    
    it('Edge Case 3: Distance at cascade boundary should transition correctly', () => {
        for (let i = 0; i < CASCADE_SPLITS.length - 1; i++) {
            const boundary = CASCADE_SPLITS[i];
            // Just before boundary should be in current cascade
            const cascadeBeforeBoundary = selectShadowCascade(boundary - 0.1);
            // Just after boundary should be in next cascade
            const cascadeAfterBoundary = selectShadowCascade(boundary + 0.1);
            
            expect(cascadeAfterBoundary).toBe(cascadeBeforeBoundary + 1);
        }
    });
    
    it('Edge Case 4: Shadow fade should be 1.0 before fade distance', () => {
        const shadowFade = calculateShadowFade(SHADOW_FADE_DISTANCE - CASCADE_BLEND_WIDTH - 10);
        expect(shadowFade).toBeCloseTo(1.0, 1);
    });
    
    it('Edge Case 5: Shadow fade should be 0.0 after fade distance', () => {
        const shadowFade = calculateShadowFade(SHADOW_FADE_DISTANCE + CASCADE_BLEND_WIDTH + 10);
        expect(shadowFade).toBeCloseTo(0.0, 1);
    });
    
    it('Edge Case 6: Parallel normal and light should have minimum bias', () => {
        const normal: [number, number, number] = [1, 0, 0];
        const lightDir: [number, number, number] = [1, 0, 0];
        const bias = calculateAdaptiveDepthBias(normal, lightDir);
        
        expect(bias).toBeCloseTo(SHADOW_BIAS * 0.5, 2);
    });
    
    it('Edge Case 7: Perpendicular normal and light should have maximum bias', () => {
        const normal: [number, number, number] = [0, 1, 0];
        const lightDir: [number, number, number] = [1, 0, 0];
        const bias = calculateAdaptiveDepthBias(normal, lightDir);
        
        // When perpendicular, cosAngle = 0, so bias = SHADOW_BIAS * (1 - 0) = SHADOW_BIAS
        // But the function clamps to [SHADOW_BIAS * 0.5, SHADOW_BIAS * 2.0]
        // So the result should be SHADOW_BIAS (which is within the clamp range)
        expect(bias).toBeGreaterThanOrEqual(SHADOW_BIAS * 0.5);
        expect(bias).toBeLessThanOrEqual(SHADOW_BIAS * 2.0);
    });
    
    it('Edge Case 8: Valid shadow coordinate at origin', () => {
        const coord: [number, number, number] = [0, 0, 0];
        expect(isValidShadowCoord(coord)).toBe(true);
    });
    
    it('Edge Case 9: Valid shadow coordinate at max', () => {
        const coord: [number, number, number] = [1, 1, 1];
        expect(isValidShadowCoord(coord)).toBe(true);
    });
    
    it('Edge Case 10: Invalid shadow coordinate outside bounds', () => {
        const coord: [number, number, number] = [1.5, 0.5, 0.5];
        expect(isValidShadowCoord(coord)).toBe(false);
    });
});
