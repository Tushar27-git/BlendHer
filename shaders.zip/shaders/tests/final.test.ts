/**
 * BlendHer Shader - Final Pass Property-Based Tests
 * 
 * This test suite validates the final.fsh shader using property-based testing.
 * It ensures that:
 * - Vignette effect darkens edges appropriately
 * - Vignette intensity scales correctly with blend factor
 * - Gamma correction produces valid output
 * - Final output is always in [0.0, 1.0]
 * - No NaN or Inf values in output
 * 
 * Validates: Requirement 18 (Composite Pass Pipeline)
 * 
 * Test Framework: Vitest with fast-check for property-based testing
 */

import { describe, it, expect } from 'vitest';
import fc from 'fast-check';

// ============================================================================
// FINAL PASS CONSTANTS
// ============================================================================

const PI = Math.PI;

// ============================================================================
// FINAL PASS IMPLEMENTATIONS (TypeScript versions for testing)
// ============================================================================

/**
 * Calculate vignette effect using radial distance from screen center
 * 
 * The vignette darkens the edges of the screen, creating a cinematic effect.
 * The intensity is based on the distance from the screen center.
 */
function calculateVignette(texCoord: [number, number], intensity: number): number {
    // Calculate distance from screen center
    // Screen center is at (0.5, 0.5)
    const centerDist: [number, number] = [texCoord[0] - 0.5, texCoord[1] - 0.5];
    
    // Calculate radial distance
    const radialDist = Math.sqrt(centerDist[0] * centerDist[0] + centerDist[1] * centerDist[1]) * 1.414;
    
    // Apply vignette curve using smoothstep
    // This creates a smooth falloff from center to edges
    const t = Math.max(0, Math.min(1, (1.0 - radialDist) / (1.0 - 0.0)));
    const vignette = t * t * (3.0 - 2.0 * t);
    
    // Apply intensity
    return 1.0 + (vignette - 1.0) * intensity;
}

/**
 * Apply vignette effect to color
 * 
 * Multiplies the color by the vignette factor to darken edges.
 */
function applyVignette(color: [number, number, number], texCoord: [number, number], vignetteIntensity: number): [number, number, number] {
    // Calculate vignette factor
    const vignette = calculateVignette(texCoord, vignetteIntensity);
    
    // Apply vignette by multiplying color
    return [
        color[0] * vignette,
        color[1] * vignette,
        color[2] * vignette,
    ];
}

/**
 * Apply gamma correction (inverse gamma 1/2.2)
 * 
 * Converts from linear color space to sRGB display space.
 * This ensures proper color reproduction on standard displays.
 */
function applyGammaCorrection(color: [number, number, number]): [number, number, number] {
    // Gamma correction: color^(1/2.2)
    // 1/2.2 ≈ 0.454545
    const invGamma = 1.0 / 2.2;
    
    // Apply gamma correction per channel
    return [
        Math.pow(Math.max(0, color[0]), invGamma),
        Math.pow(Math.max(0, color[1]), invGamma),
        Math.pow(Math.max(0, color[2]), invGamma),
    ];
}

/**
 * Final pass pipeline
 */
function finalPassPipeline(
    sceneColor: [number, number, number],
    texCoord: [number, number],
    blendFactor: number
): [number, number, number] {
    // Calculate vignette intensity based on blend factor
    // Requirement 18: "Scale vignette intensity based on blend factor: vignetteIntensity = mix(0.1, 0.3, blendFactor)"
    // At blend factor 1.0 (BSL): vignette intensity = 0.3 (more prominent)
    // At blend factor 0.0 (Spooklementary): vignette intensity = 0.1 (subtle)
    const vignetteIntensity = 0.1 + blendFactor * 0.2;  // mix(0.1, 0.3, blendFactor)
    
    // Apply vignette effect
    let vignetted = applyVignette(sceneColor, texCoord, vignetteIntensity);
    
    // Apply gamma correction (inverse gamma 1/2.2)
    let gammaCorrected = applyGammaCorrection(vignetted);
    
    // Clamp output to [0.0, 1.0]
    return [
        Math.max(0.0, Math.min(1.0, gammaCorrected[0])),
        Math.max(0.0, Math.min(1.0, gammaCorrected[1])),
        Math.max(0.0, Math.min(1.0, gammaCorrected[2])),
    ];
}

/**
 * Check if color contains NaN or Inf
 */
function isValidColor(color: [number, number, number]): boolean {
    return Number.isFinite(color[0]) &&
           Number.isFinite(color[1]) &&
           Number.isFinite(color[2]) &&
           !Number.isNaN(color[0]) &&
           !Number.isNaN(color[1]) &&
           !Number.isNaN(color[2]);
}

/**
 * Calculate distance from screen center
 */
function distanceFromCenter(texCoord: [number, number]): number {
    const dx = texCoord[0] - 0.5;
    const dy = texCoord[1] - 0.5;
    return Math.sqrt(dx * dx + dy * dy);
}

// ============================================================================
// PROPERTY-BASED TESTS
// ============================================================================

describe('Final Pass - Vignette Effect', () => {
    
    // ========================================================================
    // Property 9.1: Vignette Darkens Edges
    // ========================================================================
    
    it('Property 9.1: Vignette darkens edges more than center', () => {
        const color: [number, number, number] = [1.0, 1.0, 1.0];
        const blendFactor = 0.5;
        
        // Center of screen
        const centerCoord: [number, number] = [0.5, 0.5];
        const centerResult = finalPassPipeline(color, centerCoord, blendFactor);
        
        // Corner of screen
        const cornerCoord: [number, number] = [0.0, 0.0];
        const cornerResult = finalPassPipeline(color, cornerCoord, blendFactor);
        
        // Center should be brighter than corner
        const centerBrightness = (centerResult[0] + centerResult[1] + centerResult[2]) / 3;
        const cornerBrightness = (cornerResult[0] + cornerResult[1] + cornerResult[2]) / 3;
        
        expect(centerBrightness).toBeGreaterThan(cornerBrightness);
    });
    
    // ========================================================================
    // Property 9.2: Vignette Intensity Scales with Blend Factor
    // ========================================================================
    
    it('Property 9.2: Vignette intensity increases with blend factor', () => {
        const color: [number, number, number] = [1.0, 1.0, 1.0];
        const cornerCoord: [number, number] = [0.0, 0.0];
        
        // Low blend factor (Spooklementary)
        const lowBlendResult = finalPassPipeline(color, cornerCoord, 0.0);
        
        // High blend factor (BSL)
        const highBlendResult = finalPassPipeline(color, cornerCoord, 1.0);
        
        // Low blend should be brighter at edges (less vignette)
        const lowBrightness = (lowBlendResult[0] + lowBlendResult[1] + lowBlendResult[2]) / 3;
        const highBrightness = (highBlendResult[0] + highBlendResult[1] + highBlendResult[2]) / 3;
        
        expect(lowBrightness).toBeGreaterThan(highBrightness);
    });
    
    // ========================================================================
    // Property 9.3: Vignette at Center is Minimal
    // ========================================================================
    
    it('Property 9.3: Vignette at screen center is minimal', () => {
        const color: [number, number, number] = [1.0, 1.0, 1.0];
        const centerCoord: [number, number] = [0.5, 0.5];
        const blendFactor = 0.5;
        
        const result = finalPassPipeline(color, centerCoord, blendFactor);
        
        // Center should be close to original (after gamma correction)
        const expectedGamma = Math.pow(1.0, 1.0 / 2.2);
        
        expect(result[0]).toBeCloseTo(expectedGamma, 1);
        expect(result[1]).toBeCloseTo(expectedGamma, 1);
        expect(result[2]).toBeCloseTo(expectedGamma, 1);
    });
    
    // ========================================================================
    // Property 9.4: Vignette Monotonicity
    // ========================================================================
    
    it('Property 9.4: Vignette effect increases monotonically from center to edge', () => {
        const color: [number, number, number] = [1.0, 1.0, 1.0];
        const blendFactor = 0.5;
        
        // Sample points from center to corner
        const points: [number, number][] = [
            [0.5, 0.5],    // Center
            [0.4, 0.5],    // Slightly left
            [0.3, 0.5],    // More left
            [0.2, 0.5],    // Even more left
            [0.0, 0.5],    // Edge
        ];
        
        let previousBrightness = Infinity;
        
        for (const point of points) {
            const result = finalPassPipeline(color, point, blendFactor);
            const brightness = (result[0] + result[1] + result[2]) / 3;
            
            // Brightness should decrease as we move away from center
            expect(brightness).toBeLessThanOrEqual(previousBrightness + 0.01);  // Allow small tolerance
            previousBrightness = brightness;
        }
    });
});

describe('Final Pass - Gamma Correction', () => {
    
    // ========================================================================
    // Property 9.5: Gamma Correction Brightens Image
    // ========================================================================
    
    it('Property 9.5: Gamma correction brightens mid-tones', () => {
        // Mid-tone color (0.5 in linear space)
        const midtone: [number, number, number] = [0.5, 0.5, 0.5];
        
        // Apply gamma correction
        const corrected = applyGammaCorrection(midtone);
        
        // Gamma correction should brighten mid-tones
        // 0.5^(1/2.2) ≈ 0.735
        expect(corrected[0]).toBeGreaterThan(midtone[0]);
        expect(corrected[1]).toBeGreaterThan(midtone[1]);
        expect(corrected[2]).toBeGreaterThan(midtone[2]);
    });
    
    // ========================================================================
    // Property 9.6: Gamma Correction Preserves Black and White
    // ========================================================================
    
    it('Property 9.6: Gamma correction preserves black and white', () => {
        // Black
        const black: [number, number, number] = [0.0, 0.0, 0.0];
        const correctedBlack = applyGammaCorrection(black);
        
        expect(correctedBlack[0]).toBeCloseTo(0.0, 5);
        expect(correctedBlack[1]).toBeCloseTo(0.0, 5);
        expect(correctedBlack[2]).toBeCloseTo(0.0, 5);
        
        // White
        const white: [number, number, number] = [1.0, 1.0, 1.0];
        const correctedWhite = applyGammaCorrection(white);
        
        expect(correctedWhite[0]).toBeCloseTo(1.0, 5);
        expect(correctedWhite[1]).toBeCloseTo(1.0, 5);
        expect(correctedWhite[2]).toBeCloseTo(1.0, 5);
    });
    
    // ========================================================================
    // Property 9.7: Gamma Correction Monotonicity
    // ========================================================================
    
    it('Property 9.7: Gamma correction is monotonically increasing', () => {
        fc.assert(
            fc.property(
                fc.float({ min: 0, max: 1, noNaN: true }),
                fc.float({ min: 0, max: 1, noNaN: true }),
                (color1, color2) => {
                    if (color1 >= color2) return;  // Skip if not ordered
                    
                    const corrected1 = applyGammaCorrection([color1, color1, color1]);
                    const corrected2 = applyGammaCorrection([color2, color2, color2]);
                    
                    // Gamma correction should preserve ordering
                    expect(corrected1[0]).toBeLessThanOrEqual(corrected2[0]);
                }
            ),
            { numRuns: 1000 }
        );
    });
    
    // ========================================================================
    // Property 9.8: Gamma Correction Output Range
    // ========================================================================
    
    it('Property 9.8: Gamma correction produces valid output', () => {
        fc.assert(
            fc.property(
                fc.tuple(
                    fc.float({ min: 0, max: 1, noNaN: true }),
                    fc.float({ min: 0, max: 1, noNaN: true }),
                    fc.float({ min: 0, max: 1, noNaN: true })
                ),
                (colorTuple) => {
                    const color = colorTuple as [number, number, number];
                    const corrected = applyGammaCorrection(color);
                    
                    // Should be valid color
                    expect(isValidColor(corrected)).toBe(true);
                    
                    // Should be in [0, 1] range
                    expect(corrected[0]).toBeGreaterThanOrEqual(0.0);
                    expect(corrected[0]).toBeLessThanOrEqual(1.0);
                    expect(corrected[1]).toBeGreaterThanOrEqual(0.0);
                    expect(corrected[1]).toBeLessThanOrEqual(1.0);
                    expect(corrected[2]).toBeGreaterThanOrEqual(0.0);
                    expect(corrected[2]).toBeLessThanOrEqual(1.0);
                }
            ),
            { numRuns: 1000 }
        );
    });
});

describe('Final Pass - Output Range', () => {
    
    // ========================================================================
    // Property 9.9: Final Output Always in [0.0, 1.0]
    // ========================================================================
    
    it('Property 9.9: Final output color always in [0.0, 1.0]', () => {
        fc.assert(
            fc.property(
                fc.tuple(
                    fc.float({ min: 0, max: 1, noNaN: true }),
                    fc.float({ min: 0, max: 1, noNaN: true }),
                    fc.float({ min: 0, max: 1, noNaN: true })
                ),
                fc.tuple(
                    fc.float({ min: 0, max: 1, noNaN: true }),
                    fc.float({ min: 0, max: 1, noNaN: true })
                ),
                fc.float({ min: 0, max: 1, noNaN: true }),
                (colorTuple, coordTuple, blendFactor) => {
                    const color = colorTuple as [number, number, number];
                    const texCoord = coordTuple as [number, number];
                    
                    const result = finalPassPipeline(color, texCoord, blendFactor);
                    
                    // All channels should be in [0.0, 1.0]
                    expect(result[0]).toBeGreaterThanOrEqual(0.0);
                    expect(result[0]).toBeLessThanOrEqual(1.0);
                    expect(result[1]).toBeGreaterThanOrEqual(0.0);
                    expect(result[1]).toBeLessThanOrEqual(1.0);
                    expect(result[2]).toBeGreaterThanOrEqual(0.0);
                    expect(result[2]).toBeLessThanOrEqual(1.0);
                }
            ),
            { numRuns: 1000 }
        );
    });
    
    // ========================================================================
    // Property 9.10: No NaN or Inf Values
    // ========================================================================
    
    it('Property 9.10: No NaN or Inf values in output', () => {
        fc.assert(
            fc.property(
                fc.tuple(
                    fc.float({ min: 0, max: 1, noNaN: true }),
                    fc.float({ min: 0, max: 1, noNaN: true }),
                    fc.float({ min: 0, max: 1, noNaN: true })
                ),
                fc.tuple(
                    fc.float({ min: 0, max: 1, noNaN: true }),
                    fc.float({ min: 0, max: 1, noNaN: true })
                ),
                fc.float({ min: 0, max: 1, noNaN: true }),
                (colorTuple, coordTuple, blendFactor) => {
                    const color = colorTuple as [number, number, number];
                    const texCoord = coordTuple as [number, number];
                    
                    const result = finalPassPipeline(color, texCoord, blendFactor);
                    
                    // Should be valid color
                    expect(isValidColor(result)).toBe(true);
                }
            ),
            { numRuns: 1000 }
        );
    });
});

describe('Final Pass - Blend Factor Dependency', () => {
    
    // ========================================================================
    // Property 9.11: Vignette Intensity Scales Correctly
    // ========================================================================
    
    it('Property 9.11: Vignette intensity scales from 0.1 to 0.3 with blend factor', () => {
        const color: [number, number, number] = [1.0, 1.0, 1.0];
        const cornerCoord: [number, number] = [0.0, 0.0];
        
        // Test at blend factor 0.0 (intensity 0.1)
        const result0 = finalPassPipeline(color, cornerCoord, 0.0);
        const brightness0 = (result0[0] + result0[1] + result0[2]) / 3;
        
        // Test at blend factor 0.5 (intensity 0.2)
        const result05 = finalPassPipeline(color, cornerCoord, 0.5);
        const brightness05 = (result05[0] + result05[1] + result05[2]) / 3;
        
        // Test at blend factor 1.0 (intensity 0.3)
        const result1 = finalPassPipeline(color, cornerCoord, 1.0);
        const brightness1 = (result1[0] + result1[1] + result1[2]) / 3;
        
        // Brightness should decrease as blend factor increases (more vignette)
        expect(brightness0).toBeGreaterThan(brightness05);
        expect(brightness05).toBeGreaterThan(brightness1);
    });
    
    // ========================================================================
    // Property 9.12: Blend Factor in Valid Range
    // ========================================================================
    
    it('Property 9.12: Blend factor always in [0.0, 1.0]', () => {
        fc.assert(
            fc.property(
                fc.float({ min: 0, max: 1, noNaN: true }),
                (blendFactor) => {
                    // Blend factor should be in valid range
                    expect(blendFactor).toBeGreaterThanOrEqual(0.0);
                    expect(blendFactor).toBeLessThanOrEqual(1.0);
                }
            ),
            { numRuns: 100 }
        );
    });
});

describe('Final Pass - Edge Cases', () => {
    
    it('Edge Case 1: Black color at center', () => {
        const black: [number, number, number] = [0, 0, 0];
        const centerCoord: [number, number] = [0.5, 0.5];
        const result = finalPassPipeline(black, centerCoord, 0.5);
        
        expect(isValidColor(result)).toBe(true);
        expect(result[0]).toBeCloseTo(0.0, 5);
        expect(result[1]).toBeCloseTo(0.0, 5);
        expect(result[2]).toBeCloseTo(0.0, 5);
    });
    
    it('Edge Case 2: White color at center', () => {
        const white: [number, number, number] = [1, 1, 1];
        const centerCoord: [number, number] = [0.5, 0.5];
        const result = finalPassPipeline(white, centerCoord, 0.5);
        
        expect(isValidColor(result)).toBe(true);
        expect(result[0]).toBeCloseTo(1.0, 1);
        expect(result[1]).toBeCloseTo(1.0, 1);
        expect(result[2]).toBeCloseTo(1.0, 1);
    });
    
    it('Edge Case 3: Black color at corner', () => {
        const black: [number, number, number] = [0, 0, 0];
        const cornerCoord: [number, number] = [0.0, 0.0];
        const result = finalPassPipeline(black, cornerCoord, 0.5);
        
        expect(isValidColor(result)).toBe(true);
        expect(result[0]).toBeCloseTo(0.0, 5);
        expect(result[1]).toBeCloseTo(0.0, 5);
        expect(result[2]).toBeCloseTo(0.0, 5);
    });
    
    it('Edge Case 4: White color at corner', () => {
        const white: [number, number, number] = [1, 1, 1];
        const cornerCoord: [number, number] = [0.0, 0.0];
        const result = finalPassPipeline(white, cornerCoord, 0.5);
        
        expect(isValidColor(result)).toBe(true);
        // Should be darker due to vignette
        expect(result[0]).toBeLessThan(1.0);
        expect(result[1]).toBeLessThan(1.0);
        expect(result[2]).toBeLessThan(1.0);
    });
    
    it('Edge Case 5: Grayscale color', () => {
        const gray: [number, number, number] = [0.5, 0.5, 0.5];
        const centerCoord: [number, number] = [0.5, 0.5];
        const result = finalPassPipeline(gray, centerCoord, 0.5);
        
        expect(isValidColor(result)).toBe(true);
    });
    
    it('Edge Case 6: Blend factor 0.0 (Spooklementary)', () => {
        const color: [number, number, number] = [1.0, 1.0, 1.0];
        const centerCoord: [number, number] = [0.5, 0.5];
        const result = finalPassPipeline(color, centerCoord, 0.0);
        
        expect(isValidColor(result)).toBe(true);
    });
    
    it('Edge Case 7: Blend factor 1.0 (BSL)', () => {
        const color: [number, number, number] = [1.0, 1.0, 1.0];
        const centerCoord: [number, number] = [0.5, 0.5];
        const result = finalPassPipeline(color, centerCoord, 1.0);
        
        expect(isValidColor(result)).toBe(true);
    });
});

