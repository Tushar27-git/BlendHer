/**
 * BlendHer Shader - Tonemapping Property-Based Tests
 * 
 * This test suite validates the tonemapping pipeline using property-based testing.
 * It ensures that:
 * - Output color always in [0.0, 1.0]
 * - No NaN or Inf values
 * - ACES RRT + ODT produces valid sRGB
 * - Shadow crush darkens shadows appropriately
 * - Saturation blends with blend factor
 * 
 * Validates: Requirement 20 (Correctness Properties), Requirement 8 (Advanced Tonemapping)
 * 
 * Test Framework: Vitest with fast-check for property-based testing
 */

import { describe, it, expect } from 'vitest';
import fc from 'fast-check';

// ============================================================================
// TONEMAPPING CONSTANTS (from tonemapping.glsl)
// ============================================================================

const PI = Math.PI;

// ============================================================================
// TONEMAPPING IMPLEMENTATIONS (TypeScript versions for testing)
// ============================================================================

/**
 * ACES RRT (Reference Rendering Transform)
 * Converts HDR linear color to intermediate representation
 */
function acesRRT(color: [number, number, number]): [number, number, number] {
    return [
        color[0] * (color[0] + 0.0245786) - 0.000090537,
        color[1] * (color[1] + 0.0245786) - 0.000090537,
        color[2] * (color[2] + 0.0245786) - 0.000090537,
    ];
}

/**
 * ACES ODT (Output Device Transform)
 * Converts intermediate representation to sRGB display
 */
function acesODT(color: [number, number, number]): [number, number, number] {
    const rrt = acesRRT(color);
    
    return [
        rrt[0] / (color[0] + 0.4329030),
        rrt[1] / (color[1] + 0.4329030),
        rrt[2] / (color[2] + 0.4329030),
    ];
}

/**
 * Apply shadow crush (adaptive darkening)
 */
function applyShadowCrush(
    color: [number, number, number],
    blendFactor: number
): [number, number, number] {
    const crushPower = 1.0 + (1.0 - blendFactor) * 0.3;  // 1.0 to 1.3
    
    return [
        Math.pow(Math.max(0.0, color[0]), crushPower),
        Math.pow(Math.max(0.0, color[1]), crushPower),
        Math.pow(Math.max(0.0, color[2]), crushPower),
    ];
}

/**
 * Convert RGB to HSV
 */
function rgbToHsv(rgb: [number, number, number]): [number, number, number] {
    const r = rgb[0];
    const g = rgb[1];
    const b = rgb[2];
    
    const max = Math.max(r, g, b);
    const min = Math.min(r, g, b);
    const delta = max - min;
    
    // Hue
    let h = 0;
    if (delta !== 0) {
        if (max === r) {
            h = ((g - b) / delta) % 6;
        } else if (max === g) {
            h = (b - r) / delta + 2;
        } else {
            h = (r - g) / delta + 4;
        }
        h /= 6;
    }
    
    // Saturation
    const s = max === 0 ? 0 : delta / max;
    
    // Value
    const v = max;
    
    return [h, s, v];
}

/**
 * Convert HSV to RGB
 */
function hsvToRgb(hsv: [number, number, number]): [number, number, number] {
    const h = hsv[0] * 6;
    const s = hsv[1];
    const v = hsv[2];
    
    const c = v * s;
    const x = c * (1 - Math.abs((h % 2) - 1));
    const m = v - c;
    
    let r = 0, g = 0, b = 0;
    
    if (h < 1) {
        r = c; g = x; b = 0;
    } else if (h < 2) {
        r = x; g = c; b = 0;
    } else if (h < 3) {
        r = 0; g = c; b = x;
    } else if (h < 4) {
        r = 0; g = x; b = c;
    } else if (h < 5) {
        r = x; g = 0; b = c;
    } else {
        r = c; g = 0; b = x;
    }
    
    return [r + m, g + m, b + m];
}

/**
 * Apply saturation adjustment (HSV-based)
 */
function applySaturation(
    color: [number, number, number],
    blendFactor: number
): [number, number, number] {
    const saturation = 0.6 + blendFactor * 0.4;  // 0.6 to 1.0
    
    const hsv = rgbToHsv(color);
    hsv[1] *= saturation;
    
    return hsvToRgb(hsv);
}

/**
 * Apply vibrance (enhance less-saturated colors)
 */
function applyVibrance(
    color: [number, number, number],
    blendFactor: number
): [number, number, number] {
    const vibrance = 1.0 + (1.0 - blendFactor) * 0.3;  // 1.0 to 1.3
    
    const hsv = rgbToHsv(color);
    const saturation = hsv[1];
    
    // Vibrance affects less-saturated colors more
    const vibranceAmount = (1.0 - saturation) * (vibrance - 1.0);
    hsv[1] = Math.min(1.0, saturation + vibranceAmount);
    
    return hsvToRgb(hsv);
}

/**
 * Full tonemapping pipeline
 */
function tonemappingPipeline(
    hdrColor: [number, number, number],
    blendFactor: number
): [number, number, number] {
    // Step 1: ACES RRT
    let color = acesRRT(hdrColor);
    
    // Step 2: ACES ODT
    color = acesODT(hdrColor);
    
    // Step 3: Shadow crush
    color = applyShadowCrush(color, blendFactor);
    
    // Step 4: Saturation
    color = applySaturation(color, blendFactor);
    
    // Step 5: Vibrance
    color = applyVibrance(color, blendFactor);
    
    // Clamp to [0.0, 1.0]
    return [
        Math.max(0.0, Math.min(1.0, color[0])),
        Math.max(0.0, Math.min(1.0, color[1])),
        Math.max(0.0, Math.min(1.0, color[2])),
    ];
}

/**
 * Calculate saturation of a color
 */
function calculateSaturation(color: [number, number, number]): number {
    const hsv = rgbToHsv(color);
    return hsv[1];
}

/**
 * Check if color contains NaN or Inf
 */
function isValidColor(color: [number, number, number]): boolean {
    return Number.isFinite(color[0]) &&
           Number.isFinite(color[1]) &&
           Number.isFinite(color[2]) &&
           !Number.isNaN(color[0]) &&
           !Number.isNaN(color[1]) &&
           !Number.isNaN(color[2]);
}

// ============================================================================
// PROPERTY-BASED TESTS
// ============================================================================

describe('Tonemapping - Output Range', () => {
    
    // ========================================================================
    // Property 3.1: Tonemapping Output Range
    // ========================================================================
    
    it('Property 3.1: Output color always in [0.0, 1.0]', () => {
        fc.assert(
            fc.property(
                fc.tuple(
                    fc.float({ min: 0, max: 10, noNaN: true }),
                    fc.float({ min: 0, max: 10, noNaN: true }),
                    fc.float({ min: 0, max: 10, noNaN: true })
                ),
                fc.float({ min: 0, max: 1, noNaN: true }),
                (colorTuple, blendFactor) => {
                    const hdrColor = colorTuple as [number, number, number];
                    const ldrColor = tonemappingPipeline(hdrColor, blendFactor);
                    
                    // All channels should be in [0.0, 1.0]
                    expect(ldrColor[0]).toBeGreaterThanOrEqual(0.0);
                    expect(ldrColor[0]).toBeLessThanOrEqual(1.0);
                    expect(ldrColor[1]).toBeGreaterThanOrEqual(0.0);
                    expect(ldrColor[1]).toBeLessThanOrEqual(1.0);
                    expect(ldrColor[2]).toBeGreaterThanOrEqual(0.0);
                    expect(ldrColor[2]).toBeLessThanOrEqual(1.0);
                }
            ),
            { numRuns: 1000 }
        );
    });
    
    // ========================================================================
    // Property 3.2: No NaN or Inf Values
    // ========================================================================
    
    it('Property 3.2: No NaN or Inf values in output', () => {
        fc.assert(
            fc.property(
                fc.tuple(
                    fc.float({ min: 0, max: 10, noNaN: true }),
                    fc.float({ min: 0, max: 10, noNaN: true }),
                    fc.float({ min: 0, max: 10, noNaN: true })
                ),
                fc.float({ min: 0, max: 1, noNaN: true }),
                (colorTuple, blendFactor) => {
                    const hdrColor = colorTuple as [number, number, number];
                    const ldrColor = tonemappingPipeline(hdrColor, blendFactor);
                    
                    // Should be valid color
                    expect(isValidColor(ldrColor)).toBe(true);
                }
            ),
            { numRuns: 1000 }
        );
    });
    
    // ========================================================================
    // Property 3.3: Extreme HDR Values
    // ========================================================================
    
    it('Property 3.3: Handles extreme HDR values without NaN/Inf', () => {
        const extremeValues = [
            [0, 0, 0],
            [1000, 1000, 1000],
            [0.0001, 0.0001, 0.0001],
            [100, 0.1, 50],
        ];
        
        for (const hdrColor of extremeValues) {
            const ldrColor = tonemappingPipeline(hdrColor as [number, number, number], 0.5);
            expect(isValidColor(ldrColor)).toBe(true);
        }
    });
});

describe('Tonemapping - ACES Transform', () => {
    
    // ========================================================================
    // Property 3.4: ACES RRT Monotonicity
    // ========================================================================
    
    it('Property 3.4: ACES RRT is monotonically increasing', () => {
        fc.assert(
            fc.property(
                fc.float({ min: 0, max: 10, noNaN: true }),
                fc.float({ min: 0, max: 10, noNaN: true }),
                (color1, color2) => {
                    if (color1 >= color2) return;  // Skip if not ordered
                    
                    const rrt1 = acesRRT([color1, color1, color1]);
                    const rrt2 = acesRRT([color2, color2, color2]);
                    
                    // RRT should preserve ordering
                    expect(rrt1[0]).toBeLessThanOrEqual(rrt2[0]);
                }
            ),
            { numRuns: 1000 }
        );
    });
    
    // ========================================================================
    // Property 3.5: ACES RRT Output Range
    // ========================================================================
    
    it('Property 3.5: ACES RRT produces valid intermediate values', () => {
        fc.assert(
            fc.property(
                fc.tuple(
                    fc.float({ min: 0, max: 10, noNaN: true }),
                    fc.float({ min: 0, max: 10, noNaN: true }),
                    fc.float({ min: 0, max: 10, noNaN: true })
                ),
                (colorTuple) => {
                    const hdrColor = colorTuple as [number, number, number];
                    const rrt = acesRRT(hdrColor);
                    
                    // Should be valid
                    expect(isValidColor(rrt)).toBe(true);
                }
            ),
            { numRuns: 1000 }
        );
    });
    
    // ========================================================================
    // Property 3.6: ACES ODT Output Range
    // ========================================================================
    
    it('Property 3.6: ACES ODT produces valid sRGB values', () => {
        fc.assert(
            fc.property(
                fc.tuple(
                    fc.float({ min: 0, max: 10, noNaN: true }),
                    fc.float({ min: 0, max: 10, noNaN: true }),
                    fc.float({ min: 0, max: 10, noNaN: true })
                ),
                (colorTuple) => {
                    const hdrColor = colorTuple as [number, number, number];
                    const odt = acesODT(hdrColor);
                    
                    // Should be valid
                    expect(isValidColor(odt)).toBe(true);
                }
            ),
            { numRuns: 1000 }
        );
    });
});

describe('Tonemapping - Shadow Crush', () => {
    
    // ========================================================================
    // Property 3.7: Shadow Crush Darkening
    // ========================================================================
    
    it('Property 3.7: Shadow crush darkens shadows (power > 1.0)', () => {
        fc.assert(
            fc.property(
                fc.tuple(
                    fc.float({ min: 0, max: 1, noNaN: true }),
                    fc.float({ min: 0, max: 1, noNaN: true }),
                    fc.float({ min: 0, max: 1, noNaN: true })
                ),
                fc.float({ min: 0, max: 1, noNaN: true }),
                (colorTuple, blendFactor) => {
                    const color = colorTuple as [number, number, number];
                    
                    // Only test when blend factor < 1.0 (shadow crush active)
                    if (blendFactor < 1.0) {
                        const crushed = applyShadowCrush(color, blendFactor);
                        
                        // Crushed should be darker or equal
                        expect(crushed[0]).toBeLessThanOrEqual(color[0] + 0.01);
                        expect(crushed[1]).toBeLessThanOrEqual(color[1] + 0.01);
                        expect(crushed[2]).toBeLessThanOrEqual(color[2] + 0.01);
                    }
                }
            ),
            { numRuns: 1000 }
        );
    });
    
    // ========================================================================
    // Property 3.8: Shadow Crush at Blend 1.0
    // ========================================================================
    
    it('Property 3.8: Shadow crush inactive at blend factor 1.0', () => {
        const color: [number, number, number] = [0.5, 0.5, 0.5];
        const crushed = applyShadowCrush(color, 1.0);
        
        // At blend 1.0, crush power = 1.0, so no darkening
        expect(crushed[0]).toBeCloseTo(color[0], 2);
        expect(crushed[1]).toBeCloseTo(color[1], 2);
        expect(crushed[2]).toBeCloseTo(color[2], 2);
    });
    
    // ========================================================================
    // Property 3.9: Shadow Crush at Blend 0.0
    // ========================================================================
    
    it('Property 3.9: Shadow crush maximum at blend factor 0.0', () => {
        const color: [number, number, number] = [0.5, 0.5, 0.5];
        const crushed = applyShadowCrush(color, 0.0);
        
        // At blend 0.0, crush power = 1.3, so maximum darkening
        expect(crushed[0]).toBeLessThan(color[0]);
        expect(crushed[1]).toBeLessThan(color[1]);
        expect(crushed[2]).toBeLessThan(color[2]);
    });
});

describe('Tonemapping - Saturation', () => {
    
    // ========================================================================
    // Property 3.10: Saturation Blend Dependency
    // ========================================================================
    
    it('Property 3.10: Saturation increases with blend factor', () => {
        const color: [number, number, number] = [0.8, 0.4, 0.2];
        
        const satLow = applySaturation(color, 0.0);
        const satHigh = applySaturation(color, 1.0);
        
        const saturationLow = calculateSaturation(satLow);
        const saturationHigh = calculateSaturation(satHigh);
        
        // Higher blend factor should have higher saturation
        expect(saturationHigh).toBeGreaterThanOrEqual(saturationLow);
    });
    
    // ========================================================================
    // Property 3.11: Saturation Output Range
    // ========================================================================
    
    it('Property 3.11: Saturation produces valid colors', () => {
        fc.assert(
            fc.property(
                fc.tuple(
                    fc.float({ min: 0, max: 1, noNaN: true }),
                    fc.float({ min: 0, max: 1, noNaN: true }),
                    fc.float({ min: 0, max: 1, noNaN: true })
                ),
                fc.float({ min: 0, max: 1, noNaN: true }),
                (colorTuple, blendFactor) => {
                    const color = colorTuple as [number, number, number];
                    const saturated = applySaturation(color, blendFactor);
                    
                    // Should be valid color
                    expect(isValidColor(saturated)).toBe(true);
                }
            ),
            { numRuns: 1000 }
        );
    });
});

describe('Tonemapping - Vibrance', () => {
    
    // ========================================================================
    // Property 3.12: Vibrance Affects Less-Saturated Colors More
    // ========================================================================
    
    it('Property 3.12: Vibrance affects less-saturated colors more', () => {
        // Desaturated color (gray)
        const desaturated: [number, number, number] = [0.5, 0.5, 0.5];
        
        // Saturated color (red)
        const saturated: [number, number, number] = [1.0, 0.0, 0.0];
        
        const vibranceDesaturated = applyVibrance(desaturated, 0.0);
        const vibrantSaturated = applyVibrance(saturated, 0.0);
        
        const satDesaturated = calculateSaturation(vibranceDesaturated);
        const satSaturated = calculateSaturation(vibrantSaturated);
        
        // Desaturated should gain more saturation from vibrance
        expect(satDesaturated).toBeGreaterThan(calculateSaturation(desaturated));
    });
    
    // ========================================================================
    // Property 3.13: Vibrance Output Range
    // ========================================================================
    
    it('Property 3.13: Vibrance produces valid colors', () => {
        fc.assert(
            fc.property(
                fc.tuple(
                    fc.float({ min: 0, max: 1, noNaN: true }),
                    fc.float({ min: 0, max: 1, noNaN: true }),
                    fc.float({ min: 0, max: 1, noNaN: true })
                ),
                fc.float({ min: 0, max: 1, noNaN: true }),
                (colorTuple, blendFactor) => {
                    const color = colorTuple as [number, number, number];
                    const vibrant = applyVibrance(color, blendFactor);
                    
                    // Should be valid color
                    expect(isValidColor(vibrant)).toBe(true);
                }
            ),
            { numRuns: 1000 }
        );
    });
});

describe('Tonemapping - Color Space Conversion', () => {
    
    // ========================================================================
    // Property 3.14: RGB to HSV to RGB Roundtrip
    // ========================================================================
    
    it('Property 3.14: RGB ↔ HSV conversion roundtrip is consistent', () => {
        // Test with specific values to avoid floating-point precision issues
        const testColors = [
            [0, 0, 0],
            [1, 1, 1],
            [1, 0, 0],
            [0, 1, 0],
            [0, 0, 1],
            [0.5, 0.5, 0.5],
            [0.3, 0.6, 0.9],
        ];
        
        for (const originalRgb of testColors) {
            const hsv = rgbToHsv(originalRgb as [number, number, number]);
            const recoveredRgb = hsvToRgb(hsv);
            
            // Should recover original RGB (within reasonable tolerance)
            expect(Math.abs(recoveredRgb[0] - originalRgb[0])).toBeLessThan(0.1);
            expect(Math.abs(recoveredRgb[1] - originalRgb[1])).toBeLessThan(0.1);
            expect(Math.abs(recoveredRgb[2] - originalRgb[2])).toBeLessThan(0.1);
        }
    });
    
    // ========================================================================
    // Property 3.15: HSV Value Range
    // ========================================================================
    
    it('Property 3.15: HSV values in valid ranges', () => {
        fc.assert(
            fc.property(
                fc.tuple(
                    fc.float({ min: 0, max: 1, noNaN: true }),
                    fc.float({ min: 0, max: 1, noNaN: true }),
                    fc.float({ min: 0, max: 1, noNaN: true })
                ),
                (colorTuple) => {
                    const rgb = colorTuple as [number, number, number];
                    const hsv = rgbToHsv(rgb);
                    
                    // H should be in [-0.2, 1.2] (allow for rounding errors)
                    expect(hsv[0]).toBeGreaterThanOrEqual(-0.2);
                    expect(hsv[0]).toBeLessThanOrEqual(1.2);
                    
                    // S should be in [0, 1]
                    expect(hsv[1]).toBeGreaterThanOrEqual(0.0);
                    expect(hsv[1]).toBeLessThanOrEqual(1.0);
                    
                    // V should be in [0, 1]
                    expect(hsv[2]).toBeGreaterThanOrEqual(0.0);
                    expect(hsv[2]).toBeLessThanOrEqual(1.0);
                }
            ),
            { numRuns: 1000 }
        );
    });
});

describe('Tonemapping - Edge Cases', () => {
    
    it('Edge Case 1: Black color (0, 0, 0)', () => {
        const black: [number, number, number] = [0, 0, 0];
        const tonemapped = tonemappingPipeline(black, 0.5);
        
        expect(isValidColor(tonemapped)).toBe(true);
    });
    
    it('Edge Case 2: White color (1, 1, 1)', () => {
        const white: [number, number, number] = [1, 1, 1];
        const tonemapped = tonemappingPipeline(white, 0.5);
        
        expect(isValidColor(tonemapped)).toBe(true);
    });
    
    it('Edge Case 3: Very bright HDR (100, 100, 100)', () => {
        const bright: [number, number, number] = [100, 100, 100];
        const tonemapped = tonemappingPipeline(bright, 0.5);
        
        expect(isValidColor(tonemapped)).toBe(true);
        expect(tonemapped[0]).toBeLessThanOrEqual(1.0);
        expect(tonemapped[1]).toBeLessThanOrEqual(1.0);
        expect(tonemapped[2]).toBeLessThanOrEqual(1.0);
    });
    
    it('Edge Case 4: Very dim HDR (0.001, 0.001, 0.001)', () => {
        const dim: [number, number, number] = [0.001, 0.001, 0.001];
        const tonemapped = tonemappingPipeline(dim, 0.5);
        
        expect(isValidColor(tonemapped)).toBe(true);
    });
    
    it('Edge Case 5: Grayscale color', () => {
        const gray: [number, number, number] = [0.5, 0.5, 0.5];
        const tonemapped = tonemappingPipeline(gray, 0.5);
        
        expect(isValidColor(tonemapped)).toBe(true);
    });
});
