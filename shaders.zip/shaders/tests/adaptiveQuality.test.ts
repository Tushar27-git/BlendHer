/**
 * BlendHer Shader - Adaptive Quality Scaling Property-Based Tests
 * 
 * This test suite validates the adaptive quality scaling system using property-based testing.
 * It ensures that:
 * - Scene complexity detection works correctly
 * - Adaptive shadow quality adjusts appropriately
 * - Adaptive bloom quality adjusts appropriately
 * - Adaptive TAA quality adjusts appropriately
 * - Quality transitions are smooth without visual pops
 * - Performance targets are maintained
 * 
 * Validates: Requirement 12 (Adaptive Quality Scaling)
 * 
 * Test Framework: Vitest with fast-check for property-based testing
 */

import { describe, it, expect } from 'vitest';
import fc from 'fast-check';

// ============================================================================
// ADAPTIVE QUALITY SCALING CONSTANTS (from settings.glsl)
// ============================================================================

const COMPLEXITY_LOW = 0;
const COMPLEXITY_MEDIUM = 1;
const COMPLEXITY_HIGH = 2;

const COMPLEXITY_THRESHOLD_HIGH = 2.0;
const COMPLEXITY_THRESHOLD_MEDIUM = 1.0;
const COMPLEXITY_THRESHOLD_LOW = 0.5;

const SHADOW_CASCADE_COUNT = 4;
const SHADOW_CASCADE_COUNT_HIGH = 2;
const SHADOW_CASCADE_COUNT_LOW = 4;

const SHADOW_MAP_RESOLUTION = 2048;
const SHADOW_MAP_RESOLUTION_HIGH = 1024;
const SHADOW_MAP_RESOLUTION_LOW = 2048;

const PCF_KERNEL_SIZE = 3;

const BLOOM_RADIUS = 3;
const BLOOM_RADIUS_HIGH = 1;
const BLOOM_RADIUS_LOW = 3;

const BLOOM_SAMPLE_COUNT = 9;

const TAA_SAMPLE_COUNT = 16;
const TAA_SAMPLE_COUNT_HIGH = 8;
const TAA_SAMPLE_COUNT_LOW = 16;

const FRAME_TIME_60FPS = 16.67;
const FRAME_TIME_90FPS = 11.11;
const FRAME_TIME_100FPS = 10.0;

// ============================================================================
// ADAPTIVE QUALITY SCALING IMPLEMENTATIONS (TypeScript versions for testing)
// ============================================================================

/**
 * Estimate scene complexity from lightmap data
 */
function estimateLightingComplexity(blockLight: number, skyLight: number): number {
    const totalLight = blockLight + skyLight;
    
    if (blockLight > 0.6 && skyLight > 0.6) {
        return COMPLEXITY_HIGH;
    } else if (blockLight > 0.8) {
        return COMPLEXITY_HIGH;
    } else if (totalLight > 0.8) {
        return COMPLEXITY_MEDIUM;
    } else {
        return COMPLEXITY_LOW;
    }
}

/**
 * Estimate scene complexity from material properties
 */
function estimateMaterialComplexity(smoothness: number, emission: number, porosity: number): number {
    if (smoothness > 0.7) {
        return COMPLEXITY_HIGH;
    } else if (emission > 0.3) {
        return COMPLEXITY_HIGH;
    } else if (smoothness > 0.4 || porosity > 0.5) {
        return COMPLEXITY_MEDIUM;
    } else {
        return COMPLEXITY_LOW;
    }
}

/**
 * Estimate scene complexity from depth complexity
 */
function estimateGeometryComplexity(currentDepth: number, neighborDepth: number): number {
    const depthDiff = Math.abs(currentDepth - neighborDepth);
    
    if (depthDiff > 0.1) {
        return COMPLEXITY_HIGH;
    } else if (depthDiff > 0.05) {
        return COMPLEXITY_MEDIUM;
    } else {
        return COMPLEXITY_LOW;
    }
}

/**
 * Combine multiple complexity estimates
 */
function combineComplexityEstimates(
    lightingComplexity: number,
    materialComplexity: number,
    geometryComplexity: number
): number {
    if (lightingComplexity === COMPLEXITY_HIGH ||
        materialComplexity === COMPLEXITY_HIGH ||
        geometryComplexity === COMPLEXITY_HIGH) {
        return COMPLEXITY_HIGH;
    }
    
    if (lightingComplexity === COMPLEXITY_MEDIUM ||
        materialComplexity === COMPLEXITY_MEDIUM ||
        geometryComplexity === COMPLEXITY_MEDIUM) {
        return COMPLEXITY_MEDIUM;
    }
    
    return COMPLEXITY_LOW;
}

/**
 * Detect scene complexity
 */
function detectSceneComplexity(
    blockLight: number,
    skyLight: number,
    smoothness: number,
    emission: number,
    porosity: number,
    currentDepth: number,
    neighborDepth: number
): number {
    const lightingComplexity = estimateLightingComplexity(blockLight, skyLight);
    const materialComplexity = estimateMaterialComplexity(smoothness, emission, porosity);
    const geometryComplexity = estimateGeometryComplexity(currentDepth, neighborDepth);
    
    return combineComplexityEstimates(lightingComplexity, materialComplexity, geometryComplexity);
}

/**
 * Get adaptive shadow cascade count
 */
function getAdaptiveShadowCascadeCount(complexity: number): number {
    if (complexity === COMPLEXITY_HIGH) {
        return SHADOW_CASCADE_COUNT_HIGH;
    } else if (complexity === COMPLEXITY_MEDIUM) {
        return 3;
    } else {
        return SHADOW_CASCADE_COUNT_LOW;
    }
}

/**
 * Get adaptive shadow map resolution
 */
function getAdaptiveShadowMapResolution(complexity: number): number {
    if (complexity === COMPLEXITY_HIGH) {
        return SHADOW_MAP_RESOLUTION_HIGH;
    } else if (complexity === COMPLEXITY_MEDIUM) {
        return 1536;
    } else {
        return SHADOW_MAP_RESOLUTION_LOW;
    }
}

/**
 * Get adaptive PCF kernel size
 */
function getAdaptivePCFKernelSize(complexity: number): number {
    if (complexity === COMPLEXITY_HIGH) {
        return 1;
    } else if (complexity === COMPLEXITY_MEDIUM) {
        return 2;
    } else {
        return PCF_KERNEL_SIZE;
    }
}

/**
 * Get adaptive bloom radius
 */
function getAdaptiveBloomRadius(complexity: number): number {
    if (complexity === COMPLEXITY_HIGH) {
        return BLOOM_RADIUS_HIGH;
    } else if (complexity === COMPLEXITY_MEDIUM) {
        return 2;
    } else {
        return BLOOM_RADIUS_LOW;
    }
}

/**
 * Get adaptive bloom sample count
 */
function getAdaptiveBloomSampleCount(complexity: number): number {
    if (complexity === COMPLEXITY_HIGH) {
        return 5;
    } else if (complexity === COMPLEXITY_MEDIUM) {
        return 7;
    } else {
        return BLOOM_SAMPLE_COUNT;
    }
}

/**
 * Get adaptive TAA sample count
 */
function getAdaptiveTAASampleCount(complexity: number): number {
    if (complexity === COMPLEXITY_HIGH) {
        return TAA_SAMPLE_COUNT_HIGH;
    } else if (complexity === COMPLEXITY_MEDIUM) {
        return 12;
    } else {
        return TAA_SAMPLE_COUNT_LOW;
    }
}

/**
 * Get adaptive TAA blend weight
 */
function getAdaptiveTAABlendWeight(complexity: number): number {
    const sampleCount = getAdaptiveTAASampleCount(complexity);
    return 1.0 / sampleCount;
}

/**
 * Estimate fragment shader execution time
 */
function estimateFragmentShaderTime(complexity: number): number {
    if (complexity === COMPLEXITY_HIGH) {
        return COMPLEXITY_THRESHOLD_HIGH;
    } else if (complexity === COMPLEXITY_MEDIUM) {
        return COMPLEXITY_THRESHOLD_MEDIUM;
    } else {
        return COMPLEXITY_THRESHOLD_LOW;
    }
}

/**
 * Check if performance budget exceeded
 */
function isPerformanceBudgetExceeded(estimatedTime: number, targetFrameTime: number): boolean {
    const timeMs = estimatedTime / 1000.0;
    return timeMs > (targetFrameTime * 0.8);
}

/**
 * Smooth quality transition
 */
function smoothQualityTransition(
    currentQuality: number,
    targetQuality: number,
    deltaTime: number,
    transitionSpeed: number
): number {
    const blendFactor = 1.0 - Math.exp(-transitionSpeed * deltaTime);
    return currentQuality * (1.0 - blendFactor) + targetQuality * blendFactor;
}

// ============================================================================
// PROPERTY-BASED TESTS
// ============================================================================

describe('Adaptive Quality Scaling - Scene Complexity Detection', () => {
    
    // ========================================================================
    // Property 12.1: Lighting Complexity Detection
    // ========================================================================
    
    it('Property 12.1: Lighting complexity should be detected correctly', () => {
        fc.assert(
            fc.property(
                fc.float({ min: 0, max: 1, noNaN: true }),
                fc.float({ min: 0, max: 1, noNaN: true }),
                (blockLight, skyLight) => {
                    const complexity = estimateLightingComplexity(blockLight, skyLight);
                    
                    // Complexity should be valid
                    expect(complexity).toBeGreaterThanOrEqual(COMPLEXITY_LOW);
                    expect(complexity).toBeLessThanOrEqual(COMPLEXITY_HIGH);
                    
                    // High block light should indicate high complexity
                    if (blockLight > 0.8) {
                        expect(complexity).toBe(COMPLEXITY_HIGH);
                    }
                    
                    // Low light should indicate low complexity
                    if (blockLight < 0.3 && skyLight < 0.3) {
                        expect(complexity).toBe(COMPLEXITY_LOW);
                    }
                }
            ),
            { numRuns: 1000 }
        );
    });
    
    // ========================================================================
    // Property 12.2: Material Complexity Detection
    // ========================================================================
    
    it('Property 12.2: Material complexity should be detected correctly', () => {
        fc.assert(
            fc.property(
                fc.float({ min: 0, max: 1, noNaN: true }),
                fc.float({ min: 0, max: 1, noNaN: true }),
                fc.float({ min: 0, max: 1, noNaN: true }),
                (smoothness, emission, porosity) => {
                    const complexity = estimateMaterialComplexity(smoothness, emission, porosity);
                    
                    // Complexity should be valid
                    expect(complexity).toBeGreaterThanOrEqual(COMPLEXITY_LOW);
                    expect(complexity).toBeLessThanOrEqual(COMPLEXITY_HIGH);
                    
                    // High smoothness should indicate high complexity
                    if (smoothness > 0.7) {
                        expect(complexity).toBe(COMPLEXITY_HIGH);
                    }
                    
                    // High emission should indicate high complexity
                    if (emission > 0.3) {
                        expect(complexity).toBe(COMPLEXITY_HIGH);
                    }
                }
            ),
            { numRuns: 1000 }
        );
    });
    
    // ========================================================================
    // Property 12.3: Geometry Complexity Detection
    // ========================================================================
    
    it('Property 12.3: Geometry complexity should be detected correctly', () => {
        fc.assert(
            fc.property(
                fc.float({ min: 0, max: 1, noNaN: true }),
                fc.float({ min: 0, max: 1, noNaN: true }),
                (currentDepth, neighborDepth) => {
                    const complexity = estimateGeometryComplexity(currentDepth, neighborDepth);
                    
                    // Complexity should be valid
                    expect(complexity).toBeGreaterThanOrEqual(COMPLEXITY_LOW);
                    expect(complexity).toBeLessThanOrEqual(COMPLEXITY_HIGH);
                    
                    // Large depth discontinuities should indicate high complexity
                    if (Math.abs(currentDepth - neighborDepth) > 0.1) {
                        expect(complexity).toBe(COMPLEXITY_HIGH);
                    }
                    
                    // Small depth discontinuities should indicate low complexity
                    if (Math.abs(currentDepth - neighborDepth) < 0.02) {
                        expect(complexity).toBe(COMPLEXITY_LOW);
                    }
                }
            ),
            { numRuns: 1000 }
        );
    });
    
    // ========================================================================
    // Property 12.4: Combined Complexity Detection
    // ========================================================================
    
    it('Property 12.4: Combined complexity should be detected correctly', () => {
        fc.assert(
            fc.property(
                fc.float({ min: 0, max: 1, noNaN: true }),
                fc.float({ min: 0, max: 1, noNaN: true }),
                fc.float({ min: 0, max: 1, noNaN: true }),
                fc.float({ min: 0, max: 1, noNaN: true }),
                fc.float({ min: 0, max: 1, noNaN: true }),
                fc.float({ min: 0, max: 1, noNaN: true }),
                fc.float({ min: 0, max: 1, noNaN: true }),
                (blockLight, skyLight, smoothness, emission, porosity, currentDepth, neighborDepth) => {
                    const complexity = detectSceneComplexity(
                        blockLight, skyLight,
                        smoothness, emission, porosity,
                        currentDepth, neighborDepth
                    );
                    
                    // Complexity should be valid
                    expect(complexity).toBeGreaterThanOrEqual(COMPLEXITY_LOW);
                    expect(complexity).toBeLessThanOrEqual(COMPLEXITY_HIGH);
                    expect(Number.isNaN(complexity)).toBe(false);
                }
            ),
            { numRuns: 1000 }
        );
    });
});

describe('Adaptive Quality Scaling - Shadow Quality', () => {
    
    // ========================================================================
    // Property 12.5: Adaptive Shadow Cascade Count
    // ========================================================================
    
    it('Property 12.5: Shadow cascade count should adapt to complexity', () => {
        fc.assert(
            fc.property(fc.integer({ min: 0, max: 2 }), (complexity) => {
                const cascadeCount = getAdaptiveShadowCascadeCount(complexity);
                
                // Cascade count should be valid
                expect(cascadeCount).toBeGreaterThanOrEqual(2);
                expect(cascadeCount).toBeLessThanOrEqual(4);
                
                // High complexity should have fewer cascades
                if (complexity === COMPLEXITY_HIGH) {
                    expect(cascadeCount).toBe(SHADOW_CASCADE_COUNT_HIGH);
                    expect(cascadeCount).toBeLessThan(SHADOW_CASCADE_COUNT_LOW);
                }
                
                // Low complexity should have more cascades
                if (complexity === COMPLEXITY_LOW) {
                    expect(cascadeCount).toBe(SHADOW_CASCADE_COUNT_LOW);
                    expect(cascadeCount).toBeGreaterThanOrEqual(SHADOW_CASCADE_COUNT_HIGH);
                }
            }),
            { numRuns: 100 }
        );
    });
    
    // ========================================================================
    // Property 12.6: Adaptive Shadow Map Resolution
    // ========================================================================
    
    it('Property 12.6: Shadow map resolution should adapt to complexity', () => {
        fc.assert(
            fc.property(fc.integer({ min: 0, max: 2 }), (complexity) => {
                const resolution = getAdaptiveShadowMapResolution(complexity);
                
                // Resolution should be valid
                expect(resolution).toBeGreaterThanOrEqual(1024);
                expect(resolution).toBeLessThanOrEqual(2048);
                
                // High complexity should have lower resolution
                if (complexity === COMPLEXITY_HIGH) {
                    expect(resolution).toBe(SHADOW_MAP_RESOLUTION_HIGH);
                    expect(resolution).toBeLessThan(SHADOW_MAP_RESOLUTION_LOW);
                }
                
                // Low complexity should have higher resolution
                if (complexity === COMPLEXITY_LOW) {
                    expect(resolution).toBe(SHADOW_MAP_RESOLUTION_LOW);
                    expect(resolution).toBeGreaterThanOrEqual(SHADOW_MAP_RESOLUTION_HIGH);
                }
            }),
            { numRuns: 100 }
        );
    });
    
    // ========================================================================
    // Property 12.7: Adaptive PCF Kernel Size
    // ========================================================================
    
    it('Property 12.7: PCF kernel size should adapt to complexity', () => {
        fc.assert(
            fc.property(fc.integer({ min: 0, max: 2 }), (complexity) => {
                const kernelSize = getAdaptivePCFKernelSize(complexity);
                
                // Kernel size should be valid
                expect(kernelSize).toBeGreaterThanOrEqual(1);
                expect(kernelSize).toBeLessThanOrEqual(3);
                
                // High complexity should have smaller kernel
                if (complexity === COMPLEXITY_HIGH) {
                    expect(kernelSize).toBe(1);
                }
                
                // Low complexity should have larger kernel
                if (complexity === COMPLEXITY_LOW) {
                    expect(kernelSize).toBe(PCF_KERNEL_SIZE);
                }
            }),
            { numRuns: 100 }
        );
    });
});

describe('Adaptive Quality Scaling - Bloom Quality', () => {
    
    // ========================================================================
    // Property 12.8: Adaptive Bloom Radius
    // ========================================================================
    
    it('Property 12.8: Bloom radius should adapt to complexity', () => {
        fc.assert(
            fc.property(fc.integer({ min: 0, max: 2 }), (complexity) => {
                const radius = getAdaptiveBloomRadius(complexity);
                
                // Radius should be valid
                expect(radius).toBeGreaterThanOrEqual(1);
                expect(radius).toBeLessThanOrEqual(3);
                
                // High complexity should have smaller radius
                if (complexity === COMPLEXITY_HIGH) {
                    expect(radius).toBe(BLOOM_RADIUS_HIGH);
                    expect(radius).toBeLessThan(BLOOM_RADIUS_LOW);
                }
                
                // Low complexity should have larger radius
                if (complexity === COMPLEXITY_LOW) {
                    expect(radius).toBe(BLOOM_RADIUS_LOW);
                    expect(radius).toBeGreaterThanOrEqual(BLOOM_RADIUS_HIGH);
                }
            }),
            { numRuns: 100 }
        );
    });
    
    // ========================================================================
    // Property 12.9: Adaptive Bloom Sample Count
    // ========================================================================
    
    it('Property 12.9: Bloom sample count should adapt to complexity', () => {
        fc.assert(
            fc.property(fc.integer({ min: 0, max: 2 }), (complexity) => {
                const sampleCount = getAdaptiveBloomSampleCount(complexity);
                
                // Sample count should be valid
                expect(sampleCount).toBeGreaterThanOrEqual(5);
                expect(sampleCount).toBeLessThanOrEqual(9);
                
                // High complexity should have fewer samples
                if (complexity === COMPLEXITY_HIGH) {
                    expect(sampleCount).toBe(5);
                    expect(sampleCount).toBeLessThan(BLOOM_SAMPLE_COUNT);
                }
                
                // Low complexity should have more samples
                if (complexity === COMPLEXITY_LOW) {
                    expect(sampleCount).toBe(BLOOM_SAMPLE_COUNT);
                    expect(sampleCount).toBeGreaterThanOrEqual(5);
                }
            }),
            { numRuns: 100 }
        );
    });
});

describe('Adaptive Quality Scaling - TAA Quality', () => {
    
    // ========================================================================
    // Property 12.10: Adaptive TAA Sample Count
    // ========================================================================
    
    it('Property 12.10: TAA sample count should adapt to complexity', () => {
        fc.assert(
            fc.property(fc.integer({ min: 0, max: 2 }), (complexity) => {
                const sampleCount = getAdaptiveTAASampleCount(complexity);
                
                // Sample count should be valid
                expect(sampleCount).toBeGreaterThanOrEqual(8);
                expect(sampleCount).toBeLessThanOrEqual(16);
                
                // High complexity should have fewer samples
                if (complexity === COMPLEXITY_HIGH) {
                    expect(sampleCount).toBe(TAA_SAMPLE_COUNT_HIGH);
                    expect(sampleCount).toBeLessThan(TAA_SAMPLE_COUNT_LOW);
                }
                
                // Low complexity should have more samples
                if (complexity === COMPLEXITY_LOW) {
                    expect(sampleCount).toBe(TAA_SAMPLE_COUNT_LOW);
                    expect(sampleCount).toBeGreaterThanOrEqual(TAA_SAMPLE_COUNT_HIGH);
                }
            }),
            { numRuns: 100 }
        );
    });
    
    // ========================================================================
    // Property 12.11: Adaptive TAA Blend Weight
    // ========================================================================
    
    it('Property 12.11: TAA blend weight should be inverse of sample count', () => {
        fc.assert(
            fc.property(fc.integer({ min: 0, max: 2 }), (complexity) => {
                const blendWeight = getAdaptiveTAABlendWeight(complexity);
                const sampleCount = getAdaptiveTAASampleCount(complexity);
                
                // Blend weight should be 1/sampleCount
                expect(blendWeight).toBeCloseTo(1.0 / sampleCount, 5);
                
                // Blend weight should be in valid range
                expect(blendWeight).toBeGreaterThan(0);
                expect(blendWeight).toBeLessThanOrEqual(1.0);
            }),
            { numRuns: 100 }
        );
    });
});

describe('Adaptive Quality Scaling - Performance', () => {
    
    // ========================================================================
    // Property 12.12: Performance Budget Checking
    // ========================================================================
    
    it('Property 12.12: Performance budget should be checked correctly', () => {
        fc.assert(
            fc.property(
                fc.float({ min: 0, max: 5, noNaN: true }),
                fc.float({ min: 5, max: 20, noNaN: true }),
                (estimatedTime, targetFrameTime) => {
                    const budgetExceeded = isPerformanceBudgetExceeded(estimatedTime, targetFrameTime);
                    
                    // Budget exceeded should be boolean
                    expect(typeof budgetExceeded).toBe('boolean');
                    
                    // If estimated time is very high, budget should be exceeded
                    if (estimatedTime > targetFrameTime * 800) {
                        expect(budgetExceeded).toBe(true);
                    }
                    
                    // If estimated time is very low, budget should not be exceeded
                    if (estimatedTime < targetFrameTime * 100) {
                        expect(budgetExceeded).toBe(false);
                    }
                }
            ),
            { numRuns: 1000 }
        );
    });
    
    // ========================================================================
    // Property 12.13: Execution Time Estimation
    // ========================================================================
    
    it('Property 12.13: Execution time should be estimated based on complexity', () => {
        fc.assert(
            fc.property(fc.integer({ min: 0, max: 2 }), (complexity) => {
                const estimatedTime = estimateFragmentShaderTime(complexity);
                
                // Estimated time should be positive
                expect(estimatedTime).toBeGreaterThan(0);
                
                // High complexity should have higher estimated time
                if (complexity === COMPLEXITY_HIGH) {
                    expect(estimatedTime).toBe(COMPLEXITY_THRESHOLD_HIGH);
                    expect(estimatedTime).toBeGreaterThan(COMPLEXITY_THRESHOLD_LOW);
                }
                
                // Low complexity should have lower estimated time
                if (complexity === COMPLEXITY_LOW) {
                    expect(estimatedTime).toBe(COMPLEXITY_THRESHOLD_LOW);
                    expect(estimatedTime).toBeLessThan(COMPLEXITY_THRESHOLD_HIGH);
                }
            }),
            { numRuns: 100 }
        );
    });
});

describe('Adaptive Quality Scaling - Transitions', () => {
    
    // ========================================================================
    // Property 12.14: Smooth Quality Transitions
    // ========================================================================
    
    it('Property 12.14: Quality transitions should be smooth', () => {
        fc.assert(
            fc.property(
                fc.float({ min: 0, max: 10, noNaN: true }),
                fc.float({ min: 0, max: 10, noNaN: true }),
                fc.float({ min: Math.fround(0.001), max: Math.fround(0.1), noNaN: true }),
                fc.float({ min: Math.fround(0.1), max: Math.fround(2.0), noNaN: true }),
                (currentQuality, targetQuality, deltaTime, transitionSpeed) => {
                    const smoothedQuality = smoothQualityTransition(
                        currentQuality,
                        targetQuality,
                        deltaTime,
                        transitionSpeed
                    );
                    
                    // Smoothed quality should be between current and target
                    const minQuality = Math.min(currentQuality, targetQuality);
                    const maxQuality = Math.max(currentQuality, targetQuality);
                    
                    expect(smoothedQuality).toBeGreaterThanOrEqual(minQuality);
                    expect(smoothedQuality).toBeLessThanOrEqual(maxQuality);
                    expect(Number.isNaN(smoothedQuality)).toBe(false);
                    expect(Number.isFinite(smoothedQuality)).toBe(true);
                }
            ),
            { numRuns: 1000 }
        );
    });
    
    // ========================================================================
    // Property 12.15: Transition Convergence
    // ========================================================================
    
    it('Property 12.15: Quality transitions should converge to target', () => {
        const currentQuality = 5.0;
        const targetQuality = 10.0;
        const transitionSpeed = 1.0;
        
        let smoothedQuality = currentQuality;
        
        // Simulate multiple frames with longer transition
        for (let i = 0; i < 500; i++) {
            smoothedQuality = smoothQualityTransition(
                smoothedQuality,
                targetQuality,
                0.016,  // ~60 FPS
                transitionSpeed
            );
        }
        
        // Should converge close to target (within 0.1 of target)
        expect(Math.abs(smoothedQuality - targetQuality)).toBeLessThan(0.1);
    });
});

describe('Adaptive Quality Scaling - Edge Cases', () => {
    
    it('Edge Case 1: Zero complexity should be low', () => {
        const cascadeCount = getAdaptiveShadowCascadeCount(COMPLEXITY_LOW);
        expect(cascadeCount).toBe(SHADOW_CASCADE_COUNT_LOW);
    });
    
    it('Edge Case 2: Maximum complexity should reduce quality', () => {
        const cascadeCountHigh = getAdaptiveShadowCascadeCount(COMPLEXITY_HIGH);
        const cascadeCountLow = getAdaptiveShadowCascadeCount(COMPLEXITY_LOW);
        
        expect(cascadeCountHigh).toBeLessThan(cascadeCountLow);
    });
    
    it('Edge Case 3: All quality settings should reduce for high complexity', () => {
        const shadowCascadeHigh = getAdaptiveShadowCascadeCount(COMPLEXITY_HIGH);
        const shadowCascadeLow = getAdaptiveShadowCascadeCount(COMPLEXITY_LOW);
        
        const bloomRadiusHigh = getAdaptiveBloomRadius(COMPLEXITY_HIGH);
        const bloomRadiusLow = getAdaptiveBloomRadius(COMPLEXITY_LOW);
        
        const taaSampleHigh = getAdaptiveTAASampleCount(COMPLEXITY_HIGH);
        const taaSampleLow = getAdaptiveTAASampleCount(COMPLEXITY_LOW);
        
        expect(shadowCascadeHigh).toBeLessThan(shadowCascadeLow);
        expect(bloomRadiusHigh).toBeLessThan(bloomRadiusLow);
        expect(taaSampleHigh).toBeLessThan(taaSampleLow);
    });
    
    it('Edge Case 4: Very high lighting should indicate high complexity', () => {
        const complexity = estimateLightingComplexity(0.9, 0.9);
        expect(complexity).toBe(COMPLEXITY_HIGH);
    });
    
    it('Edge Case 5: Very low lighting should indicate low complexity', () => {
        const complexity = estimateLightingComplexity(0.1, 0.1);
        expect(complexity).toBe(COMPLEXITY_LOW);
    });
    
    it('Edge Case 6: High smoothness should indicate high complexity', () => {
        const complexity = estimateMaterialComplexity(0.9, 0.1, 0.1);
        expect(complexity).toBe(COMPLEXITY_HIGH);
    });
    
    it('Edge Case 7: High emission should indicate high complexity', () => {
        const complexity = estimateMaterialComplexity(0.1, 0.5, 0.1);
        expect(complexity).toBe(COMPLEXITY_HIGH);
    });
    
    it('Edge Case 8: Large depth discontinuity should indicate high complexity', () => {
        const complexity = estimateGeometryComplexity(0.1, 0.3);
        expect(complexity).toBe(COMPLEXITY_HIGH);
    });
    
    it('Edge Case 9: Small depth discontinuity should indicate low complexity', () => {
        const complexity = estimateGeometryComplexity(0.5, 0.51);
        expect(complexity).toBe(COMPLEXITY_LOW);
    });
    
    it('Edge Case 10: TAA blend weight should be valid for all complexities', () => {
        for (let complexity = COMPLEXITY_LOW; complexity <= COMPLEXITY_HIGH; complexity++) {
            const blendWeight = getAdaptiveTAABlendWeight(complexity);
            expect(blendWeight).toBeGreaterThan(0);
            expect(blendWeight).toBeLessThanOrEqual(1.0);
        }
    });
});

