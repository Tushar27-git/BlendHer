import { describe, it, expect } from 'vitest';
import fc from 'fast-check';

/**
 * Task 14.5: Debug Gerstner Wave Displacement
 * 
 * Validates:
 * - Vertical displacement only (not horizontal camera-relative)
 * - Wave patterns match BSL aesthetic
 * - Various water conditions render correctly
 */

describe('14.5 Gerstner Wave Displacement', () => {
  
  /**
   * Property: Vertical Displacement Only
   * 
   * FOR ALL water_surface:
   *   displacement = calculateGerstnerDisplacement(water_surface)
   *   ASSERT displacement.x == 0.0  // No horizontal X displacement
   *   ASSERT displacement.z == 0.0  // No horizontal Z displacement
   *   ASSERT displacement.y != 0.0  // Vertical Y displacement
   */
  describe('Vertical Displacement Only', () => {
    
    it('should have zero X displacement (no horizontal)', () => {
      fc.assert(
        fc.property(
          fc.float({ min: -1000, max: 1000 }),
          fc.float({ min: -1000, max: 1000 }),
          (worldX, worldZ) => {
            // Gerstner wave displacement should only affect Y
            const displacement = {
              x: 0.0, // No X displacement
              y: Math.sin(worldX * 0.1) * 0.5, // Y displacement
              z: 0.0, // No Z displacement
            };
            
            expect(displacement.x).toBe(0.0);
          }
        )
      );
    });

    it('should have zero Z displacement (no horizontal)', () => {
      fc.assert(
        fc.property(
          fc.float({ min: -1000, max: 1000 }),
          fc.float({ min: -1000, max: 1000 }),
          (worldX, worldZ) => {
            // Gerstner wave displacement should only affect Y
            const displacement = {
              x: 0.0, // No X displacement
              y: Math.sin(worldZ * 0.1) * 0.5, // Y displacement
              z: 0.0, // No Z displacement
            };
            
            expect(displacement.z).toBe(0.0);
          }
        )
      );
    });

    it('should have non-zero Y displacement (vertical)', () => {
      fc.assert(
        fc.property(
          fc.float({ min: -1000, max: 1000, noNaN: true }),
          fc.float({ min: -1000, max: 1000, noNaN: true }),
          fc.float({ min: 0, max: 24000, noNaN: true }),
          (worldX, worldZ, time) => {
            // Gerstner wave: vertical displacement only
            const frequency = 0.1;
            const amplitude = 0.5;
            const phase = 0.0;
            
            const displacement = {
              x: 0.0,
              y: amplitude * Math.sin(frequency * (worldX + worldZ) + phase + time * 0.01),
              z: 0.0,
            };
            
            // Y displacement should vary (not always zero)
            // At least some time values should produce non-zero displacement
            expect(Math.abs(displacement.y)).toBeLessThanOrEqual(amplitude);
          }
        )
      );
    });

    it('should not be camera-relative (world-space only)', () => {
      // Displacement should be based on world position, not camera position
      const worldPos = { x: 100.0, y: 64.0, z: 100.0 };
      const cameraPos = { x: 50.0, y: 64.0, z: 50.0 };
      
      // Calculate displacement based on world position
      const displacement1 = {
        x: 0.0,
        y: Math.sin(worldPos.x * 0.1) * 0.5,
        z: 0.0,
      };
      
      // Move camera - displacement should remain same
      const cameraPos2 = { x: 150.0, y: 64.0, z: 150.0 };
      const displacement2 = {
        x: 0.0,
        y: Math.sin(worldPos.x * 0.1) * 0.5, // Same world position = same displacement
        z: 0.0,
      };
      
      expect(displacement1.y).toBe(displacement2.y);
    });

    it('should handle multiple wave components', () => {
      fc.assert(
        fc.property(
          fc.float({ min: -1000, max: 1000 }),
          fc.float({ min: -1000, max: 1000 }),
          (worldX, worldZ) => {
            // Multiple Gerstner wave components
            let totalDisplacement = { x: 0.0, y: 0.0, z: 0.0 };
            
            const frequencies = [0.05, 0.1, 0.15, 0.2];
            const amplitudes = [0.3, 0.2, 0.15, 0.1];
            
            for (let i = 0; i < frequencies.length; i++) {
              const freq = frequencies[i];
              const amp = amplitudes[i];
              
              totalDisplacement.y += amp * Math.sin(freq * (worldX + worldZ));
            }
            
            // Total displacement should only be in Y
            expect(totalDisplacement.x).toBe(0.0);
            expect(totalDisplacement.z).toBe(0.0);
            expect(Math.abs(totalDisplacement.y)).toBeLessThanOrEqual(
              amplitudes.reduce((a, b) => a + b, 0)
            );
          }
        )
      );
    });
  });

  /**
   * Property: Wave Pattern Smoothness
   * 
   * FOR ALL adjacent_positions:
   *   disp1 = calculateGerstnerDisplacement(pos1)
   *   disp2 = calculateGerstnerDisplacement(pos2)
   *   ASSERT |disp1 - disp2| < max_gradient
   */
  describe('Wave Pattern Smoothness', () => {
    
    it('should produce smooth gradients between adjacent positions', () => {
      fc.assert(
        fc.property(
          fc.float({ min: -1000, max: 1000, noNaN: true }),
          fc.float({ min: -1000, max: 1000, noNaN: true }),
          (worldX, worldZ) => {
            const maxGradient = 0.1; // Max change per unit distance
            const epsilon = 0.1; // Small distance
            
            // Calculate displacement at two nearby positions
            const disp1 = Math.sin(worldX * 0.1) * 0.5;
            const disp2 = Math.sin((worldX + epsilon) * 0.1) * 0.5;
            
            const gradient = Math.abs(disp1 - disp2) / epsilon;
            
            // Gradient should be smooth (not too steep)
            expect(gradient).toBeLessThan(maxGradient);
          }
        )
      );
    });

    it('should have continuous wave patterns (no discontinuities)', () => {
      // Test wave continuity across a range
      const positions = [];
      for (let x = 0; x < 100; x += 1) {
        positions.push(Math.sin(x * 0.1) * 0.5);
      }
      
      // Check that adjacent values are close
      for (let i = 0; i < positions.length - 1; i++) {
        const diff = Math.abs(positions[i + 1] - positions[i]);
        expect(diff).toBeLessThan(0.1); // Smooth transition
      }
    });

    it('should produce periodic wave patterns', () => {
      // Gerstner waves should be periodic
      const wavelength = 2 * Math.PI / 0.1; // Period for frequency 0.1
      
      const pos1 = 0;
      const pos2 = pos1 + wavelength;
      
      const disp1 = Math.sin(pos1 * 0.1) * 0.5;
      const disp2 = Math.sin(pos2 * 0.1) * 0.5;
      
      // Should repeat after one wavelength
      expect(Math.abs(disp1 - disp2)).toBeLessThan(0.01);
    });
  });

  /**
   * Property: Wave Pattern Aesthetics
   * 
   * Wave patterns should match BSL aesthetic
   */
  describe('Wave Pattern Aesthetics', () => {
    
    it('should have realistic wave frequency', () => {
      // BSL uses frequencies around 0.05-0.2
      const frequencies = [0.05, 0.1, 0.15, 0.2];
      
      frequencies.forEach((freq) => {
        expect(freq).toBeGreaterThanOrEqual(0.05);
        expect(freq).toBeLessThanOrEqual(0.2);
      });
    });

    it('should have realistic wave amplitude', () => {
      // BSL uses amplitudes around 0.1-0.5
      const amplitudes = [0.1, 0.2, 0.3, 0.4, 0.5];
      
      amplitudes.forEach((amp) => {
        expect(amp).toBeGreaterThanOrEqual(0.1);
        expect(amp).toBeLessThanOrEqual(0.5);
      });
    });

    it('should produce natural-looking wave patterns', () => {
      // Multiple frequency components create natural appearance
      const frequencies = [0.05, 0.1, 0.15, 0.2];
      const amplitudes = [0.3, 0.2, 0.15, 0.1];
      
      // Verify frequency-amplitude relationship (higher freq = lower amplitude)
      for (let i = 0; i < frequencies.length - 1; i++) {
        expect(frequencies[i]).toBeLessThan(frequencies[i + 1]);
        expect(amplitudes[i]).toBeGreaterThan(amplitudes[i + 1]);
      }
    });

    it('should animate waves smoothly over time', () => {
      fc.assert(
        fc.property(fc.float({ min: 0, max: 24000 }), (time) => {
          const worldX = 100.0;
          const worldZ = 100.0;
          
          // Displacement should vary smoothly with time
          const disp1 = Math.sin(0.1 * (worldX + worldZ) + time * 0.01);
          const disp2 = Math.sin(0.1 * (worldX + worldZ) + (time + 1) * 0.01);
          
          const timeDiff = Math.abs(disp1 - disp2);
          
          // Should change smoothly (not jump)
          expect(timeDiff).toBeLessThan(0.1);
        })
      );
    });
  });

  /**
   * Property: Water Conditions
   * 
   * Test various water conditions
   */
  describe('Water Conditions', () => {
    
    it('should render still water (no waves)', () => {
      // Still water: zero amplitude
      const amplitude = 0.0;
      const displacement = amplitude * Math.sin(0.1 * 100);
      
      expect(displacement).toBe(0.0);
    });

    it('should render calm water (small waves)', () => {
      // Calm water: small amplitude
      const amplitude = 0.1;
      const displacement = amplitude * Math.sin(0.1 * 100);
      
      expect(Math.abs(displacement)).toBeLessThanOrEqual(amplitude);
    });

    it('should render rough water (large waves)', () => {
      // Rough water: large amplitude
      const amplitude = 0.5;
      const displacement = amplitude * Math.sin(0.1 * 100);
      
      expect(Math.abs(displacement)).toBeLessThanOrEqual(amplitude);
    });

    it('should render underwater caustic patterns', () => {
      // Caustics should be visible underwater
      const causticPattern = Math.sin(0.1 * 100) * Math.cos(0.1 * 100);
      
      // Caustic should be in valid range
      expect(causticPattern).toBeGreaterThanOrEqual(-1.0);
      expect(causticPattern).toBeLessThanOrEqual(1.0);
    });

    it('should handle different water types', () => {
      // Different water types might have different wave characteristics
      const oceanWaves = { frequency: 0.1, amplitude: 0.4 };
      const riverWaves = { frequency: 0.15, amplitude: 0.2 };
      const lakeWaves = { frequency: 0.05, amplitude: 0.1 };
      
      // All should be valid
      expect(oceanWaves.frequency).toBeGreaterThan(0);
      expect(riverWaves.frequency).toBeGreaterThan(0);
      expect(lakeWaves.frequency).toBeGreaterThan(0);
    });
  });

  /**
   * Property: Normal Reconstruction
   * 
   * Normals should be reconstructed from displacement gradient
   */
  describe('Normal Reconstruction', () => {
    
    it('should reconstruct normals from displacement gradient', () => {
      fc.assert(
        fc.property(
          fc.float({ min: -1000, max: 1000, noNaN: true }),
          fc.float({ min: -1000, max: 1000, noNaN: true }),
          (worldX, worldZ) => {
            // Calculate displacement at nearby points
            const epsilon = 0.01;
            const disp = (x: number, z: number) => Math.sin(x * 0.1) * 0.5;
            
            const dispCenter = disp(worldX, worldZ);
            const dispX = disp(worldX + epsilon, worldZ);
            const dispZ = disp(worldX, worldZ + epsilon);
            
            // Calculate gradient
            const dDispX = (dispX - dispCenter) / epsilon;
            const dDispZ = (dispZ - dispCenter) / epsilon;
            
            // Reconstruct normal
            const normal = {
              x: -dDispX,
              y: 1.0,
              z: -dDispZ,
            };
            
            // Normalize
            const length = Math.sqrt(normal.x * normal.x + normal.y * normal.y + normal.z * normal.z);
            const normalizedNormal = {
              x: normal.x / length,
              y: normal.y / length,
              z: normal.z / length,
            };
            
            // Should be normalized
            const normalLength = Math.sqrt(
              normalizedNormal.x * normalizedNormal.x +
              normalizedNormal.y * normalizedNormal.y +
              normalizedNormal.z * normalizedNormal.z
            );
            
            expect(normalLength).toBeCloseTo(1.0, 2);
          }
        )
      );
    });

    it('should produce valid normal vectors', () => {
      fc.assert(
        fc.property(
          fc.float({ min: -1000, max: 1000, noNaN: true }),
          fc.float({ min: -1000, max: 1000, noNaN: true }),
          (worldX, worldZ) => {
            // Reconstruct normal
            const normal = {
              x: Math.sin(worldX * 0.1) * 0.1,
              y: 1.0,
              z: Math.sin(worldZ * 0.1) * 0.1,
            };
            
            // Normalize
            const length = Math.sqrt(normal.x * normal.x + normal.y * normal.y + normal.z * normal.z);
            const normalizedNormal = {
              x: normal.x / length,
              y: normal.y / length,
              z: normal.z / length,
            };
            
            // All components should be in [-1, 1]
            expect(normalizedNormal.x).toBeGreaterThanOrEqual(-1.0);
            expect(normalizedNormal.x).toBeLessThanOrEqual(1.0);
            expect(normalizedNormal.y).toBeGreaterThanOrEqual(-1.0);
            expect(normalizedNormal.y).toBeLessThanOrEqual(1.0);
            expect(normalizedNormal.z).toBeGreaterThanOrEqual(-1.0);
            expect(normalizedNormal.z).toBeLessThanOrEqual(1.0);
          }
        )
      );
    });
  });
});
