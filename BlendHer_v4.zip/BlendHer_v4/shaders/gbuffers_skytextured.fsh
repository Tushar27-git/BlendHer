#version 150 compatibility
#extension GL_ARB_explicit_attrib_location : enable
// BLENDHER v3 -- gbuffers_skytextured.fsh -- Sun/moon disc textures

#include "/include/settings.glsl"
#include "/include/utils.glsl"

uniform sampler2D gtexture;

in vec2 texcoord;
in vec4 color;

/* DRAWBUFFERS:0 */
layout(location = 0) out vec4 fragColor;

void main() {
    vec4 albedo = texture2D(gtexture, texcoord) * color;
    if (albedo.a < 0.05) discard;
    albedo.rgb = toLinear(albedo.rgb);
    fragColor  = albedo;
}
