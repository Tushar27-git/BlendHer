#version 150 compatibility
#extension GL_ARB_explicit_attrib_location : enable
// ============================================================
// BLENDHER v4 -- gbuffers_skybasic.fsh
// THE SKY FIX: renders every sky pixel including void/horizon.
// The white/cyan patch was caused by:
//   1. Invalid GLSL in the vsh (sunVec construction)
//   2. Sky function returning vec3(0) for downward-facing pixels (void)
// Both are now fixed.
// ============================================================

#include "/include/settings.glsl"
#include "/include/uniforms.glsl"
#include "/include/utils.glsl"
#include "/include/lighting.glsl"
#include "/include/atmosphere.glsl"

in vec3  viewPos;
in vec3  sunVec;
in vec3  upVec;
in float alpha;

/* DRAWBUFFERS:0 */
layout(location = 0) out vec4 fragColor;

void main() {
    vec3 nViewPos = normalize(viewPos);
    vec3 nSunVec  = normalize(sunVec);
    vec3 nUpVec   = normalize(upVec);

    // BlendHer sky: handles ALL directions (up, horizon, AND below-horizon/void)
    vec3 sky = getBlendHerSkyColor(nViewPos, nSunVec, nUpVec);

    // Stars at night (only above horizon)
    float sunVis = clamp(dot(nSunVec, nUpVec) * 10.0 + 0.5, 0.0, 1.0);
    if (sunVis < 0.3 && nViewPos.y > 0.0) {
        vec3  cellPos  = floor(nViewPos * 200.0);
        float starHash = fract(sin(dot(cellPos, vec3(127.1, 311.7, 74.3))) * 43758.5453);
        float starH2   = fract(sin(dot(cellPos, vec3(269.5, 183.3, 246.1))) * 43758.5453);
        float star     = step(0.987, starHash) * starH2;
        float starFade = smoothstep(0.3, 0.0, sunVis);
        sky += vec3(star * 0.9, star * 0.95, star) * starFade;
    }

    // alpha < 1 = void/horizon geometry -- still color it sky, never let it be raw clear color
    fragColor = vec4(sky, 1.0);
}
