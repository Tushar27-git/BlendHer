// ============================================================
// BLENDHER v4 -- lighting.glsl
// BSL time-of-day light colors + Spooklementary horror mode
// IMPROVED: richer shadows, better torch falloff, AO darkening
// ============================================================

// ── TIME-OF-DAY FADES ─────────────────────────────────────────
float getMEFade() {
    // 1.0 at sunrise/sunset, 0.0 at noon and midnight
    return 1.0 - clamp(abs(timeAngle - 0.5) * 8.0 - 1.5, 0.0, 1.0);
}
float getDFade() {
    // 1.0 at noon, 0.0 at night
    return 1.0 - pow(max(1.0 - timeBrightness, 0.0), 1.5);
}

// ── SUN VISIBILITY ────────────────────────────────────────────
float getSunVisibility(vec3 sunViewVec) {
    vec3 upVec = normalize(gbufferModelView[1].xyz);
    return clamp(dot(normalize(sunViewVec), upVec) * 10.0 + 0.5, 0.0, 1.0);
}

// ── BSL LIGHT COLOR (direct sun / moon) ───────────────────────
vec3 getLightColor(float mefade, float dfade, float sunVis) {
    // Morning/Evening: warm amber-orange
    vec3 morning = vec3(LIGHT_MR, LIGHT_MG, LIGHT_MB) * (LIGHT_MI / 255.0);
    // Day: slightly cool yellow-white (BSL signature)
    vec3 day     = vec3(LIGHT_DR, LIGHT_DG, LIGHT_DB) * (LIGHT_DI / 255.0);
    // Night: dim steel blue
    vec3 night   = vec3(LIGHT_NR, LIGHT_NG, LIGHT_NB) * (LIGHT_NI / 255.0);

    // Lerp morning->day->evening arc
    vec3 sunColor = mix(morning, day, dfade);
    // Sunrise/set: blend to warm orange
    sunColor      = mix(sunColor, morning * vec3(1.2, 0.9, 0.7), mefade * 0.6);
    vec3 lightCol = mix(night, sunColor, sunVis);

    // Physically-linear response (squared in gamma space)
    return lightCol * lightCol;
}

// ── SKY AMBIENT (bounce from sky hemisphere) ───────────────────
vec3 getAmbientColor(float mefade, float dfade, float sunVis) {
    vec3 morning = vec3(AMBIENT_MR, AMBIENT_MG, AMBIENT_MB) * (AMBIENT_MI / 255.0);
    vec3 day     = vec3(AMBIENT_DR, AMBIENT_DG, AMBIENT_DB) * (AMBIENT_DI / 255.0);
    vec3 night   = vec3(AMBIENT_NR, AMBIENT_NG, AMBIENT_NB) * (AMBIENT_NI / 255.0);

    // At dusk/sunset, pull ambient toward purple (Spook injection)
    vec3 spookDusk = vec3(0.22, 0.16, 0.38);
    vec3 dayFinal  = mix(day, spookDusk, mefade * 0.35 * (1.0 - dfade));

    vec3 sunAmbient = mix(morning, dayFinal, dfade);
    vec3 ambCol     = mix(night, sunAmbient, sunVis);
    return ambCol * ambCol;
}

// ── TORCH / BLOCKLIGHT ────────────────────────────────────────
vec3 getBlockLightColor(float blockLight) {
    // BSL warm amber-orange
    vec3 blColor = vec3(BLOCKLIGHT_R, BLOCKLIGHT_G, BLOCKLIGHT_B)
                   * (BLOCKLIGHT_I / 255.0);
    blColor = blColor * blColor; // linear

    // BSL power curve: bright close, falls off very fast
    // This makes torch a tight circle of warmth in horror darkness
    float bl = pow(blockLight, 8.0) * 1.8 + blockLight * 0.4;
    bl = bl * bl;

    return blColor * bl;
}

// ── MAIN BLENDHER LIGHTING ─────────────────────────────────────
// albedo:     linear-space surface color
// lightmap:   (x=blockLight y=skyLight) 0-1
// worldNormal: world-space surface normal
// shadow:     1=lit 0=in shadow
// sunViewVec: sun position in view space
vec3 applyBlendHerLighting(vec3 albedo, vec2 lightmap,
                            vec3 worldNormal, float shadow,
                            vec3 sunViewVec) {
    float blockLight = lightmap.x;
    float skyLight   = lightmap.y;
    float totalLight = max(blockLight, skyLight);

    float mefade = getMEFade();
    float dfade  = getDFade();
    float sunVis = getSunVisibility(sunViewVec);

    vec3 lightCol   = getLightColor(mefade, dfade, sunVis);
    vec3 ambientCol = getAmbientColor(mefade, dfade, sunVis);
    vec3 blockLit   = getBlockLightColor(blockLight);

    // Half-Lambert sky diffuse (softer terminator than raw NdotL)
    vec3 sunDir = normalize(sunViewVec);
    float NdotL = dot(worldNormal, sunDir);
    float diffuse = clamp(NdotL * 0.5 + 0.5, 0.2, 1.0); // half-lambert

    // BSL-style lighting:
    // skyLight^2 controls how much sky bounce reaches this surface
    float skylightSqr = skyLight * skyLight;
    float rainDim     = 1.0 - 0.6 * rainStrength;

    // In shadow: only ambient bounce. In light: full direct + ambient
    vec3 sceneLighting = mix(
        ambientCol * skylightSqr * 0.85,                      // shadowed
        lightCol   * skylightSqr * diffuse * rainDim,         // lit
        shadow * clamp(sunVis, 0.0, 1.0)
    );

    // Combine: albedo * (scene + block)
    vec3 lit = albedo * (sceneLighting + blockLit);

    // Minimum light -- no pure black voids outside (very faint sky glow)
    vec3 minLight = vec3(0.004, 0.004, 0.006) * eBS;
    lit = max(lit, albedo * minLight);

    // ── SPOOKLEMENTARY HORROR BLEND ───────────────────────────
    // In dark areas: desaturate towards grey-olive + inject purple floor
    float spookBlend = 1.0 - smoothstep(
        AMBIENT_THRESHOLD,
        AMBIENT_THRESHOLD + AMBIENT_BLEND_WIDTH,
        totalLight
    );

    if (spookBlend > 0.001) {
        float l       = luma(lit);
        // Desaturate + push toward olive-purple (Spooklementary palette)
        vec3 olivePurple = mix(vec3(l), vec3(l * 0.9, l * 0.88, l * 1.05), 0.4);
        vec3 desatLit    = mix(lit, olivePurple, SPOOK_DESAT * spookBlend);

        // ADDITIVE purple ambient floor (the BlendHer signature)
        // Additive = visible even in zero light. Multiplicative would kill it.
        vec3  purpleFloor = vec3(AMBIENT_R, AMBIENT_G, AMBIENT_B);
        float floorFade   = 1.0 - smoothstep(0.0, 0.10, totalLight);
        // Slightly stronger floor near torch (warmth meets horror at the boundary)
        desatLit += purpleFloor * floorFade * (1.0 + blockLight * 0.6);

        lit = mix(lit, desatLit, spookBlend);
    }

    // ── MOONLIGHT CYAN TINT ────────────────────────────────────
    // worldTime 13000-23000 = night. Enables navigation but keeps anxiety.
    float dayFrac = float(worldTime) / 24000.0;
    float isNight = smoothstep(0.45, 0.55, dayFrac)
                  - smoothstep(0.95, 1.0,  dayFrac);
    if (isNight > 0.001 && skyLight > 0.02) {
        vec3 moonTint = vec3(MOON_CYAN_R, MOON_CYAN_G, MOON_CYAN_B);
        lit = mix(lit, lit * moonTint * (1.0 + MOON_INTENSITY),
                  isNight * skyLight * 0.45);
    }

    // ── RAIN DESATURATION ─────────────────────────────────────
    if (rainStrength > 0.001) {
        float rainDesat = rainStrength * RAIN_DESAT * 0.45;
        float rainLuma  = luma(lit);
        lit = mix(lit, vec3(rainLuma), rainDesat);
        // Rain also slightly cools the palette (blue push)
        lit.b = mix(lit.b, lit.b * 1.05, rainStrength * 0.3);
    }

    return lit;
}
