// ============================================================
// BLENDHER v3 -- shadow.glsl
// Cosine distortion, PCF 3x3 soft shadows, radial SS god rays
// ============================================================

// Cosine distortion: concentrates resolution near player
vec2 distortShadowUV(vec2 uv) {
    float d  = length(uv);
    float dm = mix(d, 1.0, SHADOW_DISTORTION);
    return uv / max(dm, 0.0001);
}

// Full PCF shadow with normal offset acne fix
float getShadow(vec3 worldPos, vec3 worldNormal, sampler2D shadowMap) {
    // Normal offset: push surface along normal to prevent self-shadow acne
    vec3 offs = worldPos + worldNormal * SHADOW_NORMAL_OFFSET;

    // Transform to shadow clip space
    vec4 shadowClip = shadowProjection * shadowModelView * vec4(offs, 1.0);
    vec3 sNDC       = shadowClip.xyz / shadowClip.w;

    vec2  sUV    = sNDC.xy * 0.5 + 0.5;
    float sDepth = sNDC.z  * 0.5 + 0.5 - SHADOW_BIAS;

    // Out of shadow map bounds = fully lit
    if (any(lessThan(sUV, vec2(0.02))) || any(greaterThan(sUV, vec2(0.98)))) {
        return 1.0;
    }

    // Apply cosine distortion (matches shadow.vsh)
    sUV = distortShadowUV(sUV * 2.0 - 1.0) * 0.5 + 0.5;

    // PCF 3x3: Percentage Closer Filtering for soft edges
    float shadow = 0.0;
    vec2  tSz    = 1.0 / vec2(float(SHADOW_RESOLUTION));

    for (int x = -1; x <= 1; x++) {
        for (int y = -1; y <= 1; y++) {
            float stored = texture2D(shadowMap, sUV + vec2(x, y) * tSz).r;
            shadow += step(sDepth, stored);
        }
    }
    return shadow / 9.0;
}

// God rays: radial screen-space blur toward sun
// sunScreenPos: sun projected to 0-1 screen UV
vec3 getGodRays(sampler2D sceneColor, vec2 uv, vec2 sunScreenPos, float sunVisibility) {
    // Only active when sun is above horizon
    if (sunVisibility < 0.01) return vec3(0.0);

    vec2  delta  = (uv - sunScreenPos) / float(GODRAY_SAMPLES);
    float decay  = 1.0;
    vec3  ray    = vec3(0.0);
    vec2  suv    = uv;

    for (int i = 0; i < GODRAY_SAMPLES; i++) {
        suv -= delta;
        suv  = clamp(suv, vec2(0.001), vec2(0.999));

        vec3  s   = texture2D(sceneColor, suv).rgb;
        float lum = dot(s, vec3(0.299, 0.587, 0.114));

        // Only bright sky pixels contribute (not terrain or shadowed areas)
        ray  += s * decay * step(0.75, lum);
        decay *= GODRAY_DECAY;
    }

    // Scale by sun visibility * strength
    return ray * GODRAY_STRENGTH * sunVisibility / float(GODRAY_SAMPLES);
}
