// ============================================================
// BLENDHER v3 -- displacement.glsl -- VERTEX STAGE ONLY
// BSL-style noise waving + ground-lock math
// block.10001 = grass  block.10002 = leaves  block.10003 = crops
// ============================================================

// Hash noise for organic, non-repeating motion (BSL approach)
float getHash(vec2 pos) {
    return fract(sin(dot(pos, vec2(12.9898, 4.1414))) * 43758.5453);
}

float noise2D(vec2 pos) {
    vec2 flr = floor(pos);
    vec2 frc = fract(pos);
    frc = frc * frc * (3.0 - 2.0 * frc); // smoothstep

    float n00 = getHash(flr);
    float n01 = getHash(flr + vec2(0.0, 1.0));
    float n10 = getHash(flr + vec2(1.0, 0.0));
    float n11 = getHash(flr + vec2(1.0, 1.0));

    return mix(mix(n00, n01, frc.y), mix(n10, n11, frc.y), frc.x) - 0.5;
}

vec3 getWindDisplacement(vec3 worldPos, float entityId,
                          float t, vec2 vaUV0, float rainAmt) {
    vec3 d = vec3(0.0);

    // ── GRASS: 2D noise for organic non-repeating motion ──────
    float grassW = step(abs(entityId - 10001.0), 0.5);
    if (grassW > 0.5) {
        vec2 noisePos = worldPos.xz * WIND_GRASS_FREQ * 0.15 + vec2(t * 0.8);
        float wave = noise2D(noisePos) * 2.0;
        float wave2 = noise2D(noisePos * 1.3 + vec2(0.5)) * 0.5;
        d.x += (wave + wave2) * WIND_GRASS_AMP;
        d.z += noise2D(noisePos + vec2(3.7)) * WIND_GRASS_AMP * 0.4;
    }

    // ── LEAVES: multi-axis layered noise ──────────────────────
    float leafW = step(abs(entityId - 10002.0), 0.5);
    if (leafW > 0.5) {
        vec2 noisePos = worldPos.xz * WIND_LEAVES_FREQ * 0.1 + vec2(t * 0.4);
        float wave = noise2D(noisePos);
        float waveY = noise2D(noisePos * 1.4 + vec2(1.2));
        d.x += wave * WIND_LEAVES_AMP;
        d.z += noise2D(noisePos + vec2(2.3)) * WIND_LEAVES_AMP * 0.7;
        d.y += waveY * WIND_LEAVES_AMP * 0.3;
    }

    // ── CROPS: faster, more nervous sway ──────────────────────
    float cropW = step(abs(entityId - 10003.0), 0.5);
    if (cropW > 0.5) {
        float wave = sin(t * WIND_CROPS_FREQ + worldPos.z * 1.2)
                   * cos(t * WIND_CROPS_FREQ * 0.8 + worldPos.x);
        d.x += wave * WIND_CROPS_AMP;
    }

    // ── RAIN MULTIPLIER: forest shivering in storm ────────────
    d *= mix(1.0, RAIN_WIND_MULT, rainAmt);

    // ── GROUND LOCK -- THE CRITICAL STEP ─────────────────────
    // Minecraft UV: V=0 at TOP of sprite, V=1 at BOTTOM.
    // step(0.5, vaUV0.y) = 1.0 for bottom vertices (V >= 0.5)
    // 1.0 - step = 1.0 for TOP vertices ONLY
    // Multiply by this: bottom vertices get zero displacement
    float isTop = 1.0 - step(0.5, vaUV0.y);
    // Leaves can move on all vertices (no ground-lock needed)
    float needsLock = max(grassW, cropW);
    d *= mix(1.0, isTop, needsLock);

    return d;
}
