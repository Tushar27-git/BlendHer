// ============================================================
// BLENDHER v3 -- uniforms.glsl -- Centralized uniform declarations
// All OptiFine built-in uniforms that BlendHer uses
// ============================================================

// G-Buffer color attachments
uniform sampler2D colortex0;    // albedo RGBA
uniform sampler2D colortex1;    // world normals (packed 0-1)
uniform sampler2D colortex2;    // PBR / specular flags
uniform sampler2D colortex3;    // lightmap: R=block G=sky / bloom pass

// Depth
uniform sampler2D depthtex0;    // main scene depth
uniform sampler2D depthtex1;    // translucent (water) depth

// Shadow
uniform sampler2D shadowtex0;   // shadow depth (all geometry)
uniform sampler2D shadowtex1;   // shadow depth (opaque only)
uniform sampler2D shadowcolor0; // shadow color (colored shadows)

// Matrices
uniform mat4 gbufferProjection;
uniform mat4 gbufferProjectionInverse;
uniform mat4 gbufferModelView;
uniform mat4 gbufferModelViewInverse;
uniform mat4 shadowProjection;
uniform mat4 shadowModelView;

// Camera / world
uniform vec3  cameraPosition;
uniform vec3  sunPosition;      // view-space sun direction * distance
uniform vec3  moonPosition;     // view-space moon direction * distance
uniform vec3  upPosition;       // world up in view space (OptiFine)

// Time & weather
uniform int   worldTime;        // 0-24000
uniform float timeAngle;        // 0-1 over day (0=noon 0.5=midnight)
uniform float timeBrightness;   // 0-1 (0=night 1=noon)
uniform float frameTimeCounter; // seconds
uniform float rainStrength;     // 0-1
uniform float thunderStrength;  // 0-1

// Viewport
uniform float viewWidth;
uniform float viewHeight;

// Misc
uniform float near;
uniform float far;
uniform ivec2 eyeBrightnessSmooth; // x=block y=sky (0-240)
uniform int   isEyeInWater;        // 0=air 1=water 2=lava

// Distant Horizons (only available when iris.features=DISTANT_HORIZONS is set)
#ifdef DISTANT_HORIZONS
uniform sampler2D dhDepthTex0;
uniform int       dhRenderDistance;
#endif

// Computed from uniforms -- shared across all programs that include this
// These are #define macros so they become inline expressions
#define eBS         (float(eyeBrightnessSmooth.y) / 240.0)
#define sunVecWorld (normalize(mat3(gbufferModelViewInverse) * normalize(sunPosition)))
