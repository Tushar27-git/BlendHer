// ============================================================
// BLENDHER v4 -- tonemapping.glsl
// ACES filmic + horror shadow crush + saturation/vibrance
// ============================================================

// Fast ACES approximation (Narkowicz 2015)
vec3 ACESFilmic(vec3 x) {
    const float a = 2.51;
    const float b = 0.03;
    const float c = 2.43;
    const float d = 0.59;
    const float e = 0.14;
    return clamp((x * (a * x + b)) / (x * (c * x + d) + e), 0.0, 1.0);
}

// Full ACES with input matrix (more accurate)
vec3 ACESFull(vec3 hdr) {
    const mat3 m1 = mat3(
        0.59719, 0.07600, 0.02840,
        0.35458, 0.90834, 0.13383,
        0.04823, 0.01566, 0.83777
    );
    vec3 v = m1 * hdr;
    vec3 a = v * (v + 0.0245786) - 0.000090537;
    vec3 b = v * (0.983729 * v + 0.4329510) + 0.238081;
    return clamp(a / b, 0.0, 1.0);
}

// Saturation adjustment (like BSL/Complementary shaders)
vec3 adjustSaturation(vec3 color, float saturation) {
    float l = dot(color, vec3(0.2126, 0.7152, 0.0722)); // Rec.709 luma
    return mix(vec3(l), color, saturation);
}

// Vibrance: selectively boost less-saturated colors (market standard)
// Unlike saturation which boosts everything uniformly,
// vibrance protects already-saturated colors from over-saturation
vec3 adjustVibrance(vec3 color, float vibrance) {
    float l     = dot(color, vec3(0.2126, 0.7152, 0.0722));
    float maxC  = max(color.r, max(color.g, color.b));
    float minC  = min(color.r, min(color.g, color.b));
    float sat   = maxC - minC; // rough saturation measure (0=grey, 1=full sat)
    // Low saturation gets boosted most, high saturation barely touched
    float vibranceAmt = (1.0 - sat) * (vibrance - 1.0);
    return mix(color, mix(vec3(l), color, vibrance), clamp(vibranceAmt + 1.0, 0.0, 2.0) - 1.0 + 1.0);
}

// Simpler vibrance implementation (more stable)
vec3 applyVibrance(vec3 color, float vibrance) {
    float l   = dot(color, vec3(0.2126, 0.7152, 0.0722));
    float sat = length(color - vec3(l)); // distance from grey
    // Boost colors that are less saturated
    float boost = (1.0 - smoothstep(0.0, 0.6, sat)) * (vibrance - 1.0);
    return mix(vec3(l), color, 1.0 + boost);
}

// Horror tone map: ACES + shadow crush power function
// The asymmetric curve: highlights stay bright (BSL), darks get crushed (Spook)
// pow(0.1, 1.18) = 0.068  -> 32% darker in deep shadows
// pow(0.5, 1.18) = 0.464  ->  7% darker at midtones
// pow(0.9, 1.18) = 0.880  ->  2% darker at highlights
vec3 horrorTonemap(vec3 hdr) {
    vec3 aces    = ACESFull(hdr);
    vec3 crushed = pow(max(aces, vec3(0.0)), vec3(HORROR_SHADOW_CRUSH));
    return pow(crushed, vec3(1.0 / 2.2)); // linear -> sRGB gamma
}

// Standard ACES for full daylight (BSL vibrancy state)
vec3 standardTonemap(vec3 hdr) {
    return pow(ACESFilmic(max(hdr, vec3(0.0))), vec3(1.0 / 2.2));
}

// BlendHer: dark/horror gets horror curve, bright daylight gets standard ACES
vec3 blendHerTonemap(vec3 hdr, float lightLevel) {
    float horrorBlend = 1.0 - smoothstep(0.04, 0.20, lightLevel);

    vec3 horror   = horrorTonemap(hdr);
    vec3 standard = standardTonemap(hdr);
    vec3 result   = mix(standard, horror, horrorBlend);

    // Apply saturation + vibrance AFTER tonemap (in gamma space like BSL/Complementary)
    result = adjustSaturation(result, SATURATION);
    result = applyVibrance(result, VIBRANCE);

    return clamp(result, vec3(0.0), vec3(1.0));
}
