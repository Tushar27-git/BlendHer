// ============================================================
// BLENDHER v3 -- pbr.glsl
// Screen Space Reflections for water surfaces
// ============================================================

vec3 getSSR(vec3 viewPos, vec3 viewNormal,
            sampler2D sceneColor, sampler2D depthBuffer) {
    vec3 viewDir = normalize(viewPos);
    vec3 reflDir = reflect(viewDir, viewNormal);

    vec3 rayPos  = viewPos;
    vec3 rayStep = reflDir * 0.25;

    for (int i = 0; i < SSR_STEPS; i++) {
        rayPos += rayStep;
        rayStep *= 1.06; // grow step for better far coverage

        vec4 proj   = gbufferProjection * vec4(rayPos, 1.0);
        proj       /= proj.w;
        vec2 scrUV  = proj.xy * 0.5 + 0.5;

        if (any(lessThan(scrUV, vec2(0.0))) ||
            any(greaterThan(scrUV, vec2(1.0)))) break;

        float sceneDepth = texture2D(depthBuffer, scrUV).r;
        float rayDepth   = proj.z * 0.5 + 0.5;

        if (rayDepth > sceneDepth && rayDepth - sceneDepth < SSR_THICKNESS) {
            // Edge fade: reflections fade at screen borders
            vec2 edgeFade = smoothstep(vec2(0.0), vec2(0.08), scrUV)
                          * smoothstep(vec2(1.0), vec2(0.92), scrUV);
            float fade = edgeFade.x * edgeFade.y;
            return texture2D(sceneColor, scrUV).rgb * fade;
        }
    }
    return vec3(0.0);
}
