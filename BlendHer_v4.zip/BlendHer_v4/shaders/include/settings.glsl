// ============================================================
// BLENDHER v4 -- settings.glsl -- THE MASTER CONFIG
// BSL Heritage + Spooklementary Horror
// "A vibrant dream slowly turning into a beautiful nightmare."
// ============================================================

// ■ SHADOW ■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■
#define SHADOW_RESOLUTION   2048    // 512-4096 | 2048 = 8MB VRAM sweet spot
#define SHADOW_DISTANCE     128.0   // blocks | 64-256
#define SHADOW_BIAS         0.0003  // depth bias | 0.0001-0.0006
#define SHADOW_NORMAL_OFFSET 0.03   // acne fix | 0.01-0.06
#define SHADOW_DISTORTION   0.85    // cosine distortion | 0.7-1.0

// ■ BSL TIME-OF-DAY LIGHT COLORS (RGB 0-255, intensity 0-4) ■■
// Morning / Evening -- BSL warm amber-orange
#define LIGHT_MR 255
#define LIGHT_MG 145
#define LIGHT_MB  60
#define LIGHT_MI  1.3

// Day -- cool blue-white (BSL signature: slightly desaturated daylight)
#define LIGHT_DR 200
#define LIGHT_DG 218
#define LIGHT_DB 255
#define LIGHT_DI  1.45

// Night -- dim moonlight steel blue
#define LIGHT_NR  90
#define LIGHT_NG 110
#define LIGHT_NB 175
#define LIGHT_NI  0.07

// ■ AMBIENT (SKY BOUNCE) COLORS ■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■
#define AMBIENT_MR 255
#define AMBIENT_MG 195
#define AMBIENT_MB 135
#define AMBIENT_MI  0.28

#define AMBIENT_DR 100
#define AMBIENT_DG 155
#define AMBIENT_DB 255
#define AMBIENT_DI  0.48

#define AMBIENT_NR  50
#define AMBIENT_NG  62
#define AMBIENT_NB 100
#define AMBIENT_NI  0.10

// ■ BLOCKLIGHT (TORCH/LAVA) ■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■
// BSL's classic warm amber-gold torch
#define BLOCKLIGHT_R 255
#define BLOCKLIGHT_G 148
#define BLOCKLIGHT_B  52
#define BLOCKLIGHT_I  1.6

// ■ SPOOKLEMENTARY HORROR ■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■
// Purple ambient floor -- additive in darkness = BlendHer signature
#define AMBIENT_R 0.04    // red channel | keep low
#define AMBIENT_G 0.025   // green channel | keep very low
#define AMBIENT_B 0.09    // blue channel | NEVER below 0.07
// NEVER set AMBIENT_B < 0.07 -- it kills the purple thread

#define AMBIENT_THRESHOLD   0.06   // Spook activates below this | 0.02-0.10
#define AMBIENT_BLEND_WIDTH 0.12   // crossfade width | 0.05-0.20
#define SPOOK_DESAT         0.55   // desaturation in shadow | 0=none 1=full

// ■ MOON / NIGHT ■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■
// Cool cyan-white moonlight (navigable horror)
#define MOON_CYAN_R 0.72
#define MOON_CYAN_G 0.88
#define MOON_CYAN_B 1.00
#define MOON_INTENSITY 0.15

// ■ TONE-MAPPING ■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■
#define HORROR_SHADOW_CRUSH 1.18  // shadow crush power | 1.0=standard 1.30=dark
#define EXPOSURE_BIAS       0.0   // overall exposure | -1 to +1

// ■ SATURATION & VIBRANCE ■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■
#define SATURATION  1.10   // BSL: slightly punchy | 1.0=neutral
#define VIBRANCE    1.15   // selective boost of less-saturated colors

// ■ BLOOM ■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■
#define BLOOM_THRESHOLD 0.85  // luma threshold | 0.5=everything 2.0=nothing
#define BLOOM_RADIUS    6.0   // gaussian pixel radius | 3-12
#define BLOOM_STRENGTH  1.50  // bloom mix | higher = more visible glow

// ■ SKY ■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■
#define SKY_DENSITY     1.8   // gradient falloff | 1.0-3.0
#define SKY_BRIGHTNESS  1.0   // overall sky multiplier

// ■ FOG ■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■
#define FOG_START       48.0    // clear vision blocks
#define FOG_DENSITY     0.0006  // exponential coefficient
#define FOG_DH_START    1100.0  // Distant Horizons fog wall start
#define FOG_DH_END      1400.0  // DH fog at 0.9 opacity
#define FOG_SAT_REDUCE  0.20    // -20% saturation vs sky
#define FOG_PURPLE_SHIFT 0.06   // purple push in fog
#define RAIN_DESAT      0.75    // rain desaturation max

// ■ WATER ■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■
#define WATER_CHROMA       0.025  // chromatic aberration at edges
#define WATER_ABSORB_R     0.015  // red absorbs slowest
#define WATER_ABSORB_G     0.04
#define WATER_ABSORB_B     0.10   // blue absorbs fastest = teal depths
#define WATER_REFLECT      0.85   // specular strength
#define WATER_WAVE_FREQ    0.22
#define WATER_WAVE_AMP     0.12
#define WATER_NIGHT_DARKEN 0.55   // midnight darkening | 0=off 1=black

// ■ FOLIAGE WIND ■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■
#define WIND_GRASS_FREQ  2.2
#define WIND_GRASS_AMP   0.12
#define WIND_LEAVES_FREQ 0.9
#define WIND_LEAVES_AMP  0.06
#define WIND_CROPS_FREQ  3.0
#define WIND_CROPS_AMP   0.08
#define RAIN_WIND_MULT   1.8

// ■ GOD RAYS ■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■
#define GODRAY_SAMPLES  10
#define GODRAY_STRENGTH 0.35
#define GODRAY_DECAY    0.96

// ■ SSR ■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■
#define SSR_STEPS     20
#define SSR_THICKNESS 0.4
