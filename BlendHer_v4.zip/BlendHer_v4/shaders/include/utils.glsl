// ============================================================
// BLENDHER v3 -- utils.glsl -- Math helpers
// ============================================================

// Rec.709 luma
float luma(vec3 c) {
    return dot(c, vec3(0.299, 0.587, 0.114));
}

// sRGB -> linear
vec3 toLinear(vec3 srgb) {
    return pow(max(srgb, vec3(0.0001)), vec3(2.2));
}

// linear -> sRGB
vec3 toSRGB(vec3 lin) {
    return pow(max(lin, vec3(0.0001)), vec3(1.0 / 2.2));
}

// Remap a value from one range to another
float remap(float v, float inMin, float inMax, float outMin, float outMax) {
    return outMin + (v - inMin) * (outMax - outMin) / max(inMax - inMin, 0.0001);
}

// Smooth minimum -- merges two values smoothly
float smin(float a, float b, float k) {
    float h = clamp(0.5 + 0.5 * (b - a) / k, 0.0, 1.0);
    return mix(b, a, h) - k * h * (1.0 - h);
}

// BSL lightmap remap: converts OptiFine raw lightmap UV to clean 0-1
// gl_TextureMatrix[1] * gl_MultiTexCoord1 gives ~0.033-0.967 range
vec2 remapLightmap(vec2 raw) {
    return clamp((raw - 0.03125) * 1.06667, vec2(0.0), vec2(1.0));
}
