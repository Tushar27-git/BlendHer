// ============================================================
// BLENDHER v4 -- atmosphere.glsl
// SKY FIX: getBlendHerSkyColor now handles VoU < 0 (void/below horizon)
// previously returned max(sky,0) but the entire daySky calc was broken
// for downward directions, producing near-zero values that allowed the
// raw OpenGL clear color (cyan) to show through.
// ============================================================

// ── SKY COLOR ─────────────────────────────────────────────────
vec3 getBlendHerSkyColor(vec3 viewDir, vec3 sunDir, vec3 upVec) {
    float VoU = dot(viewDir, upVec);   // -1=down, 0=horizon, 1=zenith
    float VoL = dot(viewDir, sunDir);  // -1=anti-sun, 1=toward sun

    float mefade = getMEFade();     // 1 at sunrise/sunset
    float dfade  = getDFade();      // 1 at noon
    float sunVis = getSunVisibility(sunDir);
    float sunVisSq = sunVis * sunVis;

    // ── Day sky: rich blue zenith, lighter horizon ──────────
    // Use abs(VoU) for the gradient so below-horizon mirrors above
    // This kills the void being a different color than the horizon
    float horizonDist = 1.0 - abs(VoU);  // 1 at horizon, 0 at zenith/nadir
    float gradient    = exp(-max(VoU, 0.0) * SKY_DENSITY * 0.55);

    // BSL-style rich blue: darker zenith, lighter horizon
    vec3 dayZenith  = vec3(0.18, 0.42, 0.88) * SKY_BRIGHTNESS;
    vec3 dayHorizon = vec3(0.55, 0.76, 1.00) * SKY_BRIGHTNESS;
    vec3 daySky     = mix(dayZenith, dayHorizon, gradient);

    // Below horizon: blend to a warm haze instead of void
    if (VoU < 0.0) {
        // Mirror the horizon color downward, getting slightly darker + warmer
        float voidBlend = smoothstep(0.0, -0.4, VoU);  // fade into ground haze
        vec3 voidColor  = mix(dayHorizon, vec3(0.58, 0.70, 0.82), voidBlend) * SKY_BRIGHTNESS;
        daySky = mix(daySky, voidColor, smoothstep(0.0, -0.1, VoU));
    }

    // ── Sun glow near horizon ─────────────────────────────────
    float sunGlow = pow(max(VoL * 0.5 + 0.5, 0.0), 5.0)
                  * clamp(1.0 - abs(VoU) * 2.5, 0.0, 1.0);
    vec3 sunHaze  = mix(
        vec3(1.00, 0.50, 0.12),  // orange-red at sunrise/set
        vec3(1.00, 0.88, 0.55),  // golden-white at noon
        dfade
    );
    daySky += sunHaze * sunGlow * 0.9 * (1.0 - dfade * 0.5);

    // ── Sunset/Sunrise -- amber to violet gradient ─────────────
    float meHorizon  = clamp(1.0 - abs(VoU) * 3.5, 0.0, 1.0);
    vec3 sunsetColor = mix(
        vec3(1.00, 0.38, 0.08),   // low orange-red
        vec3(0.60, 0.25, 0.68),   // violet-purple (BlendHer thread)
        clamp(VoU * 2.0 + 0.4, 0.0, 1.0)
    );
    daySky = mix(daySky, sunsetColor, mefade * meHorizon * 0.88);

    // ── Night sky: dark indigo-purple ─────────────────────────
    float nightGrad = exp(-max(VoU, 0.0) * 0.6);
    vec3 nightSky   = mix(
        vec3(0.012, 0.010, 0.040),  // zenith: very dark
        vec3(0.050, 0.035, 0.115),  // horizon: dark purple pulse
        nightGrad
    );
    // Below-horizon night: uniform dark blue-purple ground
    if (VoU < 0.0) {
        nightSky = mix(nightSky, vec3(0.03, 0.02, 0.07), smoothstep(0.0, -0.2, VoU));
    }

    // ── Compose day and night ─────────────────────────────────
    vec3 sky = mix(nightSky, daySky, sunVisSq);

    // ── Rain overcast ─────────────────────────────────────────
    vec3 rainSkyTop = vec3(0.28, 0.27, 0.33);
    vec3 rainSkyHor = vec3(0.20, 0.19, 0.24);
    vec3 rainSky    = mix(rainSkyTop, rainSkyHor, clamp(-VoU + 0.5, 0.0, 1.0));
    sky = mix(sky, rainSky, rainStrength * 0.90);

    // Guarantee no NaN or negatives leak through
    return max(sky, vec3(0.0));
}

// ── FOG COLOR: sky-derived with BlendHer purple push ──────────
vec3 getFogColor(vec3 skyColor) {
    float l    = luma(skyColor);
    vec3 desat = mix(skyColor, vec3(l), FOG_SAT_REDUCE);
    desat += vec3(FOG_PURPLE_SHIFT * 0.5, 0.0, FOG_PURPLE_SHIFT);
    return desat;
}

// ── FOG DENSITY ───────────────────────────────────────────────
float getFogDensity(float viewDist) {
    float localFog = 1.0 - exp(-FOG_DENSITY * max(viewDist - FOG_START, 0.0));
    float dhFog    = smoothstep(FOG_DH_START, FOG_DH_END, viewDist) * 0.92;
    localFog       = mix(localFog, localFog * 1.4, rainStrength * 0.35);
    return clamp(max(localFog, dhFog), 0.0, 1.0);
}

// ── APPLY FOG ─────────────────────────────────────────────────
vec3 applyFog(vec3 scene, vec3 skyColor, float viewDist) {
    vec3  fogColor = getFogColor(skyColor);
    float fogFact  = getFogDensity(viewDist);

    // Rain desaturation (NOT fog addition -- preserves 32 block visibility)
    float rainDesat = rainStrength * RAIN_DESAT * 0.55;
    float sLuma     = luma(scene);
    scene = mix(scene, vec3(sLuma), rainDesat);

    return mix(scene, fogColor, fogFact);
}
