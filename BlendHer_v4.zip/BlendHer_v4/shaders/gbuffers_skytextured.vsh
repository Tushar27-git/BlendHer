#version 150 compatibility
#extension GL_ARB_explicit_attrib_location : enable
// BLENDHER v3 -- gbuffers_skytextured.vsh -- Sun/moon textures

out vec2 texcoord;
out vec4 color;

void main() {
    texcoord    = (gl_TextureMatrix[0] * gl_MultiTexCoord0).xy;
    color       = gl_Color;
    gl_Position = ftransform();
}
