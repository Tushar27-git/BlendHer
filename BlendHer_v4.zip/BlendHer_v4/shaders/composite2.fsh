#version 150 compatibility
#extension GL_ARB_explicit_attrib_location : enable
// BLENDHER v3 -- composite2.fsh -- Bloom vertical blur + add to scene

#include "/include/settings.glsl"
#include "/include/uniforms.glsl"

in vec2 texcoord;

/* DRAWBUFFERS:0 */
layout(location = 0) out vec4 fragColor;

void main() {
    vec3  bloom       = vec3(0.0);
    float totalWeight = 0.0;
    vec2  texel       = 1.0 / vec2(viewWidth, viewHeight);
    int   radius      = int(BLOOM_RADIUS);

    // Vertical Gaussian pass (reads horizontal blur result from colortex3)
    for (int i = -radius; i <= radius; i++) {
        float fi     = float(i);
        float weight = exp(-0.5 * (fi * fi) / (BLOOM_RADIUS * BLOOM_RADIUS * 0.25));
        vec3  sample = texture2D(colortex3, texcoord + vec2(0.0, fi * texel.y)).rgb;
        bloom       += sample * weight;
        totalWeight += weight;
    }

    vec3 bloomFinal = (bloom / max(totalWeight, 0.0001)) * BLOOM_STRENGTH;

    // Add bloom to lit scene (colortex0)
    vec3 scene = texture2D(colortex0, texcoord).rgb;
    fragColor  = vec4(scene + bloomFinal, 1.0);
}
