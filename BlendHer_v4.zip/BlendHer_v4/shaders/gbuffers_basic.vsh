#version 150 compatibility
#extension GL_ARB_explicit_attrib_location : enable
// ============================================================
// BLENDHER v4 -- gbuffers_basic.vsh
// THE REAL SKY FIX: Minecraft renders the void/horizon background
// through gbuffers_basic, NOT gbuffers_skybasic.
// Without this file, that geometry uses Minecraft's default program
// which outputs the raw clear color = the cyan patch.
// ============================================================

#include "/include/settings.glsl"
#include "/include/uniforms.glsl"

out vec3 viewPos;
out vec3 sunVec;
out vec3 upVec;
out vec4 vertColor;

void main() {
    sunVec   = normalize(sunPosition);
    upVec    = normalize(gbufferModelView[1].xyz);
    viewPos  = (gbufferModelView * gl_Vertex).xyz;
    vertColor = gl_Color;
    gl_Position = ftransform();
}
