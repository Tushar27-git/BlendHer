#version 150 compatibility
#extension GL_ARB_explicit_attrib_location : enable
// ============================================================
// BLENDHER v4 -- gbuffers_basic.fsh
// Handles void plane, horizon background, and any other geometry
// Minecraft renders before the sky dome. Must output our sky color.
// ============================================================

#include "/include/settings.glsl"
#include "/include/uniforms.glsl"
#include "/include/utils.glsl"
#include "/include/lighting.glsl"
#include "/include/atmosphere.glsl"

in vec3  viewPos;
in vec3  sunVec;
in vec3  upVec;
in vec4  vertColor;

/* DRAWBUFFERS:0 */
layout(location = 0) out vec4 fragColor;

void main() {
    vec3 nViewPos = normalize(viewPos);
    vec3 nSunVec  = normalize(sunVec);
    vec3 nUpVec   = normalize(upVec);

    // Render our BlendHer sky for ALL background geometry
    vec3 sky = getBlendHerSkyColor(nViewPos, nSunVec, nUpVec);

    fragColor = vec4(sky, 1.0);
}
