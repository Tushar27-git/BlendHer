#version 150 compatibility
#extension GL_ARB_explicit_attrib_location : enable
// BLENDHER v3 -- composite1.fsh -- Bloom horizontal Gaussian blur
// Reads bright-pass from colortex3, writes blurred result to colortex3

#include "/include/settings.glsl"
#include "/include/uniforms.glsl"

in vec2 texcoord;

/* DRAWBUFFERS:3 */
layout(location = 0) out vec4 fragColor;

void main() {
    vec3  bloom       = vec3(0.0);
    float totalWeight = 0.0;
    vec2  texel       = 1.0 / vec2(viewWidth, viewHeight);
    int   radius      = int(BLOOM_RADIUS);

    // Separable 1D Gaussian -- horizontal pass
    for (int i = -radius; i <= radius; i++) {
        float fi     = float(i);
        float weight = exp(-0.5 * (fi * fi) / (BLOOM_RADIUS * BLOOM_RADIUS * 0.25));
        vec3  sample = texture2D(colortex3, texcoord + vec2(fi * texel.x, 0.0)).rgb;
        bloom       += sample * weight;
        totalWeight += weight;
    }

    fragColor = vec4(bloom / max(totalWeight, 0.0001), 1.0);
}
