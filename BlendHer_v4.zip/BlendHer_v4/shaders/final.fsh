#version 150 compatibility
#extension GL_ARB_explicit_attrib_location : enable
// BLENDHER v3 -- final.fsh -- screen output

uniform sampler2D colortex0;
uniform float viewWidth;
uniform float viewHeight;

in vec2 texcoord;

/* DRAWBUFFERS:0 */
layout(location = 0) out vec4 fragColor;

void main() {
    vec3 color = texture2D(colortex0, texcoord).rgb;

    // Subtle vignette (darkens edges slightly -- adds cinematic depth)
    vec2  uv      = texcoord - 0.5;
    float vignette = 1.0 - dot(uv, uv) * 0.6;
    vignette       = clamp(vignette, 0.0, 1.0);
    color         *= mix(1.0, vignette, 0.35);

    fragColor = vec4(max(color, vec3(0.0)), 1.0);
}
