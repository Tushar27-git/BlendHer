#version 150 compatibility
#extension GL_ARB_explicit_attrib_location : enable

#include "/include/settings.glsl"
#include "/include/uniforms.glsl"

out vec2 texcoord;
out vec2 lmcoord;
out vec3 normal;
out vec4 color;

void main() {
    texcoord    = (gl_TextureMatrix[0] * gl_MultiTexCoord0).xy;
    lmcoord     = (gl_TextureMatrix[1] * gl_MultiTexCoord1).xy;
    normal      = normalize(gl_NormalMatrix * gl_Normal);
    color       = gl_Color;
    gl_Position = gl_ModelViewProjectionMatrix * gl_Vertex;
}
