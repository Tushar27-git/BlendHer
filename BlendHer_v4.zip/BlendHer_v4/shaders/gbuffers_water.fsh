#version 150 compatibility
#extension GL_ARB_explicit_attrib_location : enable
// BLENDHER v3 -- gbuffers_water.fsh

#include "/include/settings.glsl"
#include "/include/uniforms.glsl"
#include "/include/utils.glsl"
#include "/include/water.glsl"

uniform sampler2D gtexture;

in vec2 texcoord;
in vec2 lmcoord;
in vec3 normal;
in vec4 color;
in vec3 viewPosV;
in vec3 worldPosV;

/* DRAWBUFFERS:0123 */
layout(location = 0) out vec4 outColor0;
layout(location = 1) out vec4 outColor1;
layout(location = 2) out vec4 outColor2;
layout(location = 3) out vec4 outColor3;

void main() {
    vec4 baseColor = texture2D(gtexture, texcoord) * color;
    if (baseColor.a < 0.05) discard;
    baseColor.rgb = toLinear(baseColor.rgb);

    // Chromatic aberration
    vec2 screenUV = gl_FragCoord.xy / vec2(viewWidth, viewHeight);
    vec2 aberr    = getChromaticAberration(screenUV);
    float r = toLinear(vec3(texture2D(gtexture, texcoord + aberr).r)).r;
    float b = toLinear(vec3(texture2D(gtexture, texcoord - aberr).b)).r;
    vec3 aberrColor = vec3(r, baseColor.g, b) * color.rgb;

    // Water depth via scene depth vs water surface position
    float terrainDepthRaw = texture2D(depthtex1, screenUV).r;
    vec4  terrainNDC      = vec4(screenUV * 2.0 - 1.0, terrainDepthRaw * 2.0 - 1.0, 1.0);
    vec4  terrainView     = gbufferProjectionInverse * terrainNDC;
    terrainView          /= terrainView.w;
    float waterDepth      = max(distance(viewPosV, terrainView.xyz), 0.0);

    // Beer-Lambert absorption + night darkening
    vec3 waterColor = applyWaterAbsorption(aberrColor, waterDepth);
    float skyLm     = clamp(lmcoord.y, 0.0, 1.0);
    float dayLight  = remapLightmap(lmcoord).y;
    waterColor      = applyWaterNightDarken(waterColor, dayLight);

    // Gerstner-derived perturbed normal
    vec3 waterNormal = getWaterNormal(worldPosV.xz, frameTimeCounter);
    vec3 finalNormal = normalize(normal + waterNormal * 0.7);

    vec2 lm = clamp(lmcoord, vec2(0.0), vec2(1.0));

    outColor0 = vec4(waterColor, baseColor.a);
    outColor1 = vec4(finalNormal * 0.5 + 0.5, 1.0);
    outColor2 = vec4(0.0, 1.0, 0.0, 1.0); // g=1.0 marks this pixel as water for SSR
    outColor3 = vec4(lm, 0.0, 1.0);
}
