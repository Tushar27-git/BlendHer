#version 150 compatibility
#extension GL_ARB_explicit_attrib_location : enable
// BLENDHER v3 -- shadow.vsh

#include "/include/settings.glsl"
#include "/include/uniforms.glsl"
#include "/include/shadow.glsl"

attribute vec4 mc_Entity;

out vec2 texcoord;
out vec4 color;

void main() {
    texcoord = (gl_TextureMatrix[0] * gl_MultiTexCoord0).xy;
    color    = gl_Color;

    vec4 viewPos = gl_ModelViewMatrix * gl_Vertex;
    vec4 projPos = gl_ProjectionMatrix * viewPos;

    // Cosine distortion: better shadow detail near player
    vec2 sUV     = projPos.xy / projPos.w;
    sUV          = distortShadowUV(sUV);
    projPos.xy   = sUV * projPos.w;

    gl_Position = projPos;
}
