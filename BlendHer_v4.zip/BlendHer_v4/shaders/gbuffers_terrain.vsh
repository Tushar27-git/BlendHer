#version 150 compatibility
#extension GL_ARB_explicit_attrib_location : enable
// ============================================================
// BLENDHER v3 -- gbuffers_terrain.vsh
// Terrain vertex: lightmap encoding + wind displacement
// ============================================================

#include "/include/settings.glsl"
#include "/include/uniforms.glsl"
#include "/include/displacement.glsl"

attribute vec4 mc_Entity;
attribute vec4 mc_midTexCoord;

out vec2 texcoord;
out vec2 lmcoord;
out vec3 normal;
out vec4 color;

void main() {
    texcoord = (gl_TextureMatrix[0] * gl_MultiTexCoord0).xy;
    // Raw lightmap UV from OptiFine -- already 0-1 range via TextureMatrix
    lmcoord  = (gl_TextureMatrix[1] * gl_MultiTexCoord1).xy;
    normal   = normalize(gl_NormalMatrix * gl_Normal);
    color    = gl_Color;

    vec4 viewPos  = gl_ModelViewMatrix * gl_Vertex;
    vec3 worldPos = (gbufferModelViewInverse * viewPos).xyz + cameraPosition;

    // Wind displacement using noise (vertex stage only -- never fragment)
    vec2 vaUV0   = texcoord;
    vec3 disp    = getWindDisplacement(worldPos, mc_Entity.x,
                                        frameTimeCounter, vaUV0, rainStrength);

    // Reconstruct view pos with displacement applied in world space
    vec3 worldPosDisplaced = (gbufferModelViewInverse * viewPos).xyz + disp;
    viewPos = gbufferModelView * vec4(worldPosDisplaced, 1.0);

    gl_Position = gl_ProjectionMatrix * viewPos;
}
