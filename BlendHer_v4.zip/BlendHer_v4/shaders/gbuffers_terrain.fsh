#version 150 compatibility
#extension GL_ARB_explicit_attrib_location : enable
// ============================================================
// BLENDHER v3 -- gbuffers_terrain.fsh
// Writes albedo, normals, lightmap to G-buffers for deferred lighting
// ============================================================

#include "/include/settings.glsl"
#include "/include/uniforms.glsl"
#include "/include/utils.glsl"

uniform sampler2D gtexture;

in vec2 texcoord;
in vec2 lmcoord;
in vec3 normal;
in vec4 color;

/* DRAWBUFFERS:0123 */
layout(location = 0) out vec4 outColor0; // colortex0: albedo
layout(location = 1) out vec4 outColor1; // colortex1: normal
layout(location = 2) out vec4 outColor2; // colortex2: PBR flags
layout(location = 3) out vec4 outColor3; // colortex3: lightmap

void main() {
    vec4 albedo = texture2D(gtexture, texcoord) * color;
    if (albedo.a < 0.1) discard;

    albedo.rgb = toLinear(albedo.rgb);

    // Encode normal to 0-1 range for G-buffer storage
    vec3 encodedNormal = normal * 0.5 + 0.5;

    // Lightmap: clamp to valid range (TextureMatrix gives ~0.033-0.967)
    // Store raw -- composite.fsh will use remapLightmap()
    vec2 lm = clamp(lmcoord, vec2(0.0), vec2(1.0));

    outColor0 = albedo;
    outColor1 = vec4(encodedNormal, 1.0);
    outColor2 = vec4(0.0, 0.0, 0.0, 1.0); // no PBR data for basic terrain
    outColor3 = vec4(lm, 0.0, 1.0);
}
