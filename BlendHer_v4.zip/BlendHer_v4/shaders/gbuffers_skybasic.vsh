#version 150 compatibility
#extension GL_ARB_explicit_attrib_location : enable
// ============================================================
// BLENDHER v4 -- gbuffers_skybasic.vsh
// FIX: previous version used invalid GLSL vec3(-sin,cos*vec2).
//      sunPosition uniform is already view-space -- use it directly.
// ============================================================

#include "/include/settings.glsl"
#include "/include/uniforms.glsl"

out vec3 viewPos;
out vec3 sunVec;
out vec3 upVec;
out float alpha;

void main() {
    // sunPosition from Iris is already in view space (sun direction * large distance)
    sunVec  = normalize(sunPosition);
    upVec   = normalize(gbufferModelView[1].xyz);
    viewPos = (gbufferModelView * gl_Vertex).xyz;
    alpha   = gl_Color.a;
    gl_Position = ftransform();
}
