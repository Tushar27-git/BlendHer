#version 150 compatibility
#extension GL_ARB_explicit_attrib_location : enable
// ============================================================
// BLENDHER v4 -- composite.fsh
// SKY FIX: depth==1.0 pixels now ALWAYS compute sky from view direction
// instead of passing through potentially-invalid gbuffer content.
// ============================================================

#include "/include/settings.glsl"
#include "/include/uniforms.glsl"
#include "/include/utils.glsl"
#include "/include/lighting.glsl"
#include "/include/shadow.glsl"
#include "/include/atmosphere.glsl"
#include "/include/tonemapping.glsl"
#include "/include/pbr.glsl"

in vec2 texcoord;

/* DRAWBUFFERS:03 */
layout(location = 0) out vec4 fragColor;
layout(location = 1) out vec4 fragBloom;

void main() {
    vec4  albedo  = texture2D(colortex0, texcoord);
    vec3  normal  = texture2D(colortex1, texcoord).rgb * 2.0 - 1.0;
    vec4  pbrData = texture2D(colortex2, texcoord);
    vec2  lmRaw   = texture2D(colortex3, texcoord).rg;
    float depth   = texture2D(depthtex0, texcoord).r;

    vec3  nUpVec  = normalize(gbufferModelView[1].xyz);
    vec3  nSunVec = normalize(sunPosition);

    // ── SKY PIXELS: always compute fresh sky color ───────────────
    // Do NOT pass through albedo -- it may be the buffer clear color (cyan)
    // on pixels where no geometry rendered. Compute sky from view direction.
    if (depth >= 1.0) {
        // Reconstruct view direction from texcoord
        vec4 ndc     = vec4(texcoord * 2.0 - 1.0, 1.0, 1.0);
        vec4 viewDir = gbufferProjectionInverse * ndc;
        vec3 nViewPos = normalize(viewDir.xyz / viewDir.w);

        vec3 sky = getBlendHerSkyColor(nViewPos, nSunVec, nUpVec);

        // Stars at night
        float sunVis0 = clamp(dot(nSunVec, nUpVec) * 10.0 + 0.5, 0.0, 1.0);
        if (sunVis0 < 0.3 && nViewPos.y > 0.0) {
            vec3  cell  = floor(nViewPos * 200.0);
            float sh    = fract(sin(dot(cell, vec3(127.1, 311.7, 74.3))) * 43758.5453);
            float sh2   = fract(sin(dot(cell, vec3(269.5, 183.3, 246.1))) * 43758.5453);
            float star  = step(0.987, sh) * sh2;
            sky += vec3(star * 0.9, star * 0.95, star) * smoothstep(0.3, 0.0, sunVis0);
        }

        // Apply gamma to match tonemapped terrain
        sky = pow(max(sky, vec3(0.0)), vec3(1.0 / 2.2));

        fragColor = vec4(sky, 1.0);
        fragBloom = vec4(0.0);
        return;
    }

    // ── RECONSTRUCT POSITIONS ────────────────────────────────────
    vec4  ndc      = vec4(texcoord * 2.0 - 1.0, depth * 2.0 - 1.0, 1.0);
    vec4  viewPos  = gbufferProjectionInverse * ndc;
    viewPos       /= viewPos.w;
    float vDist    = length(viewPos.xyz);

    vec3 worldPos    = (gbufferModelViewInverse * viewPos).xyz;
    vec3 worldNormal = normalize(mat3(gbufferModelViewInverse) * normalize(normal));

    // ── LIGHTMAP ─────────────────────────────────────────────────
    vec2 lightmap = remapLightmap(lmRaw);

    // ── SHADOW ───────────────────────────────────────────────────
    float shadow = getShadow(worldPos + cameraPosition, worldNormal, shadowtex0);

    // ── BSL + SPOOK LIGHTING ─────────────────────────────────────
    vec3 lit = applyBlendHerLighting(
        albedo.rgb, lightmap, worldNormal, shadow, sunPosition
    );

    // ── SSR (water) ──────────────────────────────────────────────
    float isWater = step(0.5, pbrData.g);
    if (isWater > 0.5) {
        vec3 ssr = getSSR(viewPos.xyz, normal, colortex0, depthtex0);
        if (dot(ssr, ssr) > 0.001) {
            vec3  vd      = normalize(viewPos.xyz);
            float cosT    = max(dot(-vd, normalize(normal)), 0.0);
            float fresnel = 0.02 + 0.98 * pow(1.0 - cosT, 5.0);
            lit = mix(lit, ssr, fresnel * WATER_REFLECT);
        }
    }

    // ── GOD RAYS ─────────────────────────────────────────────────
    float sunVis = clamp(dot(nSunVec, nUpVec) * 10.0 + 0.5, 0.0, 1.0);
    if (sunVis > 0.05) {
        vec4 sunProj   = gbufferProjection * vec4(nSunVec * 10.0, 1.0);
        vec2 sunScreen = (sunProj.xy / sunProj.w) * 0.5 + 0.5;
        vec3 godRays   = getGodRays(colortex0, texcoord, sunScreen, sunVis);
        lit += godRays * (1.0 - rainStrength * 0.6);
    }

    // ── FOG ──────────────────────────────────────────────────────
    float viewDist = vDist;
#ifdef DISTANT_HORIZONS
    float dhDepth = texture2D(dhDepthTex0, texcoord).r;
    if (dhDepth < depth && dhDepth < 0.9999) {
        vec4 dhNdc  = vec4(texcoord * 2.0 - 1.0, dhDepth * 2.0 - 1.0, 1.0);
        vec4 dhView = gbufferProjectionInverse * dhNdc;
        viewDist    = length((dhView / dhView.w).xyz);
    }
#endif

    vec3 nViewPos2 = normalize(viewPos.xyz);
    vec3 skyColor  = getBlendHerSkyColor(nViewPos2, nSunVec, nUpVec);
    lit = applyFog(lit, skyColor, viewDist);

    // ── TONEMAP + SATURATION/VIBRANCE ────────────────────────────
    float lightLevel = max(lightmap.x, lightmap.y);
    lit = blendHerTonemap(lit, lightLevel);

    fragColor = vec4(lit, albedo.a);

    // ── BLOOM BRIGHT-PASS ────────────────────────────────────────
    float litLuma = luma(lit);
    float bloomAmt = smoothstep(BLOOM_THRESHOLD, BLOOM_THRESHOLD + 0.15, litLuma);
    fragBloom = vec4(lit * bloomAmt, 1.0);
}
